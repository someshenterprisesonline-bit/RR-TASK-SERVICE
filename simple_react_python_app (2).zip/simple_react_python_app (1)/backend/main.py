import json
from flask import Flask, request, jsonify

app = Flask(__name__)

# Path to the file where tasks will be stored
TASKS_FILE = 'tasks.json'

# Initialize the tasks file if it doesn't exist
def init_tasks_file():
    try:
        with open(TASKS_FILE, 'r') as f:
            tasks = json.load(f)
    except FileNotFoundError:
        tasks = []
    return tasks

# Save tasks to the file
def save_tasks(tasks):
    with open(TASKS_FILE, 'w') as f:
        json.dump(tasks, f, indent=4)

# Get all tasks
@app.route('/tasks', methods=['GET'])
def get_tasks():
    tasks = init_tasks_file()
    return jsonify(tasks)

# Add a new task
@app.route('/tasks', methods=['POST'])
def add_task():
    task = request.json
    tasks = init_tasks_file()
    tasks.append(task)
    save_tasks(tasks)
    return jsonify(task), 201

if __name__ == '__main__':
    app.run(debug=True)
