# RR TASK SERVICE

Task tracking for RR Task Service: a FastAPI backend with MySQL 8 storage (stored
procedures) or a local JSON file, and a React + Vite frontend with a cinematic 3D
landing intro, MY TASKS tracker, Admin Dashboard, analytics and Excel import/export.

## Requirements
- Python 3.10+
- Node.js 18+
- MySQL Server 8.0.29+ (only for MySQL storage mode)

## 1. Backend setup
```bash
cd backend
python -m pip install -r requirements.txt
```

### Storage mode and configuration
Configuration is read from environment variables, or from `backend/.env`
(git-ignored — never commit it):

| Variable | Meaning |
| --- | --- |
| `RR_STORAGE` | `json` (default, uses `backend/tasks.json`) or `mysql` |
| `RR_DB_HOST` / `RR_DB_PORT` | MySQL host and port (default `127.0.0.1` / `3306`) |
| `RR_DB_NAME` | Database name (production: `rr_task_service`) |
| `RR_DB_USER` / `RR_DB_PASSWORD` | Restricted application account |
| `RR_DB_POOL_SIZE` | Connection pool size (default `10`) |

### MySQL setup (first time only)
1. Create the schema and procedures in MySQL (non-destructive scripts):
   `mysql_schema.sql`, then `mysql_task_procedures.sql`
   (existing databases with an older `sp_get_tasks`: `mysql_sp_get_tasks_v2.sql`).
2. Optional one-time migration from JSON: `mysql_json_migration.sql`, checked with
   `mysql_json_verification.sql`.
3. Create the restricted app account and `backend/.env`:
   `python tools/create_app_user.py` (uses a `rr_admin` login path from
   `mysql_config_editor`; the generated password is written only to `.env`).
4. Set `RR_STORAGE=mysql` in `backend/.env`.

### Demo account passwords
Login accounts are defined in `auth.py`; their passwords are hashed into
`backend/users.json` (git-ignored):
```bash
python set_passwords.py              # prompts for each account
python set_passwords.py --user NAME  # one account
```

### Start the backend (Terminal 1)
```bash
cd backend
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```
- API: http://127.0.0.1:8000 — health check: http://127.0.0.1:8000/api/health
- API docs: http://127.0.0.1:8000/docs

On Windows, if `python` is unavailable, use `py`.

## 2. Frontend (Terminal 2)
```bash
cd frontend
npm install
npm run dev        # Windows PowerShell: npm.cmd run dev
```
Open http://127.0.0.1:5173 — both backend and frontend must be running.

Production build: `npm run build` (output in `frontend/dist/`).

### Landing intro
- Plays once per browser session when the app opens on Home; **Skip intro**
  (top-right) or `Esc` skips it, **Replay intro** in the hero replays it.
- Honors `prefers-reduced-motion` (no autoplay; fade-only replay) and falls back
  to a lightweight 2D version without WebGL or on slow devices.

## 3. Tests
Backend tests use the disposable `rr_task_service_test` database and only make
read / zero-row probes against production:
```bash
cd backend
python -m pip install -r requirements-dev.txt
python tools/setup_test_db.py        # create the test database (once)
python -m pytest -q
```

## Maintenance tools (backend/tools)
- `compare_json_vs_mysql.py` — read-only comparison of a JSON snapshot and MySQL
- `export_mysql_to_json.py` — read-only export of MySQL to the JSON format (rollback)
- `backend/maintenance.py` — while the maintenance flag file exists, writes are refused

## Data safety
Never commit `backend/.env`, `backend/users.json`, `backend/tasks.json`,
`backend/backups/` or any database dump — they hold credentials or employee data
and are listed in `.gitignore`.
