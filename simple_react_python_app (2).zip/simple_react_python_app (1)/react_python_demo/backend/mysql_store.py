"""MySQL-backed data access for RR TASK SERVICE (used when RR_STORAGE=mysql).

* Individual task CRUD uses the stored procedures sp_add_task, sp_get_tasks,
  sp_get_task_by_id, sp_update_task and sp_delete_task.
* Excel import and admin Delete All run as single atomic transactions.
* Multi-step write workflows (duplicate check + write) are serialized with a
  MySQL named lock, replacing the JSON store's file lock.
* Records are returned in exactly the dictionary shape the JSON store used, so
  every API response is unchanged.
* Error details/status codes mirror the JSON implementation in main.py.
"""
from datetime import datetime, timezone

from fastapi import HTTPException

TASK_LOCK = 'rr_task_service.task_writes'
DUPLICATE_MESSAGE = 'This employee already has a task with the same description.'
_TASK_COLUMNS = ('`id`, `title`, `status`, `done`, `name`, `time`, `submitted_at`, '
                 '`submitted_by`, `_import_id`')
_SIGNAL_ERRNO = 1644          # SIGNAL SQLSTATE '45000' raised by a stored procedure
_INSERT_CHUNK = 1000


def task_from_row(row: dict) -> dict:
    """Same keys, key order and value types as a task object in tasks.json."""
    task = {'id': int(row['id']), 'title': row['title'], 'status': row['status'],
            'done': bool(row['done']), 'name': row['name'], 'time': row['time'],
            'submitted_at': row['submitted_at'], 'submitted_by': row['submitted_by']}
    if row.get('_import_id') is not None:
        task['_import_id'] = row['_import_id']
    return task


def user_from_row(row: dict) -> dict:
    """Same shape as a users.json record (state fields only once an account changed)."""
    user = {'username': row['username'], 'name': row['name'], 'role': row['role'],
            'password_hash': row['password_hash']}
    if not (row['active'] and row['deactivated_at'] is None and row['deactivated_by'] is None):
        user.update({'active': bool(row['active']), 'deactivated_at': row['deactivated_at'],
                     'deactivated_by': row['deactivated_by']})
    return user


def utc_now():
    now = datetime.now(timezone.utc).replace(microsecond=0)
    return now.isoformat(timespec='seconds'), now.replace(tzinfo=None)


class MySqlStore:
    def __init__(self, db, duplicate_key, edit_creates_duplicate):
        self.db = db
        self.duplicate_key = duplicate_key                      # main._task_duplicate_key
        self.edit_creates_duplicate = edit_creates_duplicate    # main._edit_creates_duplicate

    # ---------- helpers ----------
    def _signal_message(self, exc):
        if getattr(exc, 'errno', None) == _SIGNAL_ERRNO:
            return exc.msg
        return None

    def _call(self, conn, name, args):
        try:
            return self.db.call_proc(conn, name, args)
        except self.db.errors as exc:
            message = self._signal_message(exc)
            if message is None:
                raise
            if message == 'Task not found':
                raise HTTPException(status_code=404, detail='Task not found') from None
            raise HTTPException(status_code=422, detail=message) from None

    def _task_by_id(self, conn, task_id):
        rows = self._call(conn, 'sp_get_task_by_id', [task_id])
        return task_from_row(rows[0][0]) if rows and rows[0] else None

    def _name_title_rows(self, conn):
        return self.db.query(conn, 'SELECT `id`, `name`, `title` FROM `tasks` ORDER BY `id`')

    def _existing_keys(self, conn):
        return {key for r in self._name_title_rows(conn)
                if (key := self.duplicate_key(r['name'], r['title']))}

    def _employee_id(self, conn, name, create):
        """Employee row for the exact (space-trimmed) name, as the migration linked them."""
        rows = self.db.query(conn,
            'SELECT MIN(`employee_id`) AS id FROM `employees` '
            'WHERE `normalized_name` = LOWER(TRIM(%s)) AND CAST(`name` AS BINARY) = CAST(TRIM(%s) AS BINARY)',
            (name, name))
        if rows and rows[0]['id'] is not None:
            return int(rows[0]['id'])
        if not create:
            return None
        _, new_id = self.db.execute(conn,
            'INSERT INTO `employees` (`name`, `normalized_name`) VALUES (TRIM(%s), LOWER(TRIM(%s)))',
            (name, name))
        return int(new_id)

    def _user_id(self, conn, username):
        if not username:
            return None
        rows = self.db.query(conn, 'SELECT MIN(`user_id`) AS id FROM `users` '
                                   'WHERE CAST(`username` AS BINARY) = CAST(%s AS BINARY)', (username,))
        return int(rows[0]['id']) if rows and rows[0]['id'] is not None else None

    # ---------- task reads ----------
    def all_tasks(self):
        with self.db.connection() as conn:
            rows = self.db.query(conn, f'SELECT {_TASK_COLUMNS} FROM `tasks` ORDER BY `id`')
        return [task_from_row(r) for r in rows]

    def existing_task_keys(self):
        with self.db.connection() as conn:
            return self._existing_keys(conn)

    def page_tasks(self, query, status, sort, offset, limit):
        """sp_get_tasks: returns (total, all_total, tasks). query is already strip()+casefold()."""
        with self.db.connection() as conn:
            counts, rows = self._call(conn, 'sp_get_tasks', [query, status, sort, offset, limit])
        return int(counts[0]['total']), int(counts[0]['all_total']), [task_from_row(r) for r in rows]

    def task_stats(self):
        with self.db.connection() as conn:
            row = self.db.query(conn,
                "SELECT COUNT(*) AS total, "
                "COALESCE(SUM(CAST(`status` AS BINARY) = CAST('completed' AS BINARY)), 0) AS completed "
                "FROM `tasks`")[0]
        total, completed = int(row['total']), int(row['completed'])
        return {'total': total, 'completed': completed, 'pending': total - completed}

    # ---------- task writes ----------
    def add_task(self, title, name, task_time, status, submitted_by):
        with self.db.connection() as conn, self.db.named_lock(conn, TASK_LOCK):
            if self.duplicate_key(name, title) in self._existing_keys(conn):
                raise HTTPException(status_code=409, detail=DUPLICATE_MESSAGE)
            employee_id = self._employee_id(conn, name, create=True)
            submitted_at, submitted_utc = utc_now()
            result = self._call(conn, 'sp_add_task', [
                None, employee_id, name, title, status, 0, task_time, submitted_at, submitted_utc,
                submitted_by, self._user_id(conn, submitted_by), None])
            return self._task_by_id(conn, int(result[-1][0]['id']))

    def update_task(self, task_id, title, status, name, task_time):
        with self.db.connection() as conn, self.db.named_lock(conn, TASK_LOCK):
            current = self._task_by_id(conn, task_id)
            if current is None:
                raise HTTPException(status_code=404, detail='Task not found')
            next_name = name if name is not None else current.get('name', '')
            if not next_name.strip() or not title.strip():
                raise HTTPException(status_code=422, detail='Employee name and task description are required.')
            # Same shared rule as the JSON store. The generator defers the full-table read,
            # so it only runs when the edit actually changes the employee/task pair.
            def other_rows():
                yield from self._name_title_rows(conn)

            if self.edit_creates_duplicate(task_id, current['name'], current['title'], next_name, title, other_rows()):
                raise HTTPException(status_code=409, detail=DUPLICATE_MESSAGE)
            employee_id = self._employee_id(conn, next_name, create=True)
            # time=None keeps the stored time; done=None keeps the legacy flag.
            self._call(conn, 'sp_update_task', [task_id, employee_id, next_name, title, status, task_time, None])
            return self._task_by_id(conn, task_id)

    def delete_task(self, task_id):
        with self.db.connection() as conn, self.db.named_lock(conn, TASK_LOCK):
            try:
                self._call(conn, 'sp_delete_task', [task_id])
            except HTTPException as exc:
                if exc.status_code != 404:      # JSON store: deleting a missing id is a no-op
                    raise

    def delete_all_tasks(self, expected_count):
        """Atomic Delete All; returns the number deleted. Employees/users are kept."""
        with self.db.connection() as conn, self.db.named_lock(conn, TASK_LOCK):
            with self.db.transaction(conn):
                count = int(self.db.query(conn, 'SELECT COUNT(*) AS n FROM `tasks` FOR UPDATE')[0]['n'])
                if expected_count != count:
                    raise HTTPException(status_code=409,
                        detail=f'Task count changed; refresh before deleting. Current count: {count}.')
                if count:
                    self.db.execute(conn, 'DELETE FROM `tasks`')
            return count

    def import_tasks(self, stage_rows, import_id, submitted_by):
        """Atomic Excel import. Returns (added_rows, concurrent_duplicates, prior_names, total)."""
        with self.db.connection() as conn, self.db.named_lock(conn, TASK_LOCK):
            existing = self._name_title_rows(conn)
            prior_names = [r['name'] for r in existing]
            existing_keys = {key for r in existing if (key := self.duplicate_key(r['name'], r['title']))}
            rows_to_add, concurrent_duplicates = [], []
            for row in stage_rows:
                key = self.duplicate_key(row['name'], row['title'])
                if key in existing_keys:
                    concurrent_duplicates.append({'row_number': row['row_number'], 'reference': row['reference'],
                        'messages': ['Duplicate employee and task was saved after this preview was validated.']})
                else:
                    existing_keys.add(key)
                    rows_to_add.append(row)
            if rows_to_add:
                submitted_at, submitted_utc = utc_now()
                try:
                    with self.db.transaction(conn):
                        employee_ids = self._ensure_employees(conn, {row['name'] for row in rows_to_add})
                        user_id = self._user_id(conn, submitted_by)
                        values = [(employee_ids[row['name'].strip(' ')], row['name'], row['title'], 'pending', 0,
                                   row['time'], submitted_at, submitted_utc, submitted_by, user_id, import_id)
                                  for row in rows_to_add]
                        cur = conn.cursor()
                        try:
                            for start in range(0, len(values), _INSERT_CHUNK):
                                cur.executemany(
                                    'INSERT INTO `tasks` (`employee_id`, `name`, `title`, `status`, `done`, `time`, '
                                    '`submitted_at`, `submitted_at_utc`, `submitted_by`, `submitted_by_user_id`, '
                                    '`_import_id`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)',
                                    values[start:start + _INSERT_CHUNK])
                        finally:
                            cur.close()
                except HTTPException:
                    raise
                except Exception as exc:
                    raise HTTPException(status_code=500,
                        detail='Import was not saved. No task records were added.') from exc
            total = int(self.db.query(conn, 'SELECT COUNT(*) AS n FROM `tasks`')[0]['n'])
        return rows_to_add, concurrent_duplicates, prior_names, total

    def _ensure_employees(self, conn, names):
        """Map exact (space-trimmed) employee names to ids, creating missing rows (caller's transaction)."""
        wanted = {name.strip(' ') for name in names}
        known = {}
        for r in self.db.query(conn, 'SELECT `employee_id`, `name` FROM `employees` ORDER BY `employee_id`'):
            known.setdefault(r['name'], int(r['employee_id']))     # exact str match == BINARY match
        missing = sorted(n for n in wanted if n not in known)
        if missing:
            cur = conn.cursor()
            try:
                for start in range(0, len(missing), _INSERT_CHUNK):
                    cur.executemany('INSERT INTO `employees` (`name`, `normalized_name`) VALUES (%s, LOWER(%s))',
                                    [(n, n) for n in missing[start:start + _INSERT_CHUNK]])
            finally:
                cur.close()
            for r in self.db.query(conn, 'SELECT `employee_id`, `name` FROM `employees` ORDER BY `employee_id`'):
                known.setdefault(r['name'], int(r['employee_id']))
        return known

    # ---------- users ----------
    def load_users(self):
        with self.db.connection() as conn:
            rows = self.db.query(conn,
                'SELECT `username`, `name`, `role`, `password_hash`, `active`, `deactivated_at`, `deactivated_by` '
                'FROM `users` ORDER BY `user_id`')
        return {r['username']: user_from_row(r) for r in rows}

    def create_user(self, username, name, password_hash):
        with self.db.connection() as conn:
            try:
                self.db.execute(conn, "INSERT INTO `users` (`username`, `name`, `password_hash`, `role`) "
                                      "VALUES (%s, %s, %s, 'user')", (username, name, password_hash))
            except self.db.errors as exc:
                if getattr(exc, 'errno', None) == 1062:   # unique username (race with another request)
                    raise HTTPException(status_code=409, detail=f'Username "{username}" is already taken.') from None
                raise

    def deactivate_user(self, username, deactivated_at, deactivated_by):
        with self.db.connection() as conn:
            rowcount, _ = self.db.execute(conn,
                'UPDATE `users` SET `active` = 0, `deactivated_at` = %s, `deactivated_by` = %s '
                'WHERE CAST(`username` AS BINARY) = CAST(%s AS BINARY) AND `active` = 1',
                (deactivated_at, deactivated_by, username))
        if rowcount != 1:
            raise HTTPException(status_code=404, detail='User not found')

    # ---------- employee work ----------
    @staticmethod
    def _work_from_row(row):
        return {'id': int(row['id']), 'employee_name': row['employee_name'],
                'work_done': row['work_done'], 'time': row['time']}

    @staticmethod
    def _check_work(employee_name, work_done, work_time):
        if len(employee_name) > 100:
            raise HTTPException(status_code=422, detail='Employee name must be 100 characters or fewer.')
        if len(work_time) > 20:
            raise HTTPException(status_code=422, detail='Time must be 20 characters or fewer.')
        if len(work_done.encode('utf-8')) > 65535:
            raise HTTPException(status_code=422, detail='Work description is too long.')

    def list_work(self):
        with self.db.connection() as conn:
            rows = self.db.query(conn, 'SELECT `id`, `employee_name`, `work_done`, `time` '
                                       'FROM `employee_work_entries` ORDER BY `id`')
        return [self._work_from_row(r) for r in rows]

    def add_work(self, employee_name, work_done, work_time, recorded_by):
        self._check_work(employee_name, work_done, work_time)
        _, created_utc = utc_now()
        with self.db.connection() as conn:
            _, new_id = self.db.execute(conn,
                'INSERT INTO `employee_work_entries` (`employee_id`, `employee_name`, `work_done`, `time`, '
                '`recorded_by_user_id`, `created_at_utc`) VALUES (%s, %s, %s, %s, %s, %s)',
                (self._employee_id(conn, employee_name, create=False), employee_name, work_done, work_time,
                 self._user_id(conn, recorded_by), created_utc))
        return {'id': int(new_id), 'employee_name': employee_name, 'work_done': work_done, 'time': work_time}

    def update_work(self, entry_id, employee_name, work_done, work_time):
        self._check_work(employee_name, work_done, work_time)
        with self.db.connection() as conn, self.db.transaction(conn):
            if not self.db.query(conn, 'SELECT `id` FROM `employee_work_entries` WHERE `id` = %s FOR UPDATE',
                                 (entry_id,)):
                raise HTTPException(status_code=404, detail='Entry not found')
            self.db.execute(conn,
                'UPDATE `employee_work_entries` SET `employee_id` = %s, `employee_name` = %s, `work_done` = %s, '
                '`time` = %s WHERE `id` = %s',
                (self._employee_id(conn, employee_name, create=False), employee_name, work_done, work_time,
                 entry_id))
        return {'id': entry_id, 'employee_name': employee_name, 'work_done': work_done, 'time': work_time}

    def delete_work(self, entry_id):
        with self.db.connection() as conn:
            self.db.execute(conn, 'DELETE FROM `employee_work_entries` WHERE `id` = %s', (entry_id,))
