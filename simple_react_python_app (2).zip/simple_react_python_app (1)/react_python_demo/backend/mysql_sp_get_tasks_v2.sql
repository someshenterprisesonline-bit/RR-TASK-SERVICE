-- RR TASK SERVICE: replace sp_get_tasks so MySQL paging matches the original
-- Python (_filter_sort_tasks) behaviour exactly, including tie ordering.
--
-- Same name, same 5 parameters, same two result sets (counts, then rows).
-- Changes versus the original definition:
--   * name/task sorts: case-folded code-point order, ties by id ASCENDING
--     (original: accent/case-insensitive collation order, ties by id DESCENDING)
--   * search and status filter: case-insensitive but accent-SENSITIVE code-point
--     matching (utf8mb4_0900_bin on lower-cased text), like Python str.casefold().
-- Data is not touched. The original definition is preserved in
-- C:\RR_Backups\20261107-160925\mysql\sp_get_tasks_original.sql (and the full dump).
--
-- Apply ONLY to the database selected below, and only after approval:
--   mysql --login-path=rr_admin --comments <database> < mysql_sp_get_tasks_v2.sql
-- DROP PROCEDURE removes routine-level grants, so EXECUTE is granted again at the end.

DROP PROCEDURE IF EXISTS `sp_get_tasks`;

DELIMITER $$

CREATE PROCEDURE `sp_get_tasks`(
    IN p_query VARCHAR(200),
    IN p_status VARCHAR(20),
    IN p_sort VARCHAR(20),
    IN p_offset INT UNSIGNED,
    IN p_limit INT UNSIGNED
)
SQL SECURITY INVOKER
READS SQL DATA
BEGIN
    DECLARE v_status VARCHAR(20);
    DECLARE v_sort VARCHAR(20);
    DECLARE v_query VARCHAR(200);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SET v_status = LOWER(TRIM(p_status));
    SET v_sort = LOWER(TRIM(p_sort));
    SET v_query = LOWER(TRIM(COALESCE(p_query, '')));
    IF v_status IS NULL OR v_status NOT IN ('all', 'pending', 'completed') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid task status filter';
    END IF;
    IF v_sort IS NULL OR v_sort NOT IN ('newest', 'oldest', 'name', 'task') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid task sort option';
    END IF;
    IF p_offset IS NULL OR p_limit IS NULL OR p_limit < 1 OR p_limit > 200 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Use offset >= 0 and limit between 1 and 200';
    END IF;

    -- Count and page results share a read-only transaction snapshot.
    START TRANSACTION READ ONLY;

    SELECT
        COUNT(*) AS `total`,
        (SELECT COUNT(*) FROM `tasks`) AS `all_total`
    FROM `tasks` AS t
    WHERE (v_status = 'all'
           OR LOWER(t.`status`) COLLATE utf8mb4_0900_bin = v_status COLLATE utf8mb4_0900_bin)
      AND (
          v_query = ''
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`name`) COLLATE utf8mb4_0900_bin) > 0
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`title`) COLLATE utf8mb4_0900_bin) > 0
      );

    SELECT
        t.`id`, t.`employee_id`, t.`name`, t.`title`, t.`status`, t.`done`,
        t.`time`, t.`submitted_at`, t.`submitted_at_utc`, t.`submitted_by`,
        t.`submitted_by_user_id`, t.`_import_id`
    FROM `tasks` AS t
    WHERE (v_status = 'all'
           OR LOWER(t.`status`) COLLATE utf8mb4_0900_bin = v_status COLLATE utf8mb4_0900_bin)
      AND (
          v_query = ''
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`name`) COLLATE utf8mb4_0900_bin) > 0
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`title`) COLLATE utf8mb4_0900_bin) > 0
      )
    ORDER BY
        CASE WHEN v_sort = 'name' THEN LOWER(t.`name`) COLLATE utf8mb4_0900_bin END ASC,
        CASE WHEN v_sort = 'task' THEN LOWER(t.`title`) COLLATE utf8mb4_0900_bin END ASC,
        CASE WHEN v_sort = 'newest' THEN t.`id` END DESC,
        t.`id` ASC
    LIMIT p_offset, p_limit;

    COMMIT;
END$$

DELIMITER ;

-- Restore the application account's EXECUTE right (removed by DROP PROCEDURE).
GRANT EXECUTE ON PROCEDURE `sp_get_tasks` TO 'rr_app'@'127.0.0.1';
