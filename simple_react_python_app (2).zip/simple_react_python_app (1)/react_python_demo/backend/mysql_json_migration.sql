-- RR TASK SERVICE JSON-to-MySQL migration (MySQL 8.0.29+; target server 8.0.46)
--
-- * Never modifies the source JSON files. Reads byte-identical SAFE COPIES placed in
--   this server's secure_file_priv directory (my.ini: secure-file-priv=...):
--       C:/ProgramData/MySQL/MySQL Server 8.0/Uploads
-- * No existing row is UPDATEd or DELETEd. Rows whose key already exists with an
--   identical payload are skipped (safe re-run); a key that exists with DIFFERENT
--   data aborts the whole run before anything is written.
-- * No password is stored here. Password hashes are copied, never displayed.
-- * Run only after mysql_schema.sql. Stages -> validates -> inserts -> re-validates
--   -> COMMIT. Any failed check raises a "Check constraint ... is violated" error.
--   MySQL Workbench stops at that error (keep "Continue on SQL Script Error" OFF).
--   If it stops AFTER "START TRANSACTION", run ROLLBACK; before doing anything else.
-- * employee_work has no JSON source in the current backend and is not imported.
--
-- MySQL restriction honoured below: a TEMPORARY table may be referenced only ONCE
-- per statement (otherwise ERROR 1137 "Can't reopen table"), so every check that
-- reads a staging table is a separate statement.

USE `rr_task_service`;
SET NAMES utf8mb4;

-- ---------------------------------------------------------------------------
-- 0. Source files and their expected fingerprints (from the original files on
--    2026-11-07). If tasks.json/users.json change, recopy them AND update these.
-- ---------------------------------------------------------------------------
SET @rr_tasks_path = 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/rr_task_service_tasks.json';
SET @rr_users_path = 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/rr_task_service_users.json';
SET @rr_expected_tasks_sha256 = 'b0c29700c553f7aac0f4eb3f8352ec960a17c4f57ed5cc47ac34a6ff572bddc3';
SET @rr_expected_users_sha256 = '2e4eff3478911c540d1e81f29c9a8f238eeebf654b820a462a7e632dfc7a4aa5';
SET @rr_expected_tasks = 14004;
SET @rr_expected_users = 9;
SET @rr_expected_completed = 8000;
SET @rr_expected_pending = 6004;

-- LOAD_FILE returns a BINARY string (or NULL if the file is unreadable, outside
-- secure_file_priv, larger than max_allowed_packet, or the account lacks FILE).
-- JSON functions reject binary strings, so convert to utf8mb4 explicitly.
SET @rr_tasks_json = CONVERT(LOAD_FILE(@rr_tasks_path) USING utf8mb4);
SET @rr_users_json = CONVERT(LOAD_FILE(@rr_users_path) USING utf8mb4);

SELECT @@version AS `server_version`,
       @@secure_file_priv AS `secure_file_priv`,
       @@max_allowed_packet AS `max_allowed_packet`,
       @rr_tasks_json IS NOT NULL AS `tasks_file_loaded`,
       LENGTH(@rr_tasks_json) AS `tasks_file_bytes`,
       @rr_users_json IS NOT NULL AS `users_file_loaded`,
       LENGTH(@rr_users_json) AS `users_file_bytes`;

DROP TEMPORARY TABLE IF EXISTS `_rr_migration_guard`;
DROP TEMPORARY TABLE IF EXISTS `_rr_commit_guard`;
DROP TEMPORARY TABLE IF EXISTS `_rr_checks`;
DROP TEMPORARY TABLE IF EXISTS `_rr_stage_tasks`;
DROP TEMPORARY TABLE IF EXISTS `_rr_stage_users`;

-- A row can be inserted here only when ok = 1; a failed check therefore raises an
-- error and stops Workbench. Permanent INSERTs are also gated on this row, so a
-- client that continues after an error still cannot write partial data.
CREATE TEMPORARY TABLE `_rr_migration_guard` (
    `ok` TINYINT NOT NULL,
    CONSTRAINT `rr_preflight_all_checks_passed` CHECK (`ok` = 1)
) ENGINE=InnoDB;

CREATE TEMPORARY TABLE `_rr_commit_guard` (
    `ok` TINYINT NOT NULL,
    CONSTRAINT `rr_postinsert_all_checks_passed` CHECK (`ok` = 1)
) ENGINE=InnoDB;

CREATE TEMPORARY TABLE `_rr_checks` (
    `phase` VARCHAR(12) NOT NULL,
    `check_name` VARCHAR(80) NOT NULL,
    `expected` VARCHAR(80) NULL,
    `actual` VARCHAR(80) NULL,
    `passed` TINYINT AS (IF(`actual` <=> `expected`, 1, 0)) STORED,
    PRIMARY KEY (`phase`, `check_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ---------------------------------------------------------------------------
-- 1. Stage users. users.json has no numeric IDs: username is the identity.
--    `active` mirrors auth.is_active(): missing -> active (1); only false -> 0.
-- ---------------------------------------------------------------------------
CREATE TEMPORARY TABLE `_rr_stage_users` (
    `ord` INT UNSIGNED NOT NULL,
    `username` VARCHAR(30) NOT NULL PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `role` VARCHAR(20) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `active` TINYINT NULL,
    `deactivated_at` VARCHAR(40) NULL,
    `deactivated_by` VARCHAR(30) NULL,
    `type_ok` TINYINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `_rr_stage_users`
    (`ord`, `username`, `name`, `role`, `password_hash`,
     `active`, `deactivated_at`, `deactivated_by`, `type_ok`)
SELECT j.`ord`, j.`username`, j.`name`, j.`role`, j.`password_hash`,
       CASE
           WHEN j.`active_j` IS NULL OR JSON_TYPE(j.`active_j`) = 'NULL' THEN 1
           WHEN JSON_TYPE(j.`active_j`) = 'BOOLEAN'
               THEN IF(CAST(j.`active_j` AS CHAR) = 'false', 0, 1)
           ELSE NULL
       END,
       IF(j.`deact_at_j` IS NULL OR JSON_TYPE(j.`deact_at_j`) = 'NULL',
          NULL, JSON_UNQUOTE(j.`deact_at_j`)),
       IF(j.`deact_by_j` IS NULL OR JSON_TYPE(j.`deact_by_j`) = 'NULL',
          NULL, JSON_UNQUOTE(j.`deact_by_j`)),
       IF((j.`active_j` IS NULL OR JSON_TYPE(j.`active_j`) IN ('NULL', 'BOOLEAN'))
          AND (j.`deact_at_j` IS NULL OR JSON_TYPE(j.`deact_at_j`) IN ('NULL', 'STRING'))
          AND (j.`deact_by_j` IS NULL OR JSON_TYPE(j.`deact_by_j`) IN ('NULL', 'STRING')),
          1, 0)
FROM JSON_TABLE(@rr_users_json, '$[*]' COLUMNS (
    `ord` FOR ORDINALITY,
    `username` VARCHAR(30) PATH '$.username' ERROR ON EMPTY ERROR ON ERROR,
    `name` VARCHAR(100) PATH '$.name' ERROR ON EMPTY ERROR ON ERROR,
    `role` VARCHAR(20) PATH '$.role' ERROR ON EMPTY ERROR ON ERROR,
    `password_hash` VARCHAR(255) PATH '$.password_hash' ERROR ON EMPTY ERROR ON ERROR,
    `active_j` JSON PATH '$.active' NULL ON EMPTY,
    `deact_at_j` JSON PATH '$.deactivated_at' NULL ON EMPTY,
    `deact_by_j` JSON PATH '$.deactivated_by' NULL ON EMPTY
)) AS j;

-- ---------------------------------------------------------------------------
-- 2. Stage tasks. IDs are preserved exactly. `done` is a JSON boolean in the
--    source and is preserved as-is (it is NOT derived from status).
--    submitted_by / _import_id may be JSON null or missing -> SQL NULL.
-- ---------------------------------------------------------------------------
CREATE TEMPORARY TABLE `_rr_stage_tasks` (
    `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `title` VARCHAR(200) NOT NULL,
    `status` VARCHAR(20) NOT NULL,
    `done` TINYINT NULL,
    `time` VARCHAR(20) NOT NULL,
    `submitted_at` VARCHAR(40) NOT NULL,
    `submitted_at_utc` DATETIME(6) NULL,
    `submitted_by` VARCHAR(100) NULL,
    `_import_id` VARCHAR(64) NULL,
    `type_ok` TINYINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `_rr_stage_tasks`
    (`id`, `name`, `title`, `status`, `done`, `time`, `submitted_at`,
     `submitted_at_utc`, `submitted_by`, `_import_id`, `type_ok`)
SELECT j.`id`, j.`name`, j.`title`, j.`status`,
       CASE
           WHEN JSON_TYPE(j.`done_j`) = 'BOOLEAN'
               THEN IF(CAST(j.`done_j` AS CHAR) = 'true', 1, 0)
           WHEN JSON_TYPE(j.`done_j`) = 'INTEGER' AND CAST(j.`done_j` AS CHAR) IN ('0', '1')
               THEN CAST(CAST(j.`done_j` AS CHAR) AS UNSIGNED)
           ELSE NULL
       END,
       j.`time`, j.`submitted_at`,
       -- Normalized UTC copy of the exact source text (which is kept unchanged).
       -- Only ISO-8601 values with an explicit +HH:MM/-HH:MM offset are converted.
       CASE
           WHEN j.`submitted_at` REGEXP
                '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}([.][0-9]{1,6})?[+-][0-9]{2}:[0-9]{2}$'
           THEN CONVERT_TZ(
                    CAST(REPLACE(LEFT(j.`submitted_at`, CHAR_LENGTH(j.`submitted_at`) - 6), 'T', ' ')
                         AS DATETIME(6)),
                    RIGHT(j.`submitted_at`, 6), '+00:00')
           ELSE NULL
       END,
       IF(j.`sb_j` IS NULL OR JSON_TYPE(j.`sb_j`) = 'NULL', NULL, JSON_UNQUOTE(j.`sb_j`)),
       IF(j.`imp_j` IS NULL OR JSON_TYPE(j.`imp_j`) = 'NULL', NULL, JSON_UNQUOTE(j.`imp_j`)),
       IF(JSON_TYPE(j.`done_j`) IN ('BOOLEAN', 'INTEGER')
          AND (j.`sb_j` IS NULL OR JSON_TYPE(j.`sb_j`) IN ('NULL', 'STRING'))
          AND (j.`imp_j` IS NULL OR JSON_TYPE(j.`imp_j`) IN ('NULL', 'STRING')),
          1, 0)
FROM JSON_TABLE(@rr_tasks_json, '$[*]' COLUMNS (
    `id` BIGINT UNSIGNED PATH '$.id' ERROR ON EMPTY ERROR ON ERROR,
    `name` VARCHAR(100) PATH '$.name' ERROR ON EMPTY ERROR ON ERROR,
    `title` VARCHAR(200) PATH '$.title' ERROR ON EMPTY ERROR ON ERROR,
    `status` VARCHAR(20) PATH '$.status' ERROR ON EMPTY ERROR ON ERROR,
    `done_j` JSON PATH '$.done' ERROR ON EMPTY,
    `time` VARCHAR(20) PATH '$.time' ERROR ON EMPTY ERROR ON ERROR,
    `submitted_at` VARCHAR(40) PATH '$.submitted_at' ERROR ON EMPTY ERROR ON ERROR,
    `sb_j` JSON PATH '$.submitted_by' NULL ON EMPTY,
    `imp_j` JSON PATH '$._import_id' NULL ON EMPTY
)) AS j;

-- ---------------------------------------------------------------------------
-- 3. Pre-flight checks (read-only). One statement per staging-table reference.
-- ---------------------------------------------------------------------------
INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`) VALUES
    ('preflight', 'tasks_file_sha256', @rr_expected_tasks_sha256, SHA2(@rr_tasks_json, 256)),
    ('preflight', 'users_file_sha256', @rr_expected_users_sha256, SHA2(@rr_users_json, 256)),
    ('preflight', 'tasks_json_valid_array', 'ARRAY',
        IF(JSON_VALID(@rr_tasks_json) = 1, JSON_TYPE(@rr_tasks_json), 'INVALID')),
    ('preflight', 'users_json_valid_array', 'ARRAY',
        IF(JSON_VALID(@rr_users_json) = 1, JSON_TYPE(@rr_users_json), 'INVALID')),
    ('preflight', 'tasks_json_length', @rr_expected_tasks,
        IF(JSON_VALID(@rr_tasks_json) = 1, JSON_LENGTH(@rr_tasks_json), NULL)),
    ('preflight', 'users_json_length', @rr_expected_users,
        IF(JSON_VALID(@rr_users_json) = 1, JSON_LENGTH(@rr_users_json), NULL));

-- Schema compatibility: CREATE TABLE IF NOT EXISTS never verifies existing tables.
INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'schema_users_columns', '8', COUNT(*)
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users'
  AND COLUMN_NAME IN ('user_id', 'username', 'name', 'password_hash', 'role',
                      'active', 'deactivated_at', 'deactivated_by');
INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'schema_employees_columns', '4', COUNT(*)
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'employees'
  AND COLUMN_NAME IN ('employee_id', 'user_id', 'name', 'normalized_name');
INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'schema_tasks_columns', '12', COUNT(*)
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tasks'
  AND COLUMN_NAME IN ('id', 'employee_id', 'name', 'title', 'status', 'done', 'time',
                      'submitted_at', 'submitted_at_utc', 'submitted_by',
                      'submitted_by_user_id', '_import_id');

INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'stage_users_rows|distinct|valid', CONCAT_WS('|', @rr_expected_users, @rr_expected_users, @rr_expected_users),
       CONCAT_WS('|', COUNT(*), COUNT(DISTINCT BINARY `username`),
                 SUM(`role` IN ('admin', 'user') AND `active` IS NOT NULL AND `type_ok` = 1))
FROM `_rr_stage_users`;

INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'stage_tasks_rows|distinct_ids|valid',
       CONCAT_WS('|', @rr_expected_tasks, @rr_expected_tasks, @rr_expected_tasks),
       CONCAT_WS('|', COUNT(*), COUNT(DISTINCT `id`),
                 SUM(BINARY `status` IN ('pending', 'completed') AND `done` IN (0, 1)
                     AND `type_ok` = 1 AND `id` > 0))
FROM `_rr_stage_tasks`;

INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'stage_completed|pending', CONCAT_WS('|', @rr_expected_completed, @rr_expected_pending),
       CONCAT_WS('|', SUM(BINARY `status` = 'completed'), SUM(BINARY `status` = 'pending'))
FROM `_rr_stage_tasks`;

-- Conflicts: an existing row with the same key but different data. Never overwritten.
INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'conflicting_existing_users', '0', COUNT(*)
FROM `_rr_stage_users` s
JOIN `users` u ON u.`username` = s.`username`        -- case-insensitive on purpose
WHERE BINARY u.`username` <> BINARY s.`username`
   OR BINARY u.`name` <> BINARY s.`name`
   OR BINARY u.`role` <> BINARY s.`role`
   OR BINARY u.`password_hash` <> BINARY s.`password_hash`
   OR NOT (u.`active` <=> s.`active`)
   OR NOT (BINARY u.`deactivated_at` <=> BINARY s.`deactivated_at`)
   OR NOT (BINARY u.`deactivated_by` <=> BINARY s.`deactivated_by`);

INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'preflight', 'conflicting_existing_tasks', '0', COUNT(*)
FROM `_rr_stage_tasks` s
JOIN `tasks` t ON t.`id` = s.`id`
WHERE BINARY t.`name` <> BINARY s.`name`
   OR BINARY t.`title` <> BINARY s.`title`
   OR BINARY t.`status` <> BINARY s.`status`
   OR NOT (t.`done` <=> s.`done`)
   OR BINARY t.`time` <> BINARY s.`time`
   OR BINARY t.`submitted_at` <> BINARY s.`submitted_at`
   OR NOT (BINARY t.`submitted_by` <=> BINARY s.`submitted_by`)
   OR NOT (BINARY t.`_import_id` <=> BINARY s.`_import_id`);

SELECT `phase`, `check_name`, `expected`, `actual`, IF(`passed` = 1, 'PASS', 'FAIL') AS `result`
FROM `_rr_checks` ORDER BY `passed`, `check_name`;

-- Informational (not a failure): rows already present and identical will be skipped.
SELECT (SELECT COUNT(*) FROM `users`) AS `existing_users_before`,
       (SELECT COUNT(*) FROM `tasks`) AS `existing_tasks_before`,
       (SELECT COUNT(*) FROM `employees`) AS `existing_employees_before`;

-- HARD STOP if any pre-flight check failed: raises ERROR 3819
-- "Check constraint 'rr_preflight_all_checks_passed' is violated." Nothing written.
INSERT INTO `_rr_migration_guard` (`ok`)
SELECT IF(COUNT(*) = 14 AND SUM(`passed`) = 14, 1, 0) FROM `_rr_checks` WHERE `phase` = 'preflight';

SELECT 'READY - all pre-flight checks passed' AS `preflight_status`;

-- ---------------------------------------------------------------------------
-- 4. Insert (only rows whose key is not already present). No UPDATE / DELETE.
-- ---------------------------------------------------------------------------
START TRANSACTION;

-- user_id is AUTO_INCREMENT; insert in users.json order for deterministic IDs.
INSERT INTO `users` (`username`, `name`, `password_hash`, `role`,
                     `active`, `deactivated_at`, `deactivated_by`)
SELECT s.`username`, s.`name`, s.`password_hash`, s.`role`,
       s.`active`, s.`deactivated_at`, s.`deactivated_by`
FROM `_rr_stage_users` s
WHERE NOT EXISTS (SELECT 1 FROM `users` u WHERE u.`username` = s.`username`)
  AND EXISTS (SELECT 1 FROM `_rr_migration_guard`)
ORDER BY s.`ord`;

-- Employee identity is not explicit in the JSON: one employee row per exact
-- (case-sensitive) display name; tasks keep their own name snapshot.
-- (Derived-table joins instead of per-row correlated subqueries: the exact-case
-- name match cannot use an index, and the correlated form takes ~2 minutes,
-- exceeding Workbench's default 30-second read timeout.)
INSERT INTO `employees` (`name`, `normalized_name`)
SELECT s.`name`, LOWER(TRIM(s.`name`))
FROM `_rr_stage_tasks` s
LEFT JOIN (SELECT DISTINCT CAST(e.`name` AS BINARY) AS `bname` FROM `employees` e) ex
       ON ex.`bname` = CAST(s.`name` AS BINARY)
WHERE ex.`bname` IS NULL
  AND EXISTS (SELECT 1 FROM `_rr_migration_guard`)
GROUP BY BINARY s.`name`, s.`name`
ORDER BY MIN(s.`id`);

-- Duplicate employee/title combinations are intentionally preserved (one row per id).
INSERT INTO `tasks` (
    `id`, `employee_id`, `name`, `title`, `status`, `done`, `time`,
    `submitted_at`, `submitted_at_utc`, `submitted_by`,
    `submitted_by_user_id`, `_import_id`
)
SELECT s.`id`, em.`employee_id`,
       s.`name`, s.`title`, s.`status`, s.`done`, s.`time`,
       s.`submitted_at`, s.`submitted_at_utc`, s.`submitted_by`,
       us.`user_id`, s.`_import_id`
FROM `_rr_stage_tasks` s
LEFT JOIN (SELECT CAST(e.`name` AS BINARY) AS `bname`, MIN(e.`employee_id`) AS `employee_id`
           FROM `employees` e GROUP BY CAST(e.`name` AS BINARY)) em
       ON em.`bname` = CAST(s.`name` AS BINARY)
LEFT JOIN (SELECT CAST(u.`username` AS BINARY) AS `buser`, MIN(u.`user_id`) AS `user_id`
           FROM `users` u GROUP BY CAST(u.`username` AS BINARY)) us
       ON us.`buser` = CAST(s.`submitted_by` AS BINARY)
WHERE NOT EXISTS (SELECT 1 FROM `tasks` t WHERE t.`id` = s.`id`)
  AND EXISTS (SELECT 1 FROM `_rr_migration_guard`)
ORDER BY s.`id`;

-- ---------------------------------------------------------------------------
-- 5. Post-insert checks INSIDE the transaction (before COMMIT).
-- ---------------------------------------------------------------------------
INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'postinsert', 'users_identical_in_mysql', @rr_expected_users, COUNT(*)
FROM `_rr_stage_users` s
JOIN `users` u ON BINARY u.`username` = BINARY s.`username`
WHERE BINARY u.`name` = BINARY s.`name`
  AND BINARY u.`role` = BINARY s.`role`
  AND BINARY u.`password_hash` = BINARY s.`password_hash`
  AND u.`active` <=> s.`active`
  AND BINARY u.`deactivated_at` <=> BINARY s.`deactivated_at`
  AND BINARY u.`deactivated_by` <=> BINARY s.`deactivated_by`;

INSERT INTO `_rr_checks` (`phase`, `check_name`, `expected`, `actual`)
SELECT 'postinsert', 'tasks_identical|employee_linked|submitter_linked',
       CONCAT_WS('|', @rr_expected_tasks, @rr_expected_tasks, @rr_expected_tasks),
       CONCAT_WS('|',
           COUNT(*),
           SUM(t.`employee_id` IS NOT NULL),
           SUM(s.`submitted_by` IS NULL OR t.`submitted_by_user_id` IS NOT NULL))
FROM `_rr_stage_tasks` s
JOIN `tasks` t ON t.`id` = s.`id`
WHERE BINARY t.`name` = BINARY s.`name`
  AND BINARY t.`title` = BINARY s.`title`
  AND BINARY t.`status` = BINARY s.`status`
  AND t.`done` <=> s.`done`
  AND BINARY t.`time` = BINARY s.`time`
  AND BINARY t.`submitted_at` = BINARY s.`submitted_at`
  AND BINARY t.`submitted_by` <=> BINARY s.`submitted_by`
  AND BINARY t.`_import_id` <=> BINARY s.`_import_id`;

SELECT `phase`, `check_name`, `expected`, `actual`, IF(`passed` = 1, 'PASS', 'FAIL') AS `result`
FROM `_rr_checks` WHERE `phase` = 'postinsert' ORDER BY `check_name`;

-- HARD STOP before COMMIT if anything is wrong: raises ERROR 3819
-- "Check constraint 'rr_postinsert_all_checks_passed' is violated."
-- If you see it: run ROLLBACK; (nothing has been committed).
INSERT INTO `_rr_commit_guard` (`ok`)
SELECT IF(COUNT(*) = 2 AND SUM(`passed`) = 2, 1, 0) FROM `_rr_checks` WHERE `phase` = 'postinsert';

COMMIT;

SELECT 'COMMITTED' AS `migration_status`,
       (SELECT COUNT(*) FROM `users`) AS `mysql_user_rows`,
       (SELECT COUNT(*) FROM `tasks`) AS `mysql_task_rows`,
       (SELECT COUNT(*) FROM `employees`) AS `mysql_employee_rows`;

DROP TEMPORARY TABLE IF EXISTS `_rr_migration_guard`;
DROP TEMPORARY TABLE IF EXISTS `_rr_commit_guard`;
DROP TEMPORARY TABLE IF EXISTS `_rr_checks`;
DROP TEMPORARY TABLE IF EXISTS `_rr_stage_tasks`;
DROP TEMPORARY TABLE IF EXISTS `_rr_stage_users`;
