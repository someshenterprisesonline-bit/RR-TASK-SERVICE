-- RR TASK SERVICE task CRUD procedures for MySQL 8.0
-- This file only defines routines. It contains no CALL statements and performs
-- no task CRUD when installed. sp_delete_task deletes only when explicitly called.
-- There are no DROP statements. Existing routine definitions are left unchanged.
-- Each routine owns its transaction; do not wrap CALLs in another transaction.
-- IF NOT EXISTS requires MySQL 8.0.29 or later; check the exact server version.
-- sp_get_tasks below is the v2 definition (exact Python sort/filter parity). To upgrade an
-- existing database whose sp_get_tasks predates it, use mysql_sp_get_tasks_v2.sql.

USE `rr_task_service`;

DELIMITER $$

CREATE PROCEDURE IF NOT EXISTS `sp_add_task`(
    IN p_task_id BIGINT UNSIGNED,
    IN p_employee_id BIGINT UNSIGNED,
    IN p_name VARCHAR(100),
    IN p_title VARCHAR(200),
    IN p_status VARCHAR(20),
    IN p_done TINYINT,
    IN p_time VARCHAR(20),
    IN p_submitted_at VARCHAR(40),
    IN p_submitted_at_utc DATETIME(6),
    IN p_submitted_by VARCHAR(100),
    IN p_submitted_by_user_id BIGINT UNSIGNED,
    IN p_import_id VARCHAR(64)
)
SQL SECURITY INVOKER
MODIFIES SQL DATA
BEGIN
    DECLARE v_status VARCHAR(20);
    DECLARE v_new_task_id BIGINT UNSIGNED;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SET v_status = LOWER(TRIM(p_status));
    IF p_task_id = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Task ID must be positive or NULL';
    END IF;
    IF p_name IS NULL OR CHAR_LENGTH(TRIM(p_name)) = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Employee name is required';
    END IF;
    IF p_title IS NULL OR CHAR_LENGTH(TRIM(p_title)) = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Task title is required';
    END IF;
    IF v_status IS NULL OR v_status NOT IN ('pending', 'completed') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Status must be pending or completed';
    END IF;
    IF p_done IS NULL OR p_done NOT IN (0, 1) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Legacy done value must be supplied as 0 or 1';
    END IF;
    IF p_submitted_at IS NULL OR CHAR_LENGTH(TRIM(p_submitted_at)) = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Source submission timestamp is required';
    END IF;

    -- No employee-name/title uniqueness check: repeated pairs are valid records.
    IF p_task_id IS NULL THEN
        INSERT INTO `tasks` (
            `employee_id`, `name`, `title`, `status`, `done`, `time`,
            `submitted_at`, `submitted_at_utc`, `submitted_by`,
            `submitted_by_user_id`, `_import_id`
        ) VALUES (
            p_employee_id, TRIM(p_name), TRIM(p_title), TRIM(p_status), p_done,
            COALESCE(p_time, ''), p_submitted_at, p_submitted_at_utc,
            p_submitted_by, p_submitted_by_user_id, p_import_id
        );
        SET v_new_task_id = LAST_INSERT_ID();
    ELSE
        INSERT INTO `tasks` (
            `id`, `employee_id`, `name`, `title`, `status`, `done`, `time`,
            `submitted_at`, `submitted_at_utc`, `submitted_by`,
            `submitted_by_user_id`, `_import_id`
        ) VALUES (
            p_task_id, p_employee_id, TRIM(p_name), TRIM(p_title), TRIM(p_status),
            p_done, COALESCE(p_time, ''), p_submitted_at, p_submitted_at_utc,
            p_submitted_by, p_submitted_by_user_id, p_import_id
        );
        SET v_new_task_id = p_task_id;
    END IF;

    COMMIT;
    SELECT v_new_task_id AS `id`;
END$$

CREATE PROCEDURE IF NOT EXISTS `sp_get_tasks`(
    IN p_query VARCHAR(200),
    IN p_status VARCHAR(20),
    IN p_sort VARCHAR(20),
    IN p_offset INT UNSIGNED,
    IN p_limit INT UNSIGNED
)
SQL SECURITY INVOKER
READS SQL DATA
BEGIN
    DECLARE v_status VARCHAR(20);
    DECLARE v_sort VARCHAR(20);
    DECLARE v_query VARCHAR(200);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SET v_status = LOWER(TRIM(p_status));
    SET v_sort = LOWER(TRIM(p_sort));
    SET v_query = LOWER(TRIM(COALESCE(p_query, '')));
    IF v_status IS NULL OR v_status NOT IN ('all', 'pending', 'completed') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid task status filter';
    END IF;
    IF v_sort IS NULL OR v_sort NOT IN ('newest', 'oldest', 'name', 'task') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid task sort option';
    END IF;
    IF p_offset IS NULL OR p_limit IS NULL OR p_limit < 1 OR p_limit > 200 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Use offset >= 0 and limit between 1 and 200';
    END IF;

    -- Count and page results share a read-only transaction snapshot.
    START TRANSACTION READ ONLY;

    SELECT
        COUNT(*) AS `total`,
        (SELECT COUNT(*) FROM `tasks`) AS `all_total`
    FROM `tasks` AS t
    WHERE (v_status = 'all'
           OR LOWER(t.`status`) COLLATE utf8mb4_0900_bin = v_status COLLATE utf8mb4_0900_bin)
      AND (
          v_query = ''
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`name`) COLLATE utf8mb4_0900_bin) > 0
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`title`) COLLATE utf8mb4_0900_bin) > 0
      );

    SELECT
        t.`id`, t.`employee_id`, t.`name`, t.`title`, t.`status`, t.`done`,
        t.`time`, t.`submitted_at`, t.`submitted_at_utc`, t.`submitted_by`,
        t.`submitted_by_user_id`, t.`_import_id`
    FROM `tasks` AS t
    WHERE (v_status = 'all'
           OR LOWER(t.`status`) COLLATE utf8mb4_0900_bin = v_status COLLATE utf8mb4_0900_bin)
      AND (
          v_query = ''
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`name`) COLLATE utf8mb4_0900_bin) > 0
          OR LOCATE(v_query COLLATE utf8mb4_0900_bin, LOWER(t.`title`) COLLATE utf8mb4_0900_bin) > 0
      )
    ORDER BY
        CASE WHEN v_sort = 'name' THEN LOWER(t.`name`) COLLATE utf8mb4_0900_bin END ASC,
        CASE WHEN v_sort = 'task' THEN LOWER(t.`title`) COLLATE utf8mb4_0900_bin END ASC,
        CASE WHEN v_sort = 'newest' THEN t.`id` END DESC,
        t.`id` ASC
    LIMIT p_offset, p_limit;

    COMMIT;
END$$

CREATE PROCEDURE IF NOT EXISTS `sp_get_task_by_id`(
    IN p_task_id BIGINT UNSIGNED
)
SQL SECURITY INVOKER
READS SQL DATA
BEGIN
    IF p_task_id IS NULL OR p_task_id = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A positive task ID is required';
    END IF;

    SELECT
        `id`, `employee_id`, `name`, `title`, `status`, `done`, `time`,
        `submitted_at`, `submitted_at_utc`, `submitted_by`,
        `submitted_by_user_id`, `_import_id`
    FROM `tasks`
    WHERE `id` = p_task_id;
END$$

CREATE PROCEDURE IF NOT EXISTS `sp_update_task`(
    IN p_task_id BIGINT UNSIGNED,
    IN p_employee_id BIGINT UNSIGNED,
    IN p_name VARCHAR(100),
    IN p_title VARCHAR(200),
    IN p_status VARCHAR(20),
    IN p_time VARCHAR(20),
    IN p_done TINYINT
)
SQL SECURITY INVOKER
MODIFIES SQL DATA
BEGIN
    DECLARE v_found_id BIGINT UNSIGNED DEFAULT NULL;
    DECLARE v_status VARCHAR(20);

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_found_id = NULL;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SET v_status = LOWER(TRIM(p_status));
    IF p_task_id IS NULL OR p_task_id = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A positive task ID is required';
    END IF;
    IF p_name IS NULL OR CHAR_LENGTH(TRIM(p_name)) = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Employee name is required';
    END IF;
    IF p_title IS NULL OR CHAR_LENGTH(TRIM(p_title)) = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Task title is required';
    END IF;
    IF v_status IS NULL OR v_status NOT IN ('pending', 'completed') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Status must be pending or completed';
    END IF;
    IF p_done IS NOT NULL AND p_done NOT IN (0, 1) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Legacy done value must be 0, 1, or NULL';
    END IF;

    SELECT `id` INTO v_found_id
    FROM `tasks`
    WHERE `id` = p_task_id
    FOR UPDATE;
    IF v_found_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Task not found';
    END IF;

    UPDATE `tasks`
    SET `employee_id` = p_employee_id,
        `name` = TRIM(p_name),
        `title` = TRIM(p_title),
        `status` = TRIM(p_status),
        `time` = COALESCE(p_time, `time`),
        `done` = COALESCE(p_done, `done`)
    WHERE `id` = p_task_id;

    COMMIT;
    SELECT p_task_id AS `id`;
END$$

CREATE PROCEDURE IF NOT EXISTS `sp_delete_task`(
    IN p_task_id BIGINT UNSIGNED
)
SQL SECURITY INVOKER
MODIFIES SQL DATA
BEGIN
    DECLARE v_found_id BIGINT UNSIGNED DEFAULT NULL;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_found_id = NULL;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF p_task_id IS NULL OR p_task_id = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A positive task ID is required';
    END IF;

    SELECT `id` INTO v_found_id
    FROM `tasks`
    WHERE `id` = p_task_id
    FOR UPDATE;
    IF v_found_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Task not found';
    END IF;

    DELETE FROM `tasks` WHERE `id` = p_task_id;

    COMMIT;
    SELECT p_task_id AS `deleted_id`;
END$$

DELIMITER ;
