-- RR TASK SERVICE post-migration verification (READ-ONLY: SELECT statements only).
-- Compares the safe JSON copies in secure_file_priv with rr_task_service.
-- Never displays password hashes (they are only compared).
-- Every row of the final summary should read PASS.

USE `rr_task_service`;
SET NAMES utf8mb4;
-- Read live table statistics (e.g. AUTO_INCREMENT) instead of values cached for up to
-- 24 h by information_schema_stats_expiry. Session-only; changes no data.
SET SESSION information_schema_stats_expiry = 0;

SET @rr_tasks_path = 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/rr_task_service_tasks.json';
SET @rr_users_path = 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/rr_task_service_users.json';
-- LOAD_FILE returns a binary string; JSON functions need a character string.
SET @rr_tasks_json = CONVERT(LOAD_FILE(@rr_tasks_path) USING utf8mb4);
SET @rr_users_json = CONVERT(LOAD_FILE(@rr_users_path) USING utf8mb4);

-- 1. Files loaded? (If NULL: path, FILE privilege, secure_file_priv or size problem.)
SELECT @rr_tasks_json IS NOT NULL AS `tasks_file_loaded`,
       SHA2(@rr_tasks_json, 256) AS `tasks_file_sha256`,
       @rr_users_json IS NOT NULL AS `users_file_loaded`,
       SHA2(@rr_users_json, 256) AS `users_file_sha256`;

-- 2. Totals.
SELECT JSON_LENGTH(@rr_tasks_json) AS `json_task_count`,
       (SELECT COUNT(*) FROM `tasks`) AS `mysql_task_count`,
       (SELECT COUNT(DISTINCT `id`) FROM `tasks`) AS `mysql_unique_task_ids`,
       (SELECT MIN(`id`) FROM `tasks`) AS `mysql_min_id`,
       (SELECT MAX(`id`) FROM `tasks`) AS `mysql_max_id`,
       JSON_LENGTH(@rr_users_json) AS `json_user_count`,
       (SELECT COUNT(*) FROM `users`) AS `mysql_user_count`,
       (SELECT COUNT(*) FROM `employees`) AS `mysql_employee_count`;

-- 3. Status and legacy done distribution (done is preserved, not derived from status).
SELECT j.`status`, j.`done_text`, COUNT(*) AS `json_count`
FROM JSON_TABLE(@rr_tasks_json, '$[*]' COLUMNS (
    `status` VARCHAR(20) PATH '$.status',
    `done_text` VARCHAR(10) PATH '$.done'
)) AS j
GROUP BY j.`status`, j.`done_text` ORDER BY j.`status`, j.`done_text`;
SELECT `status`, `done`, COUNT(*) AS `mysql_count`
FROM `tasks` GROUP BY `status`, `done` ORDER BY `status`, `done`;

-- 4. Import batches (_import_id is a per-import batch ID, not unique per task).
SELECT `_import_id`, COUNT(*) AS `mysql_count`
FROM `tasks` GROUP BY `_import_id` ORDER BY `_import_id`;

-- 5. Users: active / deactivated state (no password hashes shown).
SELECT `user_id`, `username`, `name`, `role`, `active`, `deactivated_at`, `deactivated_by`
FROM `users` ORDER BY `user_id`;

-- 6. Summary of integrity checks. Every row should read PASS.
WITH
jt AS (
    SELECT j.`id`, j.`name`, j.`title`, j.`status`, j.`time`, j.`submitted_at`,
           CASE WHEN JSON_TYPE(j.`done_j`) = 'BOOLEAN'
                    THEN IF(CAST(j.`done_j` AS CHAR) = 'true', 1, 0)
                WHEN JSON_TYPE(j.`done_j`) = 'INTEGER'
                    THEN CAST(CAST(j.`done_j` AS CHAR) AS SIGNED)
           END AS `done`,
           IF(j.`sb_j` IS NULL OR JSON_TYPE(j.`sb_j`) = 'NULL', NULL, JSON_UNQUOTE(j.`sb_j`)) AS `submitted_by`,
           IF(j.`imp_j` IS NULL OR JSON_TYPE(j.`imp_j`) = 'NULL', NULL, JSON_UNQUOTE(j.`imp_j`)) AS `import_id`
    FROM JSON_TABLE(@rr_tasks_json, '$[*]' COLUMNS (
        `id` BIGINT UNSIGNED PATH '$.id',
        `name` VARCHAR(100) PATH '$.name',
        `title` VARCHAR(200) PATH '$.title',
        `status` VARCHAR(20) PATH '$.status',
        `done_j` JSON PATH '$.done',
        `time` VARCHAR(20) PATH '$.time',
        `submitted_at` VARCHAR(40) PATH '$.submitted_at',
        `sb_j` JSON PATH '$.submitted_by' NULL ON EMPTY,
        `imp_j` JSON PATH '$._import_id' NULL ON EMPTY
    )) AS j
),
ju AS (
    SELECT j.`username`, j.`name`, j.`role`, j.`password_hash`,
           CASE WHEN j.`active_j` IS NULL OR JSON_TYPE(j.`active_j`) = 'NULL' THEN 1
                WHEN JSON_TYPE(j.`active_j`) = 'BOOLEAN'
                    THEN IF(CAST(j.`active_j` AS CHAR) = 'false', 0, 1)
           END AS `active`,
           IF(j.`da_j` IS NULL OR JSON_TYPE(j.`da_j`) = 'NULL', NULL, JSON_UNQUOTE(j.`da_j`)) AS `deactivated_at`,
           IF(j.`db_j` IS NULL OR JSON_TYPE(j.`db_j`) = 'NULL', NULL, JSON_UNQUOTE(j.`db_j`)) AS `deactivated_by`
    FROM JSON_TABLE(@rr_users_json, '$[*]' COLUMNS (
        `username` VARCHAR(30) PATH '$.username',
        `name` VARCHAR(100) PATH '$.name',
        `role` VARCHAR(20) PATH '$.role',
        `password_hash` VARCHAR(255) PATH '$.password_hash',
        `active_j` JSON PATH '$.active' NULL ON EMPTY,
        `da_j` JSON PATH '$.deactivated_at' NULL ON EMPTY,
        `db_j` JSON PATH '$.deactivated_by' NULL ON EMPTY
    )) AS j
),
checks AS (
    SELECT 'json_files_loaded' AS `check_name`, '1' AS `expected`,
           CAST(@rr_tasks_json IS NOT NULL AND @rr_users_json IS NOT NULL AS CHAR) AS `actual`
    UNION ALL SELECT 'task_count_json_vs_mysql', CAST((SELECT COUNT(*) FROM jt) AS CHAR),
           CAST((SELECT COUNT(*) FROM `tasks`) AS CHAR)
    UNION ALL SELECT 'task_count_expected_14004', '14004', CAST((SELECT COUNT(*) FROM `tasks`) AS CHAR)
    UNION ALL SELECT 'completed_expected_8000', '8000',
           CAST((SELECT COUNT(*) FROM `tasks` WHERE BINARY `status` = 'completed') AS CHAR)
    UNION ALL SELECT 'pending_expected_6004', '6004',
           CAST((SELECT COUNT(*) FROM `tasks` WHERE BINARY `status` = 'pending') AS CHAR)
    UNION ALL SELECT 'user_count_expected_9', '9', CAST((SELECT COUNT(*) FROM `users`) AS CHAR)
    UNION ALL SELECT 'json_task_ids_missing_in_mysql', '0',
           CAST((SELECT COUNT(*) FROM jt LEFT JOIN `tasks` t ON t.`id` = jt.`id` WHERE t.`id` IS NULL) AS CHAR)
    UNION ALL SELECT 'mysql_task_ids_missing_in_json', '0',
           CAST((SELECT COUNT(*) FROM `tasks` t WHERE NOT EXISTS (SELECT 1 FROM jt WHERE jt.`id` = t.`id`)) AS CHAR)
    UNION ALL SELECT 'task_payload_mismatches', '0',
           CAST((SELECT COUNT(*) FROM jt JOIN `tasks` t ON t.`id` = jt.`id`
                 WHERE BINARY t.`name` <> BINARY jt.`name`
                    OR BINARY t.`title` <> BINARY jt.`title`
                    OR BINARY t.`status` <> BINARY jt.`status`
                    OR NOT (t.`done` <=> jt.`done`)
                    OR BINARY t.`time` <> BINARY jt.`time`
                    OR BINARY t.`submitted_at` <> BINARY jt.`submitted_at`
                    OR NOT (BINARY t.`submitted_by` <=> BINARY jt.`submitted_by`)
                    OR NOT (BINARY t.`_import_id` <=> BINARY jt.`import_id`)) AS CHAR)
    UNION ALL SELECT 'duplicate_name_title_groups_json_vs_mysql',
           CAST((SELECT COUNT(*) FROM (SELECT 1 FROM jt GROUP BY BINARY jt.`name`, BINARY jt.`title`
                                       HAVING COUNT(*) > 1) d) AS CHAR),
           CAST((SELECT COUNT(*) FROM (SELECT 1 FROM `tasks` GROUP BY BINARY `name`, BINARY `title`
                                       HAVING COUNT(*) > 1) d) AS CHAR)
    UNION ALL SELECT 'tasks_without_employee_link', '0',
           CAST((SELECT COUNT(*) FROM `tasks` WHERE `employee_id` IS NULL) AS CHAR)
    UNION ALL SELECT 'employee_link_name_mismatch', '0',
           CAST((SELECT COUNT(*) FROM `tasks` t JOIN `employees` e ON e.`employee_id` = t.`employee_id`
                 WHERE BINARY e.`name` <> BINARY t.`name`) AS CHAR)
    UNION ALL SELECT 'submitter_not_linked_to_user', '0',
           CAST((SELECT COUNT(*) FROM `tasks` WHERE `submitted_by` IS NOT NULL
                 AND `submitted_by_user_id` IS NULL) AS CHAR)
    UNION ALL SELECT 'submitted_at_utc_missing', '0',
           CAST((SELECT COUNT(*) FROM `tasks` WHERE `submitted_at_utc` IS NULL) AS CHAR)
    UNION ALL SELECT 'submitted_at_utc_disagrees_with_text', '0',
           CAST((SELECT COUNT(*) FROM `tasks`
                 WHERE `submitted_at` LIKE '%+00:00'
                   AND DATE_FORMAT(`submitted_at_utc`, '%Y-%m-%dT%H:%i:%s+00:00') <> `submitted_at`) AS CHAR)
    UNION ALL SELECT 'tasks_auto_increment_above_max_id', '1',
           CAST((SELECT COALESCE(MAX(`id`), 0) FROM `tasks`) <
                (SELECT COALESCE(MAX(`AUTO_INCREMENT`), 1) FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tasks') AS CHAR)
    UNION ALL SELECT 'json_usernames_missing_in_mysql', '0',
           CAST((SELECT COUNT(*) FROM ju LEFT JOIN `users` u ON BINARY u.`username` = BINARY ju.`username`
                 WHERE u.`user_id` IS NULL) AS CHAR)
    UNION ALL SELECT 'mysql_usernames_missing_in_json', '0',
           CAST((SELECT COUNT(*) FROM `users` u
                 WHERE NOT EXISTS (SELECT 1 FROM ju WHERE BINARY ju.`username` = BINARY u.`username`)) AS CHAR)
    UNION ALL SELECT 'user_payload_mismatches_incl_password_hash', '0',
           CAST((SELECT COUNT(*) FROM ju JOIN `users` u ON BINARY u.`username` = BINARY ju.`username`
                 WHERE BINARY u.`name` <> BINARY ju.`name`
                    OR BINARY u.`role` <> BINARY ju.`role`
                    OR BINARY u.`password_hash` <> BINARY ju.`password_hash`
                    OR NOT (u.`active` <=> ju.`active`)
                    OR NOT (BINARY u.`deactivated_at` <=> BINARY ju.`deactivated_at`)
                    OR NOT (BINARY u.`deactivated_by` <=> BINARY ju.`deactivated_by`)) AS CHAR)
    UNION ALL SELECT 'inactive_users_json_vs_mysql',
           CAST((SELECT COUNT(*) FROM ju WHERE ju.`active` = 0) AS CHAR),
           CAST((SELECT COUNT(*) FROM `users` WHERE `active` = 0) AS CHAR)
)
SELECT `check_name`, `expected`, `actual`,
       IF(`actual` <=> `expected`, 'PASS', 'FAIL') AS `result`
FROM checks;
