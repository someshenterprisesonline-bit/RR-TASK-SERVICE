import os

import pytest

import support


@pytest.fixture(scope='session')
def pw_hash():
    support.load_app('json', support.BACKEND / 'tests' / '_unused')   # imports auth for hashing
    return support.password_hash()


@pytest.fixture(autouse=True)
def _guard_environment():
    """Every test must leave the app pointed at the disposable test database."""
    yield
    db_name = os.environ.get('RR_DB_NAME', '')
    assert db_name == '' or db_name.endswith('_test'), f'test left RR_DB_NAME={db_name!r}'


@pytest.fixture
def seeded(tmp_path, pw_hash):
    """Same seed data in temporary JSON files and in the disposable test database."""
    tasks, users = support.seed_tasks(), support.seed_users(pw_hash)
    support.write_json_store(tmp_path, tasks, users)
    support.seed_db(tasks, users)
    return {'dir': tmp_path, 'tasks': tasks, 'users': users}


@pytest.fixture
def mysql_app(seeded):
    return support.load_app('mysql', seeded['dir'])
