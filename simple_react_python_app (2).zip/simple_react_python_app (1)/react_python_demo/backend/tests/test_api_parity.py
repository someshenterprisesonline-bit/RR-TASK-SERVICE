"""Tests 1, 2 and 5: every endpoint, run identically against JSON and MySQL storage.

Each step asserts the expected HTTP status in BOTH modes, then the complete
response logs of the two modes must be identical (after masking values that are
random by design: session tokens, import-preview ids, and the storage name).
"""
import csv
import io
import json

from fastapi.testclient import TestClient

import support

ORIGIN = 'http://127.0.0.1:5173'
START, END = '2026-10-01', '2026-11-07'


def _mask(value, seed_max):
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if key == 'token':
                out[key] = '<token>'
            elif key == 'storage':
                out[key] = '<storage>'
            elif key in ('submitted_date', 'submitted_time') and isinstance(value.get('id'), int) and value['id'] > seed_max:
                out[key] = '<now>'
            else:
                out[key] = _mask(item, seed_max)
        return out
    if isinstance(value, (list, tuple)):
        return [_mask(v, seed_max) for v in value]
    return value


def run_scenario(main, flag_path, seed_tasks):
    client = TestClient(main.app)
    log = []
    seed_max_id = max(t['id'] for t in seed_tasks)
    keys = [main._task_duplicate_key(t['name'], t['title']) for t in seed_tasks]
    unique_task = next(t for t, k in zip(seed_tasks, keys) if keys.count(k) == 1)
    duplicated_task = next(t for t, k in zip(seed_tasks, keys) if keys.count(k) > 1)

    def call(label, method, url, expect, **kwargs):
        response = client.request(method, url, **kwargs)
        assert response.status_code == expect, (label, response.status_code, response.text[:500])
        ctype = response.headers.get('content-type', '')
        if 'json' in ctype:
            body = response.json()
        elif 'csv' in ctype:
            body = list(csv.reader(io.StringIO(response.content.decode('utf-8-sig'))))
            if label.startswith('maint'):      # rows created moments ago carry "now" timestamps
                body = [row[:4] + ['<now>', '<now>'] + row[6:] for row in body]
        elif 'spreadsheet' in ctype:
            body = support.xlsx_rows(response.content)
        else:
            body = response.text
        log.append((label, response.status_code, ctype.split(';')[0],
                    response.headers.get('content-disposition'), body))
        return response

    def auth(token):
        return {'Authorization': f'Bearer {token}'}

    # ---- public reads ----
    call('health', 'GET', '/api/health', 200)
    call('tasks all', 'GET', '/api/tasks', 200)
    for status in ('all', 'pending', 'completed'):
        for sort in ('newest', 'oldest', 'name', 'task'):
            for q in ('', 'jaga', '  JaGa ', 'report', 'ana', 'emile', 'zzz'):
                for offset in (0, 7):
                    call(f'page {status} {sort} {q!r} {offset}', 'GET',
                         f'/api/tasks?offset={offset}&limit=7&q={q}&status={status}&sort={sort}', 200)
    call('page bad limit', 'GET', '/api/tasks?offset=0&limit=500', 422)
    call('page bad sort', 'GET', '/api/tasks?offset=0&limit=5&sort=random', 422)

    # ---- authentication ----
    call('login wrong password', 'POST', '/api/login', 401, json={'username': 'rithvik', 'password': 'nope-nope'})
    call('login deactivated', 'POST', '/api/login', 401, json={'username': 'oldpf', 'password': support.PASSWORD})
    call('login unknown', 'POST', '/api/login', 401, json={'username': 'ghost', 'password': support.PASSWORD})
    for attempt in range(5):
        call(f'lockout attempt {attempt}', 'POST', '/api/login', 401, json={'username': 'basith', 'password': 'x' * 8})
    call('lockout engaged', 'POST', '/api/login', 429, json={'username': 'basith', 'password': support.PASSWORD})
    admin = call('login admin', 'POST', '/api/login', 200,
                 json={'username': ' Rithvik ', 'password': support.PASSWORD}).json()['token']
    user = call('login user', 'POST', '/api/login', 200, json={'username': 'jaga', 'password': support.PASSWORD}).json()['token']
    call('me admin', 'GET', '/api/me', 200, headers=auth(admin))
    call('me anonymous', 'GET', '/api/me', 401)
    call('users as admin', 'GET', '/api/users', 200, headers=auth(admin))
    for url in ('/api/users', '/api/admin/tasks', '/api/admin/users', '/api/admin/old-pf', '/api/admin/analytics'):
        call(f'forbidden for user {url}', 'GET', url, 403, headers=auth(user))
    call('admin anonymous', 'GET', '/api/admin/tasks', 401)

    # ---- admin reads, profiles, Old PF, analytics, exports ----
    call('admin tasks all', 'GET', '/api/admin/tasks', 200, headers=auth(admin))
    for status in ('all', 'pending', 'completed'):
        for sort in ('newest', 'oldest', 'name', 'task'):
            for q in ('', 'priya', 'DATA'):
                call(f'admin page {status} {sort} {q}', 'GET',
                     f'/api/admin/tasks?offset=5&limit=10&q={q}&status={status}&sort={sort}', 200, headers=auth(admin))
    call('admin users', 'GET', '/api/admin/users', 200, headers=auth(admin))
    call('old pf all', 'GET', '/api/admin/old-pf', 200, headers=auth(admin))
    call('old pf page', 'GET', '/api/admin/old-pf?offset=0&limit=10', 200, headers=auth(admin))
    for name in ('Jaga', 'Madhan B Anand', 'priya', 'Émile', 'nobody'):
        call(f'task profile {name}', 'GET', f'/api/admin/task-profiles/{name}/tasks', 200, headers=auth(admin))
    for username in ('rithvik', 'jaga', 'oldpf'):
        call(f'user tasks {username}', 'GET', f'/api/admin/users/{username}/tasks', 200, headers=auth(admin))
    call('user tasks missing', 'GET', '/api/admin/users/ghost/tasks', 404, headers=auth(admin))
    for period in ('daily', 'weekly', 'monthly'):
        for status in ('all', 'completed', 'pending'):
            call(f'analytics {period} {status}', 'GET',
                 f'/api/admin/analytics?start={START}&end={END}&period={period}&status={status}', 200, headers=auth(admin))
    users_page = call('analytics users', 'GET', '/api/admin/analytics/users?limit=15', 200, headers=auth(admin)).json()
    call('analytics users q', 'GET', '/api/admin/analytics/users?q=ana&limit=5', 200, headers=auth(admin))
    for item in users_page['items'][:6]:
        call(f"analytics user {item['name']}", 'GET',
             f"/api/admin/analytics/users/{item['username']}?start={START}&end={END}", 200, headers=auth(admin))
    call('my analytics', 'GET', f'/api/my/analytics?start={START}&end={END}', 200, headers=auth(user))
    for fmt in ('csv', 'xlsx'):
        call(f'admin export {fmt}', 'GET', f'/api/admin/tasks/export?format={fmt}', 200, headers=auth(admin))
        call(f'analytics export {fmt}', 'GET',
             f'/api/admin/analytics/export?format={fmt}&start={START}&end={END}', 200, headers=auth(admin))
        call(f'my analytics export {fmt}', 'GET',
             f'/api/my/analytics/export?format={fmt}&start={START}&end={END}', 200, headers=auth(user))

    # ---- task writes (disposable test records) ----
    call('add visitor', 'POST', '/api/tasks', 200, json={'title': 'Parity check A', 'name': 'Tester One', 'time': '9:15 AM', 'status': 'pending'})
    call('add logged in', 'POST', '/api/tasks', 200, headers=auth(user),
         json={'title': 'Parity check B', 'name': 'Jaga', 'time': '', 'status': 'completed'})
    call('add duplicate (case/space)', 'POST', '/api/tasks', 409, json={'title': ' parity  CHECK a', 'name': 'tester one', 'status': 'pending'})
    call('add duplicate of seed', 'POST', '/api/tasks', 409, json={'title': 'REPORT', 'name': 'JAGA', 'status': 'pending'})
    call('add missing name', 'POST', '/api/tasks', 422, json={'title': 'No name', 'name': '  ', 'status': 'pending'})
    call('add missing title', 'POST', '/api/tasks', 422, json={'title': '', 'name': 'X', 'status': 'pending'})
    call('toggle status', 'PATCH', f"/api/tasks/{unique_task['id']}", 200,
         json={'title': unique_task['title'], 'status': 'pending' if unique_task['status'] == 'completed' else 'completed'})
    # Repeated (historical) employee/task pairs: status/time edits are allowed because the
    # pair does not change; turning a task INTO another existing pair is still rejected.
    dup_key = main._task_duplicate_key(duplicated_task['name'], duplicated_task['title'])
    sibling = next(t for t, k in zip(seed_tasks, keys) if k == dup_key and t['id'] != duplicated_task['id'])
    flipped = 'pending' if duplicated_task['status'] == 'completed' else 'completed'
    call('toggle duplicated task', 'PATCH', f"/api/tasks/{duplicated_task['id']}", 200,
         json={'title': duplicated_task['title'], 'status': flipped})
    call('toggle duplicated task back', 'PATCH', f"/api/tasks/{duplicated_task['id']}", 200,
         json={'title': duplicated_task['title'], 'status': duplicated_task['status']})
    call('time edit on duplicated task', 'PATCH', f"/api/tasks/{sibling['id']}", 200,
         json={'title': sibling['title'], 'status': sibling['status'], 'time': '7:07 AM'})
    call('case/space-only edit keeps pair', 'PATCH', f"/api/tasks/{sibling['id']}", 200,
         json={'title': sibling['title'].upper().replace(' ', '  ', 1), 'status': sibling['status']})
    call('rename duplicated task onto another existing pair', 'PATCH', f"/api/tasks/{sibling['id']}", 409,
         json={'title': unique_task['title'], 'name': unique_task['name'], 'status': 'pending'})
    call('rename unique task onto a repeated pair', 'PATCH', f"/api/tasks/{unique_task['id']}", 409,
         json={'title': duplicated_task['title'], 'name': duplicated_task['name'], 'status': 'pending'})
    call('rename duplicated task to a new pair', 'PATCH', f"/api/tasks/{sibling['id']}", 200,
         json={'title': 'Brand new description', 'name': sibling['name'], 'status': 'pending'})
    call('rename employee', 'PATCH', '/api/tasks/2', 200, json={'title': 'Renamed task', 'name': 'New Person', 'time': '1:00 PM', 'status': 'completed'})
    call('edit into duplicate', 'PATCH', '/api/tasks/3', 409, json={'title': 'Parity check A', 'name': 'Tester One', 'status': 'pending'})
    call('edit blank title', 'PATCH', '/api/tasks/3', 422, json={'title': '   ', 'status': 'pending'})
    call('edit missing', 'PATCH', '/api/tasks/999999', 404, json={'title': 'x', 'status': 'pending'})
    call('delete existing', 'DELETE', '/api/tasks/4', 200)
    call('delete missing', 'DELETE', '/api/tasks/999999', 200)
    call('get after writes', 'GET', '/api/tasks', 200)
    call('admin after writes', 'GET', '/api/admin/tasks?offset=0&limit=200&sort=oldest', 200, headers=auth(admin))
    call('analytics after writes', 'GET', f'/api/admin/analytics?start={START}&end=2030-01-01', 200, headers=auth(admin))

    # ---- Excel import ----
    workbook = support.xlsx_bytes([
        (1, 'Import Person', 'Imported task one', '10:30 AM'),
        (2, 'Import Person', 'Imported task two', ''),
        (3, 'import person', 'IMPORTED TASK ONE', '11:00 AM'),      # duplicate inside workbook
        (4, 'Jaga', 'report', '9:00 AM'),                           # duplicate of existing
        (5, '', 'Missing name', '9:00 AM'),                         # invalid
        (6, 'Bad Time', 'Some task', '25:99'),                      # invalid
        (7, 'Brand New', 'Fresh import task', '4:45 PM'),
    ])
    preview = call('import validate', 'POST', '/api/tasks/import/validate', 200, content=workbook,
                   headers={'Content-Type': 'application/octet-stream'}).json()
    log[-1] = log[-1][:4] + (dict(log[-1][4], import_id='<stage>'),)
    call('import commit', 'POST', '/api/tasks/import/commit', 200, json={'import_id': preview['import_id']})
    call('import commit again', 'POST', '/api/tasks/import/commit', 404, json={'import_id': preview['import_id']})
    call('import empty body', 'POST', '/api/tasks/import/validate', 400, content=b'')
    call('get after import', 'GET', '/api/admin/tasks?offset=0&limit=200&sort=newest', 200, headers=auth(admin))
    call('profiles after import', 'GET', '/api/admin/users', 200, headers=auth(admin))

    # ---- accounts ----
    call('create user', 'POST', '/api/admin/users', 201, headers=auth(admin),
         json={'name': 'Test  Person', 'username': 'TestPerson', 'password': support.OTHER_PASSWORD})
    call('create duplicate username', 'POST', '/api/admin/users', 409, headers=auth(admin),
         json={'name': 'Other', 'username': 'testperson', 'password': support.OTHER_PASSWORD})
    call('create name clash', 'POST', '/api/admin/users', 409, headers=auth(admin),
         json={'name': 'jaga', 'username': 'jaga2', 'password': support.OTHER_PASSWORD})
    call('create deleted username', 'POST', '/api/admin/users', 409, headers=auth(admin),
         json={'name': 'Someone', 'username': 'oldpf', 'password': support.OTHER_PASSWORD})
    call('create as user', 'POST', '/api/admin/users', 403, headers=auth(user),
         json={'name': 'Nope', 'username': 'nope', 'password': support.OTHER_PASSWORD})
    call('login new user', 'POST', '/api/login', 200, json={'username': 'testperson', 'password': support.OTHER_PASSWORD})
    call('deactivate admin', 'DELETE', '/api/admin/users/rithvik', 400, headers=auth(admin))
    call('deactivate user', 'DELETE', '/api/admin/users/testperson', 200, headers=auth(admin))
    call('deactivate again', 'DELETE', '/api/admin/users/testperson', 404, headers=auth(admin))
    call('login deactivated new', 'POST', '/api/login', 401, json={'username': 'testperson', 'password': support.OTHER_PASSWORD})
    call('old pf after', 'GET', '/api/admin/old-pf', 200, headers=auth(admin))
    call('users after', 'GET', '/api/users', 200, headers=auth(admin))

    # ---- employee work ----
    call('work anonymous', 'GET', '/api/employee-work', 401)
    call('work list empty', 'GET', '/api/employee-work', 200, headers=auth(user))
    call('work add', 'POST', '/api/employee-work', 200, headers=auth(user),
         json={'employee_name': 'Jaga', 'work_done': 'Reviewed reports', 'time': '2 hours'})
    call('work add 2', 'POST', '/api/employee-work', 200, headers=auth(admin),
         json={'employee_name': 'Unknown Person', 'work_done': 'Line one\nLine two', 'time': '30 min'})
    call('work update', 'PATCH', '/api/employee-work/1', 200, headers=auth(user),
         json={'employee_name': 'Jaga', 'work_done': 'Reviewed all reports', 'time': '3 hours'})
    call('work update missing', 'PATCH', '/api/employee-work/99', 404, headers=auth(user),
         json={'employee_name': 'X', 'work_done': 'Y', 'time': 'Z'})
    call('work delete', 'DELETE', '/api/employee-work/2', 200, headers=auth(user))
    call('work delete missing', 'DELETE', '/api/employee-work/99', 200, headers=auth(user))
    call('work list', 'GET', '/api/employee-work', 200, headers=auth(user))

    # ---- maintenance switch (no restart needed) ----
    flag_path.write_text('on', encoding='utf-8')
    call('maint health', 'GET', '/api/health', 200)
    call('maint read', 'GET', '/api/tasks?offset=0&limit=5', 200)
    call('maint admin read', 'GET', '/api/admin/tasks?offset=0&limit=5', 200, headers=auth(admin))
    call('maint export', 'GET', '/api/admin/tasks/export?format=csv', 200, headers=auth(admin))
    call('maint login', 'POST', '/api/login', 200, json={'username': 'jaga', 'password': support.PASSWORD})
    blocked = call('maint add', 'POST', '/api/tasks', 503, headers={'Origin': ORIGIN},
                   json={'title': 'Blocked', 'name': 'Blocked', 'status': 'pending'})
    assert blocked.headers.get('access-control-allow-origin') == ORIGIN     # browser can read the 503
    call('maint patch', 'PATCH', '/api/tasks/1', 503, json={'title': 'x', 'status': 'pending'})
    call('maint delete', 'DELETE', '/api/tasks/1', 503)
    call('maint delete all', 'DELETE', '/api/admin/tasks', 503, headers=auth(admin),
         json={'confirmation': 'DELETE ALL', 'expected_count': 1})
    call('maint import validate', 'POST', '/api/tasks/import/validate', 503, content=workbook)
    call('maint import commit', 'POST', '/api/tasks/import/commit', 503, json={'import_id': 'x' * 30})
    call('maint create user', 'POST', '/api/admin/users', 503, headers=auth(admin),
         json={'name': 'Blocked', 'username': 'blocked', 'password': support.OTHER_PASSWORD})
    call('maint deactivate', 'DELETE', '/api/admin/users/jaga', 503, headers=auth(admin))
    call('maint work add', 'POST', '/api/employee-work', 503, headers=auth(user),
         json={'employee_name': 'a', 'work_done': 'b', 'time': 'c'})
    call('maint work patch', 'PATCH', '/api/employee-work/1', 503, headers=auth(user),
         json={'employee_name': 'a', 'work_done': 'b', 'time': 'c'})
    call('maint work delete', 'DELETE', '/api/employee-work/1', 503, headers=auth(user))
    call('maint preflight', 'OPTIONS', '/api/tasks', 200, headers={
        'Origin': ORIGIN, 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type'})
    flag_path.unlink()
    call('after maint add', 'POST', '/api/tasks', 200, json={'title': 'After maintenance', 'name': 'Tester One', 'status': 'pending'})
    call('maint health off', 'GET', '/api/health', 200)

    # ---- delete all (atomic) ----
    total = call('count before delete all', 'GET', '/api/tasks?offset=0&limit=1', 200).json()['all_total']
    call('delete all wrong confirm', 'DELETE', '/api/admin/tasks', 400, headers=auth(admin),
         json={'confirmation': 'delete all', 'expected_count': total})
    call('delete all stale count', 'DELETE', '/api/admin/tasks', 409, headers=auth(admin),
         json={'confirmation': 'DELETE ALL', 'expected_count': total + 1})
    call('delete all as user', 'DELETE', '/api/admin/tasks', 403, headers=auth(user),
         json={'confirmation': 'DELETE ALL', 'expected_count': total})
    call('delete all', 'DELETE', '/api/admin/tasks', 200, headers=auth(admin),
         json={'confirmation': 'DELETE ALL', 'expected_count': total})
    call('delete all empty', 'DELETE', '/api/admin/tasks', 200, headers=auth(admin),
         json={'confirmation': 'DELETE ALL', 'expected_count': 0})
    call('tasks after delete all', 'GET', '/api/tasks?offset=0&limit=10', 200)
    call('profiles after delete all', 'GET', '/api/admin/users', 200, headers=auth(admin))
    call('logout', 'POST', '/api/logout', 200, headers=auth(user))
    call('me after logout', 'GET', '/api/me', 401, headers=auth(user))
    return [_mask(entry, seed_max_id) for entry in log]


def test_json_and_mysql_return_identical_responses(tmp_path, pw_hash):
    tasks, users = support.seed_tasks(), support.seed_users(pw_hash)

    json_dir = tmp_path / 'json'
    json_dir.mkdir()
    support.write_json_store(json_dir, tasks, users)
    json_log = run_scenario(support.load_app('json', json_dir), json_dir / 'MAINTENANCE', tasks)

    mysql_dir = tmp_path / 'mysql'
    mysql_dir.mkdir()
    support.write_json_store(mysql_dir, tasks, users)       # must stay untouched in MySQL mode
    before = {p.name: p.read_bytes() for p in mysql_dir.glob('*.json')}
    support.seed_db(tasks, users)
    mysql_log = run_scenario(support.load_app('mysql', mysql_dir), mysql_dir / 'MAINTENANCE', tasks)

    assert len(json_log) == len(mysql_log)
    mismatches = [(j[0], json.dumps(j[4], default=str)[:400], json.dumps(m[4], default=str)[:400])
                  for j, m in zip(json_log, mysql_log) if j != m]
    assert not mismatches, f'{len(mismatches)} differing responses, first: {mismatches[:3]}'
    after = {p.name: p.read_bytes() for p in mysql_dir.glob('*.json')}
    assert before == after, 'MySQL mode wrote to the JSON files'
    print(f'\n{len(json_log)} requests: JSON and MySQL responses identical')
