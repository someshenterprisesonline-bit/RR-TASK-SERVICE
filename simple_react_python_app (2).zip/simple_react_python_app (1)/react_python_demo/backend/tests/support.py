"""Shared test helpers. Safety rules enforced here:

* Only databases whose name ends in "_test" can be reset, seeded or written.
* The app under test always uses temporary copies of tasks.json/users.json and a
  temporary maintenance flag path, never the real backend files.
"""
import hashlib
import io
import json
import os
import re
import secrets
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parent.parent
for extra in (BACKEND, BACKEND / 'tools'):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

import rr_mysql_admin as admin  # noqa: E402

TEST_DB = admin.TEST_DB
# Disposable test-account passwords: random per run, held in memory only, never written anywhere.
PASSWORD = secrets.token_urlsafe(18)
OTHER_PASSWORD = secrets.token_urlsafe(18)
APP_MODULES = ('main', 'auth', 'db', 'mysql_store', 'maintenance')


def require_test_db(database: str) -> None:
    if not database.endswith('_test') or database == admin.PRODUCTION_DB:
        raise RuntimeError(f'Refusing to modify non-test database {database!r}')


def reset_db(database: str = TEST_DB) -> None:
    require_test_db(database)
    admin.run_admin_sql('SET FOREIGN_KEY_CHECKS = 0; TRUNCATE TABLE `employee_work_entries`; '
                        'TRUNCATE TABLE `tasks`; TRUNCATE TABLE `employees`; TRUNCATE TABLE `users`; '
                        'SET FOREIGN_KEY_CHECKS = 1;', database)


def _sql_literal(text: str) -> str:
    return "'" + text.replace('\\', '\\\\').replace("'", "\\'") + "'"


def seed_db(tasks: list, users: list, database: str = TEST_DB) -> str:
    """Empty the test DB, then load it with the REAL migration script (JSON inlined)."""
    require_test_db(database)
    reset_db(database)
    tasks_text, users_text = json.dumps(tasks, indent=2), json.dumps(users, indent=2)
    sql = (BACKEND / 'mysql_json_migration.sql').read_text(encoding='utf-8')
    sql = sql.replace('USE `rr_task_service`;', f'USE `{database}`;', 1)
    replacements = {
        r"SET @rr_tasks_json = CONVERT\(LOAD_FILE\(@rr_tasks_path\) USING utf8mb4\);":
            f'SET @rr_tasks_json = {_sql_literal(tasks_text)};',
        r"SET @rr_users_json = CONVERT\(LOAD_FILE\(@rr_users_path\) USING utf8mb4\);":
            f'SET @rr_users_json = {_sql_literal(users_text)};',
        r"SET @rr_expected_tasks_sha256 = '[0-9a-f]{64}';":
            f"SET @rr_expected_tasks_sha256 = '{hashlib.sha256(tasks_text.encode()).hexdigest()}';",
        r"SET @rr_expected_users_sha256 = '[0-9a-f]{64}';":
            f"SET @rr_expected_users_sha256 = '{hashlib.sha256(users_text.encode()).hexdigest()}';",
        r'SET @rr_expected_tasks = \d+;': f'SET @rr_expected_tasks = {len(tasks)};',
        r'SET @rr_expected_users = \d+;': f'SET @rr_expected_users = {len(users)};',
        r'SET @rr_expected_completed = \d+;':
            f"SET @rr_expected_completed = {sum(t['status'] == 'completed' for t in tasks)};",
        r'SET @rr_expected_pending = \d+;':
            f"SET @rr_expected_pending = {sum(t['status'] == 'pending' for t in tasks)};",
    }
    for pattern, value in replacements.items():
        sql, n = re.subn(pattern, lambda _m, v=value: v, sql)
        assert n == 1, pattern
    output = admin.run_admin_sql(sql, batch=False)
    assert 'COMMITTED' in output, output[-2000:]
    return output


def write_json_store(directory: Path, tasks: list, users: list) -> None:
    """Write files exactly the way the app does (same json.dump arguments)."""
    with (directory / 'tasks.json').open('w', encoding='utf-8') as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False)
    with (directory / 'users.json').open('w', encoding='utf-8') as f:
        json.dump(users, f, indent=2)


def load_app(mode: str, directory: Path, database: str = TEST_DB):
    """Fresh import of the backend in the requested storage mode."""
    require_test_db(database)
    for name in APP_MODULES:
        sys.modules.pop(name, None)
    os.environ.update({
        'RR_STORAGE': mode,
        'RR_DB_NAME': database,
        'RR_TASKS_FILE': str(directory / 'tasks.json'),
        'RR_USERS_FILE': str(directory / 'users.json'),
        'RR_MAINTENANCE_FILE': str(directory / 'MAINTENANCE'),
    })
    import main  # noqa: WPS433
    return main


def password_hash() -> str:
    import auth
    return auth.hash_password(PASSWORD)


def seed_users(hash_value: str) -> list:
    return [
        {'username': 'rithvik', 'name': 'Rithvik', 'role': 'admin', 'password_hash': hash_value},
        {'username': 'jaga', 'name': 'Jaga', 'role': 'user', 'password_hash': hash_value},
        {'username': 'basith', 'name': 'Basith', 'role': 'user', 'password_hash': hash_value},
        {'username': 'oldpf', 'name': 'Old Pf', 'role': 'user', 'password_hash': hash_value,
         'active': False, 'deactivated_at': '2026-11-05T11:12:14+00:00', 'deactivated_by': 'rithvik'},
    ]


NAMES = ['jaga', 'Jaga', 'basith', 'Madhan B Anand', 'Priya', 'priya ', 'Zoe', 'zoe',
         "O'Neil", 'Ana-Maria', 'Ana Maria', 'Émile', 'emile', '10x Team']
TITLES = ['Report', 'report', 'Data_Entry', 'data-entry', '10 reports', 'Audit trail',
          'Validate status of file transfer', 'HR analytics', 'Backend dev', 'Zebra crossing review']
IMPORT_BATCH = hashlib.sha256(b'test-import-batch').hexdigest()


def seed_tasks(count: int = 60) -> list:
    """Deterministic tasks covering case/accent/punctuation, duplicates and nulls."""
    rows = []
    for i in range(count):
        day = 1 + (i * 3) % 37
        month, day = (10, day) if day <= 31 else (11, day - 31)
        task = {'id': i + 1, 'title': TITLES[(i * 7) % len(TITLES)],
                'status': 'completed' if i % 3 == 0 else 'pending', 'done': False,
                'name': NAMES[i % len(NAMES)],
                'time': f"{i % 12 + 1}:{(i * 5) % 60:02d} {'AM' if i % 2 else 'PM'}",
                'submitted_at': f'2026-{month:02d}-{day:02d}T{(i * 5) % 24:02d}:{(i * 7) % 60:02d}:{(i * 11) % 60:02d}+00:00',
                'submitted_by': 'rithvik' if i % 10 == 0 else None}
        if 20 <= i < 50:
            task['_import_id'] = IMPORT_BATCH
        rows.append(task)
    return rows


def xlsx_bytes(rows: list) -> bytes:
    from openpyxl import Workbook
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(['S.No', 'Name', 'Tasks', 'Time (AM/PM)'])
    for row in rows:
        sheet.append(list(row))
    buffer = io.BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def xlsx_rows(content: bytes) -> list:
    from openpyxl import load_workbook
    workbook = load_workbook(io.BytesIO(content), read_only=True)
    try:
        return {ws.title: [list(r) for r in ws.iter_rows(values_only=True)] for ws in workbook.worksheets}
    finally:
        workbook.close()
