"""The rr_app account may do exactly what the application needs - nothing more.

Destructive probes run ONLY against the disposable test database. Against
production only grants are read and zero-row probes (WHERE 1 = 0) are used, so
nothing can change even if a privilege were unexpectedly present.
"""
import os

import mysql.connector
import pytest

import support

DENIED = {1142, 1143, 1044, 1045, 1227, 1370, 1410}


def _connect(database):
    support.load_app('json', support.BACKEND / 'tests' / '_unused')   # loads backend/.env into os.environ
    return mysql.connector.connect(host=os.environ.get('RR_DB_HOST', '127.0.0.1'),
                                   port=int(os.environ.get('RR_DB_PORT', '3306')),
                                   user=os.environ['RR_DB_USER'], password=os.environ['RR_DB_PASSWORD'],
                                   database=database, autocommit=True)


def _denied(cur, sql):
    with pytest.raises(mysql.connector.Error) as info:
        cur.execute(sql)
        cur.fetchall()
    assert info.value.errno in DENIED, (sql, info.value.errno, info.value.msg)


@pytest.fixture
def test_cursor(seeded):
    conn = _connect(support.TEST_DB)
    yield conn.cursor()
    conn.close()


def test_grants_are_exactly_the_minimum():
    conn = _connect(support.TEST_DB)
    cur = conn.cursor()
    cur.execute('SHOW GRANTS')
    grants = sorted(row[0].replace('`', '') for row in cur.fetchall())
    conn.close()
    joined = '\n'.join(grants)
    assert 'GRANT USAGE ON *.* TO rr_app@127.0.0.1' in joined
    assert 'ALL PRIVILEGES' not in joined and ' ON *.* TO' not in joined.replace('GRANT USAGE ON *.* TO', '')
    for db in ('rr_task_service', 'rr_task_service_test'):
        assert f'GRANT SELECT, INSERT, UPDATE, DELETE ON {db}.tasks TO rr_app@127.0.0.1' in grants
        assert f'GRANT SELECT, INSERT ON {db}.employees TO rr_app@127.0.0.1' in grants
        assert f'GRANT SELECT, INSERT, UPDATE (active, deactivated_at, deactivated_by) ON {db}.users TO rr_app@127.0.0.1' in grants
        assert f'GRANT SELECT, INSERT, UPDATE, DELETE ON {db}.employee_work_entries TO rr_app@127.0.0.1' in grants
        for proc in support.admin.PROCEDURES:
            assert f'GRANT EXECUTE ON PROCEDURE {db}.{proc} TO rr_app@127.0.0.1' in grants
    assert len(grants) == 1 + 2 * (4 + 5), grants
    print('\n' + joined)


def test_forbidden_operations_on_test_database(test_cursor):
    cur = test_cursor
    for sql in ('DROP TABLE tasks', 'TRUNCATE TABLE tasks', 'ALTER TABLE tasks ADD COLUMN x INT',
                'CREATE TABLE evil (id INT)', 'DELETE FROM users', 'DELETE FROM employees',
                "UPDATE users SET password_hash = 'x'", "UPDATE users SET role = 'admin'",
                "UPDATE users SET username = 'x'", "UPDATE employees SET name = 'x'",
                'DROP PROCEDURE sp_add_task', 'CREATE PROCEDURE p() SELECT 1',
                "SELECT * FROM tasks INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/x.txt'",
                'SELECT * FROM mysql.user', 'SELECT * FROM rr_task_service_missing.tasks',
                "CREATE USER 'x'@'localhost'", "GRANT SELECT ON *.* TO 'rr_app'@'127.0.0.1'",
                'SET GLOBAL max_connections = 10', 'CREATE DATABASE evil_db'):
        _denied(cur, sql)
    cur.execute("SELECT LOAD_FILE('C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/rr_task_service_users.json')")
    assert cur.fetchall() == [(None,)]           # no FILE privilege: server files are unreadable


def test_permitted_operations_on_test_database(test_cursor):
    cur = test_cursor
    cur.execute("UPDATE users SET active = active, deactivated_at = deactivated_at WHERE username = 'jaga'")
    cur.execute("INSERT INTO employees (name, normalized_name) VALUES ('Perm Probe', 'perm probe')")
    cur.execute("SELECT COUNT(*) FROM tasks")
    assert cur.fetchone()[0] == 60
    cur.callproc('sp_get_task_by_id', [1])
    assert [r.fetchall() for r in cur.stored_results()][0][0][0] == 1


def test_production_privilege_probes_change_nothing():
    """Zero-row probes against production: denied statements must fail, allowed ones touch 0 rows."""
    conn = _connect('rr_task_service')
    cur = conn.cursor()
    # Production data changes through normal use, so compare against a snapshot
    # taken now rather than a hard-coded row count.
    cur.execute('SELECT COUNT(*) FROM tasks')
    tasks_before = cur.fetchone()[0]
    for sql in ('DELETE FROM users WHERE 1 = 0', 'DELETE FROM employees WHERE 1 = 0',
                "UPDATE users SET password_hash = 'x' WHERE 1 = 0", "UPDATE users SET role = 'admin' WHERE 1 = 0"):
        _denied(cur, sql)
    cur.execute('UPDATE tasks SET status = status WHERE 1 = 0')
    assert cur.rowcount == 0
    cur.execute('SELECT COUNT(*) FROM tasks')
    assert cur.fetchone()[0] == tasks_before
    conn.close()
