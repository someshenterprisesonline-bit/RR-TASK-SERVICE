"""Regression tests for the duplicate-pair status-toggle fix.

Production data is only READ (the verified backup snapshot) to prove the rule covers
all 7,000 affected tasks. Write tests use a synthetic replica with the same group
structure in the disposable test database / temporary JSON files.
"""
import json
from collections import Counter, defaultdict
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import support

SNAPSHOT = Path(r'C:\RR_Backups\20261107-160925\json\tasks.json')
GROUP_SIZES = {20: 131, 19: 132, 21: 42, 18: 55}       # same shape as production: 360 groups, 7,000 tasks
BATCH = 'c' * 64


def _groups(main, tasks):
    groups = defaultdict(list)
    for task in tasks:
        groups[main._task_duplicate_key(task['name'], task['title'])].append(task)
    return [g for g in groups.values() if len(g) > 1]


@pytest.mark.skipif(not SNAPSHOT.exists(), reason='verified backup snapshot not available')
def test_rule_covers_all_7000_affected_production_tasks_read_only(tmp_path):
    main = support.load_app('json', tmp_path)        # empty temp store; only the rule is used
    tasks = json.loads(SNAPSHOT.read_text(encoding='utf-8'))      # read-only
    groups = _groups(main, tasks)
    affected = [t for g in groups for t in g]
    assert (len(groups), len(affected)) == (360, 7000)
    # Old behaviour: every affected task had another task with the same pair -> 409 on any edit.
    assert all(sum(1 for o in g if o['id'] != t['id']) >= 1 for g in groups for t in g)
    # New behaviour: a status/time edit (pair unchanged) never counts as a duplicate.
    blocked = [t['id'] for t in affected
               if main._edit_creates_duplicate(t['id'], t['name'], t['title'], t['name'], t['title'], tasks)]
    assert blocked == []
    # Introducing a duplicate is still rejected: move a member onto another group's pair.
    for index in range(0, len(groups), 6):
        member, target = groups[index][0], groups[(index + 1) % len(groups)][0]
        assert main._edit_creates_duplicate(member['id'], member['name'], member['title'],
                                            target['name'], target['title'], tasks)
    singles = [t for t in tasks if t not in affected][:25]
    for single in singles:
        target = groups[0][0]
        assert main._edit_creates_duplicate(single['id'], single['name'], single['title'],
                                            target['name'], target['title'], tasks)


def _replica(pw_hash):
    tasks, next_id = [], 1
    for size, count in GROUP_SIZES.items():
        for g in range(count):
            for member in range(size):
                tasks.append({'id': next_id, 'title': f'Recurring duty {size}-{g}', 'status': 'completed',
                              'done': False, 'name': f'Replica Employee {g % 97}',
                              'time': f'{member % 12 + 1}:{(member * 7) % 60:02d} PM',
                              'submitted_at': '2026-11-06T05:30:00+00:00', 'submitted_by': None,
                              '_import_id': BATCH})
                next_id += 1
    for i in range(200):                              # ordinary, non-repeated tasks
        tasks.append({'id': next_id, 'title': f'One-off task {i}', 'status': 'pending', 'done': False,
                      'name': f'Single Person {i}', 'time': '9:00 AM',
                      'submitted_at': '2026-11-06T06:00:00+00:00', 'submitted_by': None})
        next_id += 1
    return tasks, support.seed_users(pw_hash)


def test_replica_all_7000_repeated_tasks_toggle_in_mysql_and_match_json(tmp_path, pw_hash):
    tasks, users = _replica(pw_hash)
    support.write_json_store(tmp_path, tasks, users)
    json_main = support.load_app('json', tmp_path)
    groups = _groups(json_main, tasks)
    assert (len(groups), sum(map(len, groups))) == (360, 7000)
    sample = [g[len(g) // 2] for g in groups]                    # one member of every group

    json_client = TestClient(json_main.app)
    json_responses = [json_client.patch(f"/api/tasks/{t['id']}", json={'title': t['title'], 'status': 'pending'})
                      for t in sample]
    assert Counter(r.status_code for r in json_responses) == {200: 360}

    support.seed_db(tasks, users)
    mysql_main = support.load_app('mysql', tmp_path)
    before = mysql_main.store.all_tasks()
    employees_before = support.admin.run_admin_sql('SELECT COUNT(*) FROM employees;', support.TEST_DB).strip()
    client = TestClient(mysql_main.app)
    sample_ids = {t['id'] for t in sample}
    mysql_sample = []
    codes = Counter()
    for group in groups:                                         # every one of the 7,000 tasks
        for t in group:
            response = client.patch(f"/api/tasks/{t['id']}", json={'title': t['title'], 'status': 'pending'})
            codes[response.status_code] += 1
            if t['id'] in sample_ids:
                mysql_sample.append((t['id'], response.status_code, response.json()))
    assert codes == {200: 7000}
    by_id = {i: (code, body) for i, code, body in mysql_sample}
    assert [(r.status_code, r.json()) for r in json_responses] == [by_id[t['id']] for t in sample]

    after = mysql_main.store.all_tasks()
    assert len(after) == len(before) == len(tasks)                # nothing added, merged or deleted
    affected_ids = {t['id'] for g in groups for t in g}
    for old, new in zip(before, after):
        expected = dict(old, status='pending') if old['id'] in affected_ids else old
        assert new == expected                                   # only status changed
    assert support.admin.run_admin_sql('SELECT COUNT(*) FROM employees;', support.TEST_DB).strip() == employees_before

    # Normal updates and the duplicate guard still work on the same data.
    t = groups[0][0]
    assert client.patch(f"/api/tasks/{t['id']}", json={'title': t['title'], 'status': 'completed',
                                                       'time': '6:45 AM'}).status_code == 200
    other = groups[1][0]
    assert client.patch(f"/api/tasks/{t['id']}", json={'title': other['title'], 'name': other['name'],
                                                       'status': 'pending'}).status_code == 409
    single = after[-1]
    assert client.patch(f"/api/tasks/{single['id']}", json={'title': other['title'], 'name': other['name'],
                                                            'status': 'pending'}).status_code == 409
    assert client.patch(f"/api/tasks/{single['id']}", json={'title': 'Edited one-off task', 'name': single['name'],
                                                            'status': 'completed'}).status_code == 200
    assert client.post('/api/tasks', json={'title': other['title'], 'name': other['name'],
                                           'status': 'pending'}).status_code == 409
