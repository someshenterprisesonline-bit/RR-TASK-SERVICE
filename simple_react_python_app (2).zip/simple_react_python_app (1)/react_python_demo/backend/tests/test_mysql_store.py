"""MySQL-mode behaviour: procedure ordering, atomicity, concurrency, failures, scale."""
import itertools
import queue
import random
import threading
import time
from contextlib import contextmanager

import pytest
from fastapi.testclient import TestClient

import support


def _admin_token(client):
    return client.post('/api/login', json={'username': 'rithvik', 'password': support.PASSWORD}).json()['token']


def _counts():
    out = support.admin.run_admin_sql(
        'SELECT (SELECT COUNT(*) FROM tasks), (SELECT COUNT(*) FROM employees), (SELECT COUNT(*) FROM users), '
        '(SELECT COUNT(*) FROM employee_work_entries);', support.TEST_DB)
    return tuple(int(x) for x in out.split())


def test_sp_get_tasks_matches_python_filter_and_sort(tmp_path, pw_hash):
    """sp_get_tasks v2 must page exactly like _filter_sort_tasks, including tie order."""
    rng = random.Random(20261107)
    names = support.NAMES + ['ZOE', 'Zoë', 'zoe2', 'A', 'a', 'b', 'B', '_under', '-dash', 'Ánia', 'ania', '  ', 'x y']
    titles = support.TITLES + ['A', 'a', 'Ä', 'z', 'Z', '_x', '-x', '10', '9', 'résumé', 'resume']
    tasks = []
    for i in range(400):
        task = {'id': i + 1, 'title': rng.choice(titles), 'status': rng.choice(['pending', 'completed']),
                'done': False, 'name': rng.choice(names).strip() or 'Blank', 'time': '9:00 AM',
                'submitted_at': '2026-11-01T10:00:00+00:00', 'submitted_by': None}
        tasks.append(task)
    support.write_json_store(tmp_path, tasks, support.seed_users(pw_hash))
    support.seed_db(tasks, support.seed_users(pw_hash))
    main = support.load_app('mysql', tmp_path)
    rows = main.store.all_tasks()
    assert rows == tasks
    checked = 0
    for status, sort, q in itertools.product(('all', 'pending', 'completed'), ('newest', 'oldest', 'name', 'task'),
                                             ('', 'a', 'Z', 'zoe', 'résumé', 'resume', '_', '-', '1', 'nomatch')):
        expected = main._filter_sort_tasks(list(rows), q, status, sort)
        for offset, limit in ((0, 200), (37, 50), (390, 10)):
            total, all_total, page = main.store.page_tasks(q.strip().casefold(), status, sort, offset, limit)
            assert (total, all_total) == (len(expected), len(rows))
            assert [t['id'] for t in page] == [t['id'] for t in expected[offset:offset + limit]], (status, sort, q, offset)
            checked += 1
    print(f'\n{checked} sp_get_tasks pages identical to the Python implementation')


def test_import_is_atomic_when_insert_fails(mysql_app, monkeypatch):
    client = TestClient(mysql_app.app)
    before = _counts()
    rows = [(i, f'Atomic Person {i % 40}', f'Atomic task {i}', '9:00 AM') for i in range(1, 2501)]
    preview = client.post('/api/tasks/import/validate', content=support.xlsx_bytes(rows)).json()
    assert preview['valid_count'] == 2500

    db = mysql_app.store.db
    real_connection = db.connection
    calls = {'n': 0}

    class CursorProxy:
        def __init__(self, cur):
            self._cur = cur

        def executemany(self, sql, params):
            if 'INSERT INTO `tasks`' in sql:
                calls['n'] += 1
                if calls['n'] == 2:          # first 1,000 rows already inserted in this transaction
                    raise RuntimeError('simulated failure mid-import')
            return self._cur.executemany(sql, params)

        def __getattr__(self, name):
            return getattr(self._cur, name)

    class ConnProxy:
        def __init__(self, conn):
            self._conn = conn

        def cursor(self, *args, **kwargs):
            return CursorProxy(self._conn.cursor(*args, **kwargs))

        def __getattr__(self, name):
            return getattr(self._conn, name)

    @contextmanager
    def failing_connection():
        with real_connection() as conn:
            yield ConnProxy(conn)

    monkeypatch.setattr(db, 'connection', failing_connection)
    response = client.post('/api/tasks/import/commit', json={'import_id': preview['import_id']})
    assert response.status_code == 500
    assert response.json() == {'detail': 'Import was not saved. No task records were added.'}
    assert calls['n'] == 2
    assert _counts() == before, 'partial import was not rolled back (tasks/employees)'


def test_large_import_and_pagination(mysql_app):
    client = TestClient(mysql_app.app)
    seed_count = _counts()[0]
    rows = [(i, f'Bulk Employee {i % 700}', f'Bulk task number {i}', f'{i % 12 + 1}:{i % 60:02d} PM')
            for i in range(1, 20001)]
    started = time.perf_counter()
    preview = client.post('/api/tasks/import/validate', content=support.xlsx_bytes(rows)).json()
    assert preview['valid_count'] == 20000 and preview['invalid_count'] == 0
    result = client.post('/api/tasks/import/commit', json={'import_id': preview['import_id']}).json()
    elapsed = time.perf_counter() - started
    assert result['imported_count'] == 20000 and result['total'] == seed_count + 20000
    assert result['unique_employee_count'] == 700 and result['newly_created_profiles'] == 700
    page = client.get('/api/tasks?offset=0&limit=200&sort=oldest').json()
    assert page['all_total'] == seed_count + 20000 and len(page['items']) == 200
    last = client.get(f'/api/tasks?offset={seed_count + 19990}&limit=200&sort=oldest').json()
    assert len(last['items']) == 10 and last['items'][-1]['title'] == 'Bulk task number 20000'
    ids = [t['id'] for t in mysql_app.store.all_tasks()]
    assert ids == sorted(ids) and len(set(ids)) == len(ids)
    assert len(client.get('/api/tasks?offset=0&limit=200&q=bulk employee 69&sort=name').json()['items']) == 200
    print(f'\n20,000-row Excel import validated and committed in {elapsed:.1f}s')


def test_concurrent_duplicate_adds_create_exactly_one(mysql_app):
    client = TestClient(mysql_app.app)
    results, barrier = queue.Queue(), threading.Barrier(8)

    def worker():
        barrier.wait()
        results.put(client.post('/api/tasks', json={'title': 'Race task', 'name': 'Racer', 'status': 'pending'}).status_code)

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    codes = sorted(results.get() for _ in range(8))
    assert codes == [200] + [409] * 7, codes


def test_database_outage_returns_503_without_json_fallback(mysql_app, monkeypatch):
    client = TestClient(mysql_app.app)
    assert client.get('/api/tasks?offset=0&limit=1').status_code == 200
    db = mysql_app.store.db
    monkeypatch.setattr(db, '_idle', queue.LifoQueue())          # drop pooled connections
    monkeypatch.setitem(db._config, 'port', 3999)               # MySQL "goes away"
    for method, url in (('GET', '/api/tasks?offset=0&limit=5'), ('GET', '/api/tasks'), ('GET', '/api/health')):
        response = client.request(method, url)
        assert response.status_code == 503, (url, response.status_code)
        assert response.json() == {'detail': 'Database unavailable. Please try again shortly.'}
    login = client.post('/api/login', json={'username': 'rithvik', 'password': support.PASSWORD})
    assert login.status_code == 503             # never authenticates against users.json instead


def test_users_json_is_never_written_in_mysql_mode(mysql_app):
    import auth
    with pytest.raises(RuntimeError):
        auth.save_users({})


def test_new_ids_are_never_reused(mysql_app):
    """Documented difference: JSON reuses the highest id after deleting it; MySQL never does."""
    client = TestClient(mysql_app.app)
    first = client.post('/api/tasks', json={'title': 'Id probe 1', 'name': 'Probe', 'status': 'pending'}).json()['id']
    client.delete(f'/api/tasks/{first}')
    second = client.post('/api/tasks', json={'title': 'Id probe 2', 'name': 'Probe', 'status': 'pending'}).json()['id']
    assert second == first + 1


def test_status_and_length_validation(mysql_app):
    """Documented difference: MySQL rejects values the schema/procedures cannot store."""
    client = TestClient(mysql_app.app)
    bad = client.post('/api/tasks', json={'title': 'Odd status', 'name': 'Someone', 'status': 'done'})
    assert bad.status_code == 422 and bad.json() == {'detail': 'Status must be pending or completed'}
    token = _admin_token(client)
    long_time = client.post('/api/employee-work', headers={'Authorization': f'Bearer {token}'},
                            json={'employee_name': 'A', 'work_done': 'B', 'time': 'x' * 21})
    assert long_time.status_code == 422


def test_migrated_fields_preserved_through_edits(mysql_app):
    """Editing via sp_update_task keeps done, submitted_* and _import_id untouched."""
    client = TestClient(mysql_app.app)
    before = {t['id']: t for t in mysql_app.store.all_tasks()}
    target = next(t for t in before.values() if t.get('_import_id') and t['status'] == 'pending'
                  and sum(1 for o in before.values() if mysql_app._task_duplicate_key(o['name'], o['title'])
                          == mysql_app._task_duplicate_key(t['name'], t['title'])) == 1)
    response = client.patch(f"/api/tasks/{target['id']}", json={'title': target['title'], 'status': 'completed'})
    assert response.status_code == 200
    after = {t['id']: t for t in mysql_app.store.all_tasks()}
    assert after[target['id']] == dict(target, status='completed')
    assert {k: v for k, v in after.items() if k != target['id']} == \
           {k: v for k, v in before.items() if k != target['id']}
