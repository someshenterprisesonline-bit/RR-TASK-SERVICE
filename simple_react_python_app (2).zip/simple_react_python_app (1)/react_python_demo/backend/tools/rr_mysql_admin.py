"""Shared helpers for RR TASK SERVICE MySQL administration scripts.

Administrative SQL is executed through the MySQL command-line client with the
`rr_admin` login path (mysql_config_editor), so no root password is stored or
handled here. SQL is passed on stdin, never on the command line.
"""
import os
import subprocess
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
MYSQL_EXE = os.environ.get('RR_MYSQL_EXE', r'C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe')
ADMIN_LOGIN_PATH = os.environ.get('RR_ADMIN_LOGIN_PATH', 'rr_admin')
PRODUCTION_DB = 'rr_task_service'
TEST_DB = 'rr_task_service_test'
APP_USER = 'rr_app'
APP_HOST = '127.0.0.1'
PROCEDURES = ('sp_add_task', 'sp_get_tasks', 'sp_get_task_by_id', 'sp_update_task', 'sp_delete_task')


def run_admin_sql(sql: str, database: str | None = None, *, batch: bool = True) -> str:
    """Run SQL as the administrative login path; return stdout. Raises on error."""
    args = [MYSQL_EXE, f'--login-path={ADMIN_LOGIN_PATH}', '--comments', '--default-character-set=utf8mb4']
    if batch:
        args += ['-B', '-N']
    if database:
        args.append(database)
    result = subprocess.run(args, input=sql.encode('utf-8'), capture_output=True)
    if result.returncode != 0:
        # stderr never contains the SQL text, so secrets in the SQL are not echoed.
        raise RuntimeError(f'mysql exited with {result.returncode}: '
                           f'{result.stderr.decode("utf-8", "replace").strip()}')
    return result.stdout.decode('utf-8', 'replace')


def grant_statements(database: str) -> list[str]:
    """Minimum privileges the FastAPI application needs on one database."""
    who = f"'{APP_USER}'@'{APP_HOST}'"
    db = f'`{database}`'
    statements = [
        f'GRANT SELECT, INSERT, UPDATE, DELETE ON {db}.`tasks` TO {who}',
        f'GRANT SELECT, INSERT ON {db}.`employees` TO {who}',
        f'GRANT SELECT, INSERT ON {db}.`users` TO {who}',
        # Deactivation only: password hashes, usernames and roles stay read-only.
        f'GRANT UPDATE (`active`, `deactivated_at`, `deactivated_by`) ON {db}.`users` TO {who}',
        f'GRANT SELECT, INSERT, UPDATE, DELETE ON {db}.`employee_work_entries` TO {who}',
    ]
    statements += [f'GRANT EXECUTE ON PROCEDURE {db}.`{name}` TO {who}' for name in PROCEDURES]
    return statements


def app_user_exists() -> bool:
    out = run_admin_sql(f"SELECT COUNT(*) FROM mysql.user WHERE user='{APP_USER}' AND host='{APP_HOST}';")
    return out.strip() == '1'


def sql_file_for(database: str, filename: str) -> str:
    """Return a schema/procedure file's SQL with its USE statement retargeted."""
    text = (BACKEND_DIR / filename).read_text(encoding='utf-8')
    if 'USE `rr_task_service`;' not in text:
        raise RuntimeError(f'{filename}: expected USE `rr_task_service`; statement not found')
    return text.replace('USE `rr_task_service`;', f'USE `{database}`;', 1)
