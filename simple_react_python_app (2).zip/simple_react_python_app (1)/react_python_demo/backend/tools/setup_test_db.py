"""(Re)create the DISPOSABLE test database rr_task_service_test.

Only ever touches the database named in rr_mysql_admin.TEST_DB (it must end in
"_test"); the production database is never referenced. Builds the schema from
mysql_schema.sql and procedures from mysql_task_procedures.sql, then re-applies
the rr_app grants for the test database if that account exists.

    python tools/setup_test_db.py            # create if missing (keeps data)
    python tools/setup_test_db.py --reset    # drop and recreate the test database
"""
import argparse
import sys

from rr_mysql_admin import (PRODUCTION_DB, TEST_DB, app_user_exists, grant_statements,
                            run_admin_sql, sql_file_for)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--reset', action='store_true', help='drop and recreate the test database')
    args = parser.parse_args()
    if not TEST_DB.endswith('_test') or TEST_DB == PRODUCTION_DB:
        raise SystemExit('Refusing: test database name must end in _test')

    if args.reset:
        run_admin_sql(f'DROP DATABASE IF EXISTS `{TEST_DB}`;')
    run_admin_sql(f'CREATE DATABASE IF NOT EXISTS `{TEST_DB}` '
                  'DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;')
    run_admin_sql(sql_file_for(TEST_DB, 'mysql_schema.sql'))
    run_admin_sql(sql_file_for(TEST_DB, 'mysql_task_procedures.sql'))
    if app_user_exists():
        run_admin_sql(';\n'.join(grant_statements(TEST_DB)) + ';')
        print(f'{TEST_DB}: ready (rr_app grants applied)')
    else:
        print(f'{TEST_DB}: ready (rr_app does not exist yet; grants not applied)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
