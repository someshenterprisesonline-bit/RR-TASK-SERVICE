"""Read-only comparison: JSON snapshot vs a MySQL database, through the real API code.

Runs the same battery of GET requests (public pages, admin pages, profiles,
Old PF, analytics, exports) against:
  A) the JSON implementation reading COPIES of the snapshot files, and
  B) the MySQL implementation reading --database with the maintenance switch ON
     (a temporary flag file), so no write could happen even by accident.
Admin endpoints are called with a test identity via FastAPI dependency override
(no password needed). Only GET requests are issued.

    python tools/compare_json_vs_mysql.py --database rr_task_service \
        --tasks <snapshot tasks.json> --users <snapshot users.json> --report <file>
"""
import argparse
import csv
import io
import json
import os
import shutil
import sys
import tempfile
from collections import Counter
from pathlib import Path

BACKEND = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND))
APP_MODULES = ('main', 'auth', 'db', 'mysql_store', 'maintenance')
ADMIN = {'username': 'rithvik', 'name': 'Rithvik', 'role': 'admin'}


def load_app(mode, workdir, database):
    for name in APP_MODULES:
        sys.modules.pop(name, None)
    os.environ.update({'RR_STORAGE': mode, 'RR_DB_NAME': database,
                       'RR_TASKS_FILE': str(workdir / 'tasks.json'), 'RR_USERS_FILE': str(workdir / 'users.json'),
                       'RR_MAINTENANCE_FILE': str(workdir / 'MAINTENANCE')})
    import main
    main.app.dependency_overrides[main.current_user] = lambda: ADMIN
    return main


def battery(main):
    from fastapi.testclient import TestClient
    from openpyxl import load_workbook
    client = TestClient(main.app)
    results = []

    def get(url):
        response = client.get(url)
        assert response.request.method == 'GET'
        ctype = response.headers.get('content-type', '')
        if 'json' in ctype:
            body = response.json()
        elif 'csv' in ctype:
            body = list(csv.reader(io.StringIO(response.content.decode('utf-8-sig'))))
        elif 'spreadsheet' in ctype:
            wb = load_workbook(io.BytesIO(response.content), read_only=True)
            body = {ws.title: [list(r) for r in ws.iter_rows(values_only=True)] for ws in wb.worksheets}
            wb.close()
        else:
            body = response.text
        results.append((url, response.status_code, ctype.split(';')[0],
                        response.headers.get('content-disposition'), body))
        return body

    get('/api/tasks')
    for prefix in ('/api/tasks', '/api/admin/tasks'):
        for status in ('all', 'pending', 'completed'):
            for sort in ('newest', 'oldest', 'name', 'task'):
                for q in ('', 'madhan', ' Validate ', 'HR', 'jaga', 'zzz'):
                    for offset in (0, 100, 5900, 13950):
                        get(f'{prefix}?offset={offset}&limit=100&q={q}&status={status}&sort={sort}')
    get('/api/admin/tasks')
    get('/api/users')
    get('/api/me')
    get('/api/employee-work')
    profiles = get('/api/admin/users')
    get('/api/admin/old-pf')
    get('/api/admin/old-pf?offset=0&limit=5')
    names = sorted({p['name'] for p in profiles})
    for name in names[:10] + names[-10:] + ['jaga', 'Madhan B Anand', 'nobody']:
        get(f'/api/admin/task-profiles/{name}/tasks')
    for username in ('rithvik', 'jaga', 'deeraj', 'ajay', 'harish', 'basith', 'sachin', 'ragav', 'oldpfdemo'):
        get(f'/api/admin/users/{username}/tasks')
    for start, end in (('2026-10-01', '2026-11-07'), ('2026-11-06', '2026-11-06'), ('', '')):
        for period in ('daily', 'weekly', 'monthly'):
            for status in ('all', 'completed', 'pending'):
                get(f'/api/admin/analytics?start={start}&end={end}&period={period}&status={status}')
    users_page = get('/api/admin/analytics/users?limit=15')
    get('/api/admin/analytics/users?q=madhan&limit=15')
    get('/api/admin/analytics/users?offset=7000&limit=15')
    for item in users_page['items'][:8]:
        get(f"/api/admin/analytics/users/{item['username']}?start=2026-10-01&end=2026-11-07")
    get('/api/my/analytics?start=2026-10-01&end=2026-11-07')
    for fmt in ('csv', 'xlsx'):
        get(f'/api/admin/tasks/export?format={fmt}')
        get(f'/api/admin/analytics/export?format={fmt}&start=2026-10-01&end=2026-11-07')
        get(f'/api/my/analytics/export?format={fmt}&start=2026-10-01&end=2026-11-07')
    return results


def main_cli():
    parser = argparse.ArgumentParser()
    parser.add_argument('--database', required=True)
    parser.add_argument('--tasks', required=True)
    parser.add_argument('--users', required=True)
    parser.add_argument('--report', required=True)
    args = parser.parse_args()

    with tempfile.TemporaryDirectory() as tmp:
        jdir, mdir = Path(tmp, 'json'), Path(tmp, 'mysql')
        jdir.mkdir(), mdir.mkdir()
        shutil.copyfile(args.tasks, jdir / 'tasks.json')
        shutil.copyfile(args.users, jdir / 'users.json')
        json_results = battery(load_app('json', jdir, args.database))
        (mdir / 'MAINTENANCE').write_text('read-only comparison', encoding='utf-8')
        mysql_app = load_app('mysql', mdir, args.database)
        assert mysql_app.maintenance.is_enabled()
        mysql_results = battery(mysql_app)

    mismatched = [j[0] for j, m in zip(json_results, mysql_results) if j != m]
    by_kind = Counter(('sort=name' in u and 'name sort') or ('sort=task' in u and 'task sort') or u.split('?')[0]
                      for u in mismatched)
    summary = {'database': args.database, 'requests': len(json_results),
               'identical': len(json_results) - len(mismatched), 'different': len(mismatched),
               'different_by_kind': dict(by_kind), 'first_differences': mismatched[:15]}
    Path(args.report).write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))
    return 0 if not mismatched else 1


if __name__ == '__main__':
    sys.exit(main_cli())
