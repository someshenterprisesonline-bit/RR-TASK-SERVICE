"""Create the restricted MySQL application account rr_app@127.0.0.1.

* Generates a random password with the `secrets` module and writes it ONLY to
  backend/.env (git-ignored; Windows ACL limited to the current user, SYSTEM and
  Administrators). The password is never printed, logged or put on a command line.
* Grants only the privileges listed in rr_mysql_admin.grant_statements() on the
  production database and (if present) the disposable test database.
* Refuses to run if the account or backend/.env already exists (no silent rotation).
* RR_STORAGE is written as "json": creating the account does not switch the app.
"""
import getpass
import os
import secrets
import subprocess
import sys

from rr_mysql_admin import (APP_HOST, APP_USER, BACKEND_DIR, PRODUCTION_DB, TEST_DB,
                            app_user_exists, grant_statements, run_admin_sql)

ENV_FILE = BACKEND_DIR / '.env'


def restrict_acl(path) -> None:
    if os.name != 'nt':
        os.chmod(path, 0o600)
        return
    me = f"{os.environ.get('USERDOMAIN', '')}\\{getpass.getuser()}".lstrip('\\')
    subprocess.run(['icacls', str(path), '/inheritance:r', '/grant:r',
                    f'{me}:F', '*S-1-5-18:F', '*S-1-5-32-544:F'],
                   check=True, capture_output=True)


def main() -> int:
    if ENV_FILE.exists():
        raise SystemExit(f'Refusing: {ENV_FILE} already exists (not rotating credentials silently).')
    if app_user_exists():
        raise SystemExit(f"Refusing: MySQL account '{APP_USER}'@'{APP_HOST}' already exists.")

    password = secrets.token_urlsafe(32)          # 43 URL-safe characters, ~256 bits
    # Write the credential file first (restricted), so the password is never lost.
    ENV_FILE.write_text(
        '# RR TASK SERVICE local configuration - git-ignored, do not commit or share.\n'
        '# RR_STORAGE=json keeps the JSON files as the live store until switch-over.\n'
        'RR_STORAGE=json\n'
        'RR_DB_HOST=127.0.0.1\n'
        'RR_DB_PORT=3306\n'
        f'RR_DB_NAME={PRODUCTION_DB}\n'
        f'RR_DB_USER={APP_USER}\n'
        f'RR_DB_PASSWORD={password}\n',
        encoding='utf-8')
    restrict_acl(ENV_FILE)

    databases = [PRODUCTION_DB]
    if run_admin_sql(f"SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='{TEST_DB}';").strip() == '1':
        databases.append(TEST_DB)
    statements = [
        f"CREATE USER '{APP_USER}'@'{APP_HOST}' IDENTIFIED BY '{password}' "
        "WITH MAX_USER_CONNECTIONS 30 PASSWORD EXPIRE NEVER",
    ]
    for database in databases:
        statements += grant_statements(database)
    try:
        run_admin_sql(';\n'.join(statements) + ';')
    except RuntimeError:
        ENV_FILE.unlink(missing_ok=True)      # nothing half-configured is left behind
        raise
    print(f"Created '{APP_USER}'@'{APP_HOST}' with grants on: {', '.join(databases)}")
    print(f'Credentials written to {ENV_FILE} (restricted; not displayed).')
    return 0


if __name__ == '__main__':
    sys.exit(main())
