"""Export MySQL back to the JSON file format (rollback path), read-only on MySQL.

Writes tasks.json and users.json with exactly the same json.dump arguments the
application uses, so an unchanged database reproduces the original files byte
for byte. Also writes employee_work.json for reference. Uses the rr_app
credentials from backend/.env (SELECT only).

    python tools/export_mysql_to_json.py --out C:\\RR_Backups\\<folder> [--database rr_task_service]

Refuses to write into the backend folder or over existing files: restoring the
live JSON store is a deliberate, separate step.
"""
import argparse
import json
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND))

import db as rr_db  # noqa: E402
from mysql_store import task_from_row, user_from_row  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True)
    parser.add_argument('--database')
    args = parser.parse_args()
    out = Path(args.out).resolve()
    if out == BACKEND or BACKEND in out.parents and out.parent == BACKEND:
        raise SystemExit('Refusing to export into the backend folder; choose a separate directory.')
    out.mkdir(parents=True, exist_ok=True)
    targets = [out / 'tasks.json', out / 'users.json', out / 'employee_work.json']
    if any(t.exists() for t in targets):
        raise SystemExit(f'Refusing to overwrite existing export files in {out}')

    rr_db.load_env_file()
    if args.database:
        import os
        os.environ['RR_DB_NAME'] = args.database
    database = rr_db.Database.from_env()
    with database.connection() as conn:
        with database.transaction(conn):      # one consistent snapshot
            tasks = [task_from_row(r) for r in database.query(conn,
                'SELECT `id`, `title`, `status`, `done`, `name`, `time`, `submitted_at`, `submitted_by`, '
                '`_import_id` FROM `tasks` ORDER BY `id`')]
            users = [user_from_row(r) for r in database.query(conn,
                'SELECT `username`, `name`, `role`, `password_hash`, `active`, `deactivated_at`, '
                '`deactivated_by` FROM `users` ORDER BY `user_id`')]
            work = database.query(conn, 'SELECT `id`, `employee_name`, `work_done`, `time` '
                                        'FROM `employee_work_entries` ORDER BY `id`')

    with targets[0].open('w', encoding='utf-8') as f:          # same as main._save_tasks
        json.dump(tasks, f, indent=2, ensure_ascii=False)
    with targets[1].open('w', encoding='utf-8') as f:          # same as auth.save_users
        json.dump(users, f, indent=2)
    with targets[2].open('w', encoding='utf-8') as f:
        json.dump([{k: (int(v) if k == 'id' else v) for k, v in w.items()} for w in work], f, indent=2,
                  ensure_ascii=False)
    print(f'Exported {len(tasks)} tasks, {len(users)} users, {len(work)} employee-work entries to {out}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
