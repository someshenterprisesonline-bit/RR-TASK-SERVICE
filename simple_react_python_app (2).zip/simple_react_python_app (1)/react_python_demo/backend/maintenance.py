"""Maintenance switch: while the flag file exists, every data-changing request is refused.

    Enable:  create backend/MAINTENANCE   (any content; git-ignored)
    Disable: delete backend/MAINTENANCE
    (RR_MAINTENANCE_FILE overrides the path, e.g. for tests.)

Checked on every request, so it takes effect without a restart. Reads (GET/HEAD),
CORS preflight (OPTIONS), login and logout stay available; everything else -
task CRUD, Excel import, Delete All, account changes and employee-work changes -
receives 503. Register this middleware BEFORE CORSMiddleware so CORS wraps it and
the browser can read the 503 message.
"""
import os
from pathlib import Path

from starlette.responses import JSONResponse

DEFAULT_FLAG = Path(__file__).with_name('MAINTENANCE')
SAFE_METHODS = frozenset({'GET', 'HEAD', 'OPTIONS'})
ALWAYS_ALLOWED = frozenset({('POST', '/api/login'), ('POST', '/api/logout')})
MESSAGE = ('RR Task Service is in maintenance mode. Viewing is available, '
           'but changes are temporarily disabled. Please try again shortly.')


def flag_path() -> Path:
    return Path(os.environ.get('RR_MAINTENANCE_FILE') or DEFAULT_FLAG)


def is_enabled() -> bool:
    return flag_path().exists()


class MaintenanceMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] == 'http':
            method = scope['method'].upper()
            if (method not in SAFE_METHODS and (method, scope['path'].rstrip('/') or '/') not in ALWAYS_ALLOWED
                    and is_enabled()):
                response = JSONResponse({'detail': MESSAGE}, status_code=503, headers={'Retry-After': '120'})
                await response(scope, receive, send)
                return
        await self.app(scope, receive, send)
