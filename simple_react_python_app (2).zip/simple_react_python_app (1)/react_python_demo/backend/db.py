"""MySQL configuration, connection pool and transaction helpers for RR TASK SERVICE.

Configuration comes from environment variables, optionally loaded from the
git-ignored backend/.env file (real environment variables take precedence):

    RR_STORAGE      json (default) | mysql
    RR_DB_HOST, RR_DB_PORT, RR_DB_NAME, RR_DB_USER, RR_DB_PASSWORD

The MySQL driver is imported lazily, so JSON mode does not depend on it.
Credentials are never logged or included in error messages.
"""
import logging
import os
import queue
import threading
from contextlib import contextmanager
from pathlib import Path

log = logging.getLogger('rr.db')
ENV_FILE = Path(__file__).with_name('.env')
VALID_STORAGE = ('json', 'mysql')
REQUIRED_TABLES = ('users', 'employees', 'tasks', 'employee_work_entries')
REQUIRED_PROCEDURES = ('sp_add_task', 'sp_get_tasks', 'sp_get_task_by_id', 'sp_update_task', 'sp_delete_task')


def load_env_file(path: Path = ENV_FILE) -> None:
    """Load KEY=VALUE lines into os.environ without overriding existing variables."""
    if not path.exists():
        return
    for raw in path.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, value = line.split('=', 1)
        key, value = key.strip(), value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in '"\'':
            value = value[1:-1]
        os.environ.setdefault(key, value)


def storage_mode() -> str:
    mode = os.environ.get('RR_STORAGE', 'json').strip().lower() or 'json'
    if mode not in VALID_STORAGE:
        raise RuntimeError(f'RR_STORAGE must be one of {VALID_STORAGE}, got {mode!r}')
    return mode


class DatabaseUnavailable(Exception):
    """MySQL could not be reached or no connection became free in time."""


class Database:
    """Small blocking connection pool around mysql-connector-python."""

    def __init__(self, host, port, database, user, password, pool_size=10, wait_seconds=10.0):
        import mysql.connector  # lazy: only needed in MySQL mode
        self._mysql = mysql.connector
        self.database = database
        self._config = dict(host=host, port=int(port), database=database, user=user, password=password,
                            autocommit=True, charset='utf8mb4', collation='utf8mb4_0900_ai_ci',
                            connection_timeout=10, use_unicode=True)
        self._idle = queue.LifoQueue()
        self._slots = threading.BoundedSemaphore(pool_size)
        self._wait_seconds = wait_seconds

    @classmethod
    def from_env(cls) -> 'Database':
        missing = [k for k in ('RR_DB_NAME', 'RR_DB_USER', 'RR_DB_PASSWORD') if not os.environ.get(k)]
        if missing:
            raise RuntimeError(f'MySQL mode requires environment variables: {", ".join(missing)}')
        return cls(os.environ.get('RR_DB_HOST', '127.0.0.1'), os.environ.get('RR_DB_PORT', '3306'),
                   os.environ['RR_DB_NAME'], os.environ['RR_DB_USER'], os.environ['RR_DB_PASSWORD'],
                   pool_size=int(os.environ.get('RR_DB_POOL_SIZE', '10')))

    @property
    def errors(self):
        return self._mysql.Error

    def _new_connection(self):
        try:
            conn = self._mysql.connect(**self._config)
        except self._mysql.Error as exc:
            raise DatabaseUnavailable(f'Cannot connect to MySQL database {self.database!r} '
                                      f'(error {getattr(exc, "errno", "?")})') from None
        cur = conn.cursor()
        cur.execute("SET SESSION time_zone = '+00:00'")
        cur.execute("SET SESSION sql_mode = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,"
                    "NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'")
        cur.close()
        return conn

    @contextmanager
    def connection(self):
        """Borrow a healthy connection; always returned clean (no open transaction)."""
        if not self._slots.acquire(timeout=self._wait_seconds):
            raise DatabaseUnavailable('No database connection became available in time')
        conn = None
        try:
            try:
                conn = self._idle.get_nowait()
                if not conn.is_connected():
                    conn = self._new_connection()
            except queue.Empty:
                conn = self._new_connection()
            yield conn
        except (self._mysql.Error, DatabaseUnavailable):
            # A broken or unknown-state connection is never reused (any named lock
            # it held is released by the server when the session closes).
            if conn is not None:
                self._discard(conn)
                conn = None
            raise
        finally:
            if conn is not None:
                try:
                    if conn.in_transaction:
                        conn.rollback()
                    self._idle.put(conn)
                except self._mysql.Error:
                    self._discard(conn)
            self._slots.release()

    def _discard(self, conn):
        try:
            if conn.in_transaction:
                conn.rollback()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass

    @contextmanager
    def transaction(self, conn):
        """Explicit atomic unit: commit on success, roll back on any exception."""
        conn.start_transaction()
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise

    @contextmanager
    def named_lock(self, conn, name: str, timeout: int = 15):
        """Serialize multi-statement write workflows across threads and processes."""
        cur = conn.cursor()
        cur.execute('SELECT GET_LOCK(%s, %s)', (name, timeout))
        acquired = cur.fetchone()[0] == 1
        cur.close()
        if not acquired:
            raise DatabaseUnavailable('The task store is busy; please retry')
        try:
            yield
        finally:
            try:
                cur = conn.cursor()
                cur.execute('SELECT RELEASE_LOCK(%s)', (name,))
                cur.fetchall()
                cur.close()
            except self._mysql.Error:
                pass   # the connection is discarded by connection(); the lock dies with it

    @staticmethod
    def query(conn, sql, params=()):
        cur = conn.cursor(dictionary=True)
        try:
            cur.execute(sql, params)
            return cur.fetchall()
        finally:
            cur.close()

    @staticmethod
    def execute(conn, sql, params=()):
        cur = conn.cursor()
        try:
            cur.execute(sql, params)
            return cur.rowcount, cur.lastrowid
        finally:
            cur.close()

    @staticmethod
    def call_proc(conn, name, args):
        """Call a stored procedure; return its result sets as lists of dicts."""
        cur = conn.cursor()
        try:
            cur.callproc(name, args)
            results = []
            for result in cur.stored_results():
                columns = [d[0] for d in result.description]
                results.append([dict(zip(columns, row)) for row in result.fetchall()])
            return results
        finally:
            cur.close()

    def check_ready(self) -> None:
        """Fail fast (no JSON fallback) unless the schema and procedures are present."""
        with self.connection() as conn:
            tables = {r['TABLE_NAME'] for r in self.query(conn,
                'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s', (self.database,))}
            procs = {r['ROUTINE_NAME'] for r in self.query(conn,
                "SELECT ROUTINE_NAME FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = %s "
                "AND ROUTINE_TYPE = 'PROCEDURE'", (self.database,))}
        missing = [t for t in REQUIRED_TABLES if t not in tables] + \
                  [p for p in REQUIRED_PROCEDURES if p not in procs]
        if missing:
            raise RuntimeError(f'MySQL database {self.database!r} is missing: {", ".join(missing)}')

    def ping(self) -> bool:
        with self.connection() as conn:
            return self.query(conn, 'SELECT 1 AS ok')[0]['ok'] == 1
