import csv
import io
import json
import logging
import os
import re
import secrets
import threading
import hashlib
import unicodedata
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, time as datetime_time, timedelta, timezone
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from starlette.concurrency import run_in_threadpool
import auth
import db as rr_db
import maintenance
from pydantic import BaseModel, Field
from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.styles import Font
from openpyxl.utils.datetime import from_excel

rr_db.load_env_file()                 # optional, git-ignored backend/.env
STORAGE = rr_db.storage_mode()        # 'json' (default) or 'mysql'

app = FastAPI(title='Simple Tasks API')
# Registered before CORS so CORS wraps it and browsers can read the 503 message.
app.add_middleware(maintenance.MaintenanceMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5173",
        "http://127.0.0.1:5174",
        "http://127.0.0.1:5175",
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175",
    ],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)
# ---- Authentication ----
class LoginInput(BaseModel):
    username: str
    password: str

def _bearer_token(authorization: str | None) -> str | None:
    if authorization and authorization.startswith('Bearer '):
        return authorization[7:]
    return None

def current_user(authorization: str | None = Header(default=None)):
    user = auth.get_session_user(_bearer_token(authorization) or '')
    if not user:
        raise HTTPException(status_code=401, detail="Not logged in", headers={'WWW-Authenticate': 'Bearer'})
    return user

def optional_user(authorization: str | None = Header(default=None)):
    """Logged-in user if a valid token was sent, otherwise None (public visitor)."""
    return auth.get_session_user(_bearer_token(authorization) or '')

def require_role(*roles):
    def check(user=Depends(current_user)):
        if user['role'] not in roles:
            raise HTTPException(status_code=403, detail="Not allowed for your role")
        return user
    return check

@app.post('/api/login')
def login(item: LoginInput):
    username = item.username.strip().lower()
    if auth.is_locked_out(username):
        raise HTTPException(status_code=429, detail="Too many failed attempts. Try again in a few minutes.")
    record = auth.load_users().get(username)
    stored = record.get('password_hash') if record else None
    # Always run the hash check so unknown usernames take the same time as wrong passwords
    valid = auth.verify_password(item.password, stored or auth.DUMMY_HASH) and stored is not None
    if not valid or record.get('role') not in auth.VALID_ROLES or not auth.is_active(record):
        auth.record_failure(username)
        raise HTTPException(status_code=401, detail="Invalid username or password")
    auth.clear_failures(username)
    return {'token': auth.create_session(record), 'user': auth.public_user(record)}

@app.post('/api/logout')
def logout(authorization: str | None = Header(default=None)):
    auth.end_session(_bearer_token(authorization) or '')
    return {'ok': True}

@app.get('/api/me')
def me(user=Depends(current_user)):
    return user

@app.get('/api/health')
def health():
    """Which store is live and whether maintenance mode is on (no data, no secrets)."""
    if store is not None:
        store.db.ping()
    return {'status': 'ok', 'storage': STORAGE, 'maintenance': maintenance.is_enabled()}

@app.get('/api/users')
def list_users(user=Depends(require_role('admin'))):
    return [auth.public_user(u) for u in auth.load_users().values() if auth.is_active(u)]

class TaskInput(BaseModel):
    # Length limits: task endpoints are public, so keep input sizes sensible
    title: str = Field(min_length=1, max_length=200)
    status: str = Field(max_length=20)
    name: str | None = Field(default=None, max_length=100)   # optional: who the task is for
    time: str | None = Field(default=None, max_length=20)    # optional: e.g. "10:30 AM"

# ---- Task store: saved to tasks.json so tasks + submission times survive restarts ----
# RR_TASKS_FILE lets tests use a copy; the default is the real backend/tasks.json.
TASKS_FILE = Path(os.environ.get('RR_TASKS_FILE') or Path(__file__).with_name('tasks.json'))
IST = timezone(timedelta(hours=5, minutes=30), 'IST')   # India has no daylight saving
SUBMISSION_FIELDS = ('submitted_at', 'submitted_by')     # admin-only data
INTERNAL_TASK_FIELDS = (*SUBMISSION_FIELDS, '_import_id')
MAX_IMPORT_BYTES = 20 * 1024 * 1024
MAX_IMPORT_ROWS = 20000
IMPORT_STAGE_TTL_SECONDS = 30 * 60
_tasks_lock = threading.Lock()
_pending_imports = {}
_pending_imports_lock = threading.Lock()

def _load_tasks():
    if TASKS_FILE.exists():
        with TASKS_FILE.open(encoding='utf-8') as f:
            return json.load(f)
    return []

def _save_tasks():
    tmp = TASKS_FILE.with_suffix('.json.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False)
    os.replace(tmp, TASKS_FILE)
    _invalidate_analytics()

def _invalidate_analytics():
    cache = globals().get('_analytics_cache')
    lock = globals().get('_analytics_cache_lock')
    if cache is not None and lock is not None:
        with lock:
            cache.clear()

def _public_task(task):
    """Task as returned to regular users (without admin-only submission data)."""
    return {k: v for k, v in task.items() if k not in INTERNAL_TASK_FIELDS}

# ---- Storage selection: JSON files (default) or MySQL. Never falls back between them. ----
store = None
if STORAGE == 'mysql':
    from mysql_store import MySqlStore
    _database = rr_db.Database.from_env()
    _database.check_ready()          # fail fast: the app refuses to start without MySQL
    store = MySqlStore(_database, lambda name, title: _task_duplicate_key(name, title),
                       lambda *args: _edit_creates_duplicate(*args))
    auth.set_user_backend(store)

    @app.exception_handler(_database.errors)
    async def _mysql_error(request, exc):
        logging.getLogger('rr.db').error('MySQL error %s on %s %s', getattr(exc, 'errno', '?'),
                                         request.method, request.url.path)
        return JSONResponse({'detail': 'Database unavailable. Please try again shortly.'}, status_code=503)

@app.exception_handler(rr_db.DatabaseUnavailable)
async def _database_unavailable(request, exc):
    logging.getLogger('rr.db').error('Database unavailable on %s %s: %s', request.method, request.url.path, exc)
    return JSONResponse({'detail': 'Database unavailable. Please try again shortly.'}, status_code=503)

tasks = _load_tasks() if store is None else []     # MySQL mode never reads tasks.json
next_id = max((t['id'] for t in tasks), default=0) + 1

def _task_rows():
    """Every task in id order: the live JSON list, or a fresh snapshot from MySQL."""
    return tasks if store is None else store.all_tasks()

@contextmanager
def _interprocess_tasks_lock():
    """Serialize task writes across Uvicorn workers/processes using the JSON store."""
    lock_path = TASKS_FILE.with_suffix('.json.lock')
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        if os.name == 'nt':
            import msvcrt
            if os.fstat(fd).st_size == 0:
                os.write(fd, b'0')
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        if os.name == 'nt':
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)

@contextmanager
def _task_store_lock(refresh=False):
    """Lock in-process and cross-process; optionally reload the latest persisted state."""
    global next_id
    with _tasks_lock:
        with _interprocess_tasks_lock():
            if refresh:
                tasks[:] = _load_tasks()
                next_id = max((t['id'] for t in tasks), default=0) + 1
            yield

def _filter_sort_tasks(rows, q='', status='all', sort='newest'):
    query = (q or '').strip().casefold()
    if query:
        rows = [t for t in rows if query in str(t.get('name') or '').casefold() or query in str(t.get('title') or '').casefold()]
    if status in ('pending', 'completed'):
        rows = [t for t in rows if str(t.get('status', '')).casefold() == status]
    if sort == 'name':
        rows = sorted(rows, key=lambda t: (str(t.get('name') or '').casefold(), t.get('id', 0)))
    elif sort == 'task':
        rows = sorted(rows, key=lambda t: (str(t.get('title') or '').casefold(), t.get('id', 0)))
    elif sort == 'oldest':
        rows = sorted(rows, key=lambda t: t.get('id', 0))
    else:
        rows = sorted(rows, key=lambda t: t.get('id', 0), reverse=True)
    return rows

@app.get('/api/tasks')   # public: MY TASKS is open to everyone
def get_tasks(offset: int | None = None, limit: int | None = None, q: str = '', status: str = 'all', sort: str = 'newest'):
    if offset is None and limit is None:
        return [_public_task(t) for t in _task_rows()]
    offset = offset or 0
    limit = 100 if limit is None else limit
    if offset < 0 or limit < 1 or limit > 200:
        raise HTTPException(status_code=422, detail="Use an offset >= 0 and a limit between 1 and 200")
    if status not in ('all', 'pending', 'completed') or sort not in ('newest', 'oldest', 'name', 'task'):
        raise HTTPException(status_code=422, detail="Invalid task filter or sort option")
    if store is not None:
        total, all_total, rows = store.page_tasks((q or '').strip().casefold(), status, sort, offset, limit)
        return {'items': [_public_task(t) for t in rows], 'total': total, 'all_total': all_total,
                'offset': offset, 'limit': limit}
    with _tasks_lock:
        filtered = _filter_sort_tasks(list(tasks), q, status, sort)
        total = len(filtered)
        page = [_public_task(t) for t in filtered[offset:offset + limit]]
    return {'items': page, 'total': total, 'all_total': len(tasks), 'offset': offset, 'limit': limit}

def _profile_name_key(value):
    return _normalize_duplicate_text(value)

def _normalize_duplicate_text(value):
    """Collapse whitespace and Unicode compatibility forms before case-folding."""
    return ' '.join(unicodedata.normalize('NFKC', str(value or '')).split()).casefold()

def _task_duplicate_key(name, title):
    normalized_name = _normalize_duplicate_text(name)
    normalized_title = _normalize_duplicate_text(title)
    return (normalized_name, normalized_title) if normalized_name and normalized_title else None

def _edit_creates_duplicate(task_id, current_name, current_title, next_name, next_title, rows):
    """True only if the edit CHANGES the task's normalized employee/task pair to one another
    task already has. Status/time edits keep the pair, so historical repeated tasks (e.g.
    recurring imported entries) stay editable; existing records are never merged or renamed.
    Shared by the JSON and MySQL stores."""
    duplicate_key = _task_duplicate_key(next_name, next_title)
    if duplicate_key == _task_duplicate_key(current_name, current_title):
        return False
    return any(other['id'] != task_id and _task_duplicate_key(other.get('name'), other.get('title')) == duplicate_key
               for other in rows)

def _existing_task_keys(rows=None):
    return {key for task in (tasks if rows is None else rows)
            if (key := _task_duplicate_key(task.get('name'), task.get('title')))}

def _new_task_record(task_id, title, name, task_time, status, submitted_by,
                     submitted_at=None, import_id=None):
    task = {'id': task_id, 'title': title, 'status': status, 'done': False,
            'name': name, 'time': task_time,
            'submitted_at': submitted_at or datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'submitted_by': submitted_by}
    if import_id:
        task['_import_id'] = import_id
    return task

@app.post('/api/tasks')
def add_task(item: TaskInput, user=Depends(optional_user)):   # public; records who submitted if logged in
    global next_id
    if not item.name or not item.name.strip() or not item.title.strip():
        raise HTTPException(status_code=422, detail='Employee name and task description are required.')
    if store is not None:
        task = store.add_task(item.title, item.name or '', item.time or '', item.status,
                              user['username'] if user else None)
        _invalidate_analytics()
        return _public_task(task)
    with _task_store_lock(refresh=True):
        if _task_duplicate_key(item.name, item.title) in _existing_task_keys():
            raise HTTPException(status_code=409, detail='This employee already has a task with the same description.')
        task = _new_task_record(next_id, item.title, item.name or '', item.time or '', item.status,
                                user['username'] if user else None)
        next_id += 1
        tasks.append(task)
        _save_tasks()
    return _public_task(task)

def _import_text(value):
    if value is None:
        return ''
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, bool):
        return ''
    return str(value).strip()

def _import_time(value, epoch):
    if value is None or (isinstance(value, str) and not value.strip()):
        return ''
    if isinstance(value, datetime):
        value = value.time()
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        if not 0 <= value < 1:
            return None
        value = from_excel(value, epoch)
        if isinstance(value, datetime):
            value = value.time()
    if isinstance(value, datetime_time):
        if value.hour == 0 and value.minute == 0 and value.second == 0:
            return '12:00 AM'
        return value.strftime('%I:%M %p').lstrip('0')
    if not isinstance(value, str):
        return None
    match = re.fullmatch(r'(0?[1-9]|1[0-2]):([0-5][0-9])\s*(AM|PM)', value.strip(), re.IGNORECASE)
    if not match:
        return None
    return f"{int(match.group(1))}:{match.group(2)} {match.group(3).upper()}"

def _parse_task_import(contents, existing_keys=None):
    try:
        workbook = load_workbook(io.BytesIO(contents), read_only=True, data_only=True)
    except Exception as exc:
        raise HTTPException(status_code=422, detail="Could not read this Excel file. Select a valid .xlsx workbook.") from exc
    try:
        sheet = workbook.active
        iterator = sheet.iter_rows(values_only=True)
        header_row = next(iterator, None)
        if not header_row:
            raise HTTPException(status_code=422, detail="The Excel file has no header row.")
        header_map = {}
        for index, value in enumerate(header_row):
            normalized = re.sub(r'[^a-z0-9]', '', str(value or '').casefold())
            if normalized:
                header_map[normalized] = index
        name_column = header_map.get('name')
        task_column = header_map.get('tasks', header_map.get('task'))
        time_column = header_map.get('timeampm', header_map.get('time'))
        serial_column = header_map.get('sno', header_map.get('serialno'))
        if None in (name_column, task_column, time_column, serial_column):
            raise HTTPException(status_code=422, detail="Required columns: S.No, Name, Tasks, and Time (AM/PM).")

        valid_rows, errors, duplicates, seen = [], [], [], set()
        existing_keys = existing_keys or set()
        total_rows = 0
        for row_number, values in enumerate(iterator, start=2):
            if not any(value is not None and (not isinstance(value, str) or value.strip()) for value in values):
                continue
            total_rows += 1
            if total_rows > MAX_IMPORT_ROWS:
                raise HTTPException(status_code=413, detail=f"Excel files may contain up to {MAX_IMPORT_ROWS:,} data rows.")
            serial = values[serial_column] if serial_column < len(values) else None
            serial_key = _import_text(serial).casefold()
            reference = serial_key or str(row_number)
            name_value = values[name_column] if name_column < len(values) else None
            task_value = values[task_column] if task_column < len(values) else None
            time_value = values[time_column] if time_column < len(values) else None
            name = _import_text(name_value)
            task = _import_text(task_value)
            task_time = _import_time(time_value, workbook.epoch)
            messages = []
            if not name:
                messages.append('Name is required.')
            elif len(name) > 100:
                messages.append('Name must be 100 characters or fewer.')
            if not task:
                messages.append('Tasks is required.')
            elif len(task) > 200:
                messages.append('Tasks must be 200 characters or fewer.')
            if task_time is None:
                messages.append('Time must be blank or a valid time such as 10:30 AM.')
            if messages:
                errors.append({'row_number': row_number, 'reference': reference, 'messages': messages})
                continue
            key = _task_duplicate_key(name, task)
            if key in seen or key in existing_keys:
                reason = ('Duplicate employee and task in this workbook; first occurrence is kept.'
                          if key in seen else 'Duplicate employee and task already exists.')
                duplicates.append({'row_number': row_number, 'reference': reference, 'messages': [reason]})
                continue
            seen.add(key)
            valid_rows.append({'name': name, 'title': task, 'time': task_time,
                               'row_number': row_number, 'reference': reference})
        return valid_rows, errors, duplicates, total_rows
    finally:
        workbook.close()

@app.post('/api/tasks/import/validate')
async def validate_task_import(request: Request, user=Depends(optional_user)):
    content_length = request.headers.get('content-length')
    if content_length and int(content_length) > MAX_IMPORT_BYTES:
        raise HTTPException(status_code=413, detail='Excel file must be 20 MB or smaller.')
    contents = await request.body()
    if not contents:
        raise HTTPException(status_code=400, detail='Select an Excel file to import.')
    if len(contents) > MAX_IMPORT_BYTES:
        raise HTTPException(status_code=413, detail='Excel file must be 20 MB or smaller.')
    if store is not None:
        existing_keys = store.existing_task_keys()
    else:
        with _task_store_lock(refresh=True):
            existing_keys = _existing_task_keys()
    valid_rows, errors, duplicates, total_rows = await run_in_threadpool(_parse_task_import, contents, existing_keys)
    identity = sorted((_normalize_duplicate_text(r['name']), _normalize_duplicate_text(r['title'])) for r in valid_rows)
    import_id = hashlib.sha256(json.dumps(identity, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()
    stage_id = secrets.token_urlsafe(24)
    with _pending_imports_lock:
        cutoff = datetime.now(timezone.utc).timestamp() - IMPORT_STAGE_TTL_SECONDS
        for key in [key for key, stage in _pending_imports.items() if stage['created_at'] < cutoff]:
            _pending_imports.pop(key, None)
        _pending_imports[stage_id] = {
            'import_id': import_id,
            'rows': valid_rows,
            'errors': errors,
            'duplicates': duplicates,
            'total_rows': total_rows,
            'created_at': datetime.now(timezone.utc).timestamp(),
            'submitted_by': user['username'] if user else None,
        }
    return {'import_id': stage_id, 'valid_count': len(valid_rows), 'accepted_count': len(valid_rows),
            'duplicate_count': len(duplicates), 'invalid_count': len(errors), 'total_rows': total_rows,
            'errors': errors, 'duplicates': duplicates}

class TaskImportCommit(BaseModel):
    import_id: str = Field(min_length=20, max_length=100)

def _commit_task_import(stage_id):
    global next_id
    with _pending_imports_lock:
        stage = _pending_imports.get(stage_id)
    if not stage:
        raise HTTPException(status_code=404, detail='Import preview expired. Select the file again.')
    if store is not None:
        return _commit_task_import_mysql(stage_id, stage)
    with _task_store_lock(refresh=True):
        existing_keys = _existing_task_keys()
        rows_to_add, concurrent_duplicates = [], []
        for row in stage['rows']:
            key = _task_duplicate_key(row['name'], row['title'])
            if key in existing_keys:
                concurrent_duplicates.append({'row_number': row['row_number'], 'reference': row['reference'],
                    'messages': ['Duplicate employee and task was saved after this preview was validated.']})
            else:
                existing_keys.add(key)
                rows_to_add.append(row)
        now = datetime.now(timezone.utc).isoformat(timespec='seconds')
        accounts = auth.load_users()
        existing_profile_keys = set()
        for username, account in accounts.items():
            if auth.is_active(account):
                existing_profile_keys.add(_profile_name_key(username))
                existing_profile_keys.add(_profile_name_key(account.get('name')))
        existing_profile_keys.update(_profile_name_key(task.get('name')) for task in tasks if _profile_name_key(task.get('name')))
        incoming_profile_keys = {_profile_name_key(row['name']) for row in rows_to_add}
        profiles_updated = len(incoming_profile_keys & existing_profile_keys)
        profiles_created = len(incoming_profile_keys - existing_profile_keys)
        base_id = next_id
        additions = [
            _new_task_record(base_id + index, row['title'], row['name'], row['time'], 'pending',
                             stage['submitted_by'], submitted_at=now, import_id=stage['import_id'])
            for index, row in enumerate(rows_to_add)
        ]
        if additions:
            tasks.extend(additions)
            next_id += len(additions)
            try:
                _save_tasks()
            except Exception as exc:
                del tasks[-len(additions):]
                next_id = base_id
                raise HTTPException(status_code=500, detail='Import was not saved. No task records were added.') from exc
        total = len(tasks)
    with _pending_imports_lock:
        _pending_imports.pop(stage_id, None)
    all_duplicates = stage['duplicates'] + concurrent_duplicates
    return {'imported_count': len(additions), 'accepted_count': len(additions),
            'duplicate_count': len(all_duplicates), 'invalid_count': len(stage['errors']),
            'rejected_count': len(all_duplicates) + len(stage['errors']),
            'failed_count': len(all_duplicates) + len(stage['errors']),
            'total_rows': stage['total_rows'], 'errors': stage['errors'], 'duplicates': all_duplicates, 'total': total,
            'unique_employee_count': len(incoming_profile_keys),
            'newly_created_profiles': profiles_created,
            'existing_profiles_updated': profiles_updated}

def _commit_task_import_mysql(stage_id, stage):
    """MySQL variant of _commit_task_import: one atomic transaction, same response."""
    rows_to_add, concurrent_duplicates, prior_names, total = store.import_tasks(
        stage['rows'], stage['import_id'], stage['submitted_by'])
    accounts = auth.load_users()
    existing_profile_keys = set()
    for username, account in accounts.items():
        if auth.is_active(account):
            existing_profile_keys.add(_profile_name_key(username))
            existing_profile_keys.add(_profile_name_key(account.get('name')))
    existing_profile_keys.update(_profile_name_key(name) for name in prior_names if _profile_name_key(name))
    incoming_profile_keys = {_profile_name_key(row['name']) for row in rows_to_add}
    profiles_updated = len(incoming_profile_keys & existing_profile_keys)
    profiles_created = len(incoming_profile_keys - existing_profile_keys)
    if rows_to_add:
        _invalidate_analytics()
    with _pending_imports_lock:
        _pending_imports.pop(stage_id, None)
    all_duplicates = stage['duplicates'] + concurrent_duplicates
    return {'imported_count': len(rows_to_add), 'accepted_count': len(rows_to_add),
            'duplicate_count': len(all_duplicates), 'invalid_count': len(stage['errors']),
            'rejected_count': len(all_duplicates) + len(stage['errors']),
            'failed_count': len(all_duplicates) + len(stage['errors']),
            'total_rows': stage['total_rows'], 'errors': stage['errors'], 'duplicates': all_duplicates, 'total': total,
            'unique_employee_count': len(incoming_profile_keys),
            'newly_created_profiles': profiles_created,
            'existing_profiles_updated': profiles_updated}

@app.post('/api/tasks/import/commit')
async def commit_task_import(item: TaskImportCommit):
    return await run_in_threadpool(_commit_task_import, item.import_id)

@app.patch('/api/tasks/{task_id}')   # public, like the rest of MY TASKS
def update_task(task_id: int, item: TaskInput):
    if store is not None:
        task = store.update_task(task_id, item.title, item.status, item.name, item.time)
        _invalidate_analytics()
        return _public_task(task)
    with _task_store_lock(refresh=True):
        for task in tasks:
            if task['id'] == task_id:
                next_name = item.name if item.name is not None else task.get('name', '')
                if not next_name.strip() or not item.title.strip():
                    raise HTTPException(status_code=422, detail='Employee name and task description are required.')
                if _edit_creates_duplicate(task_id, task.get('name'), task.get('title'), next_name, item.title, tasks):
                    raise HTTPException(status_code=409, detail='This employee already has a task with the same description.')
                task['title'] = item.title
                task['status'] = item.status
                task['name'] = next_name
                if item.time is not None: task['time'] = item.time
                _save_tasks()
                return _public_task(task)
    raise HTTPException(status_code=404, detail="Task not found")

class DeleteAllTasksInput(BaseModel):
    confirmation: str
    expected_count: int = Field(ge=0)

@app.delete('/api/admin/tasks')
def delete_all_tasks(item: DeleteAllTasksInput, user=Depends(require_role('admin'))):
    """Delete all task records only; user accounts and Old PF history are separate."""
    global tasks
    if item.confirmation != 'DELETE ALL':
        raise HTTPException(status_code=400, detail='Type DELETE ALL to confirm.')
    if store is not None:
        count = store.delete_all_tasks(item.expected_count)
        if count:
            _invalidate_analytics()
        return {'deleted_count': count, 'total': 0}
    with _task_store_lock(refresh=True):
        count = len(tasks)
        if item.expected_count != count:
            raise HTTPException(status_code=409, detail=f'Task count changed; refresh before deleting. Current count: {count}.')
        if not count:
            return {'deleted_count': 0, 'total': 0}
        previous = tasks
        tasks = []
        try:
            _save_tasks()
        except Exception as exc:
            tasks = previous
            raise HTTPException(status_code=500, detail='Could not persist task deletion.') from exc
    return {'deleted_count': count, 'total': 0}

@app.delete('/api/tasks/{task_id}')   # public, like the rest of MY TASKS
def delete_task(task_id: int):
    global tasks
    if store is not None:
        store.delete_task(task_id)
        _invalidate_analytics()
        return {'ok': True}
    with _task_store_lock(refresh=True):
        tasks = [task for task in tasks if task['id'] != task_id]
        _save_tasks()
    return {'ok': True}

# ---- Admin dashboard (admin role only) ----
def _admin_row(t, names):
    """One task as shown to the admin, with the submission time converted to IST."""
    stamp = t.get('submitted_at')
    local = datetime.fromisoformat(stamp).astimezone(IST) if stamp else None
    return {
        'id': t['id'],
        'employee_name': t.get('name') or names.get(t.get('submitted_by'), ''),
        'task': t['title'],
        'task_time': t.get('time', ''),                       # time picked by the user
        'status': 'Completed' if t['status'] == 'completed' else 'Pending',
        'submitted_by': names.get(t.get('submitted_by'), t.get('submitted_by')) if t.get('submitted_by') else ('Visitor' if stamp else None),
        'submitted_date': local.strftime('%d %b %Y') if local else None,              # e.g. 05 Nov 2026
        'submitted_time': local.strftime('%I:%M:%S %p').lstrip('0') if local else None,  # e.g. 2:07:45 PM
    }

@app.get('/api/admin/tasks')
def admin_tasks(offset: int | None = None, limit: int | None = None, q: str = '', status: str = 'all', sort: str = 'newest', user=Depends(require_role('admin'))):
    names = {u['username']: u['name'] for u in auth.load_users().values()}
    if offset is None and limit is None:
        return [_admin_row(t, names) for t in _task_rows()]
    offset = offset or 0
    limit = 100 if limit is None else limit
    if offset < 0 or limit < 1 or limit > 200:
        raise HTTPException(status_code=422, detail="Use an offset >= 0 and a limit between 1 and 200")
    if status not in ('all', 'pending', 'completed') or sort not in ('newest', 'oldest', 'name', 'task'):
        raise HTTPException(status_code=422, detail="Invalid task filter or sort option")
    if store is not None:
        total, all_total, rows = store.page_tasks((q or '').strip().casefold(), status, sort, offset, limit)
        return {'items': [_admin_row(task, names) for task in rows], 'total': total, 'all_total': all_total,
                'stats': store.task_stats(), 'offset': offset, 'limit': limit}
    with _tasks_lock:
        filtered = _filter_sort_tasks(list(tasks), q, status, sort)
        total = len(filtered)
        page = [_admin_row(task, names) for task in filtered[offset:offset + limit]]
    return {'items': page, 'total': total, 'all_total': len(tasks), 'stats': {'total': len(tasks), 'completed': sum(1 for task in tasks if task.get('status') == 'completed'), 'pending': sum(1 for task in tasks if task.get('status') != 'completed')}, 'offset': offset, 'limit': limit}

@app.get('/api/admin/tasks/export')
def export_admin_tasks(format: str, user=Depends(require_role('admin'))):
    """Download every stored task for authenticated administrators only."""
    if format not in ('xlsx', 'csv'):
        raise HTTPException(status_code=400, detail="Format must be xlsx or csv")

    if store is not None:
        snapshot = store.all_tasks()
    else:
        with _tasks_lock:
            snapshot = [dict(task) for task in tasks]
    if not snapshot:
        return StreamingResponse(io.BytesIO(b''), status_code=204)

    names = {u['username']: u['name'] for u in auth.load_users().values()}
    headers = ['S.No', 'Employee Name', 'Task Description', 'Task Time (AM/PM)',
               'Submission Date (IST)', 'Submission Time (IST)', 'Status (Completed / Pending)']
    rows = []
    for index, task in enumerate(snapshot, start=1):
        row = _admin_row(task, names)
        rows.append([index, row['employee_name'], row['task'], row['task_time'],
                     row['submitted_date'] or '', row['submitted_time'] or '', row['status']])

    filename = f"Admin_Tasks_{datetime.now(IST):%Y-%m-%d}.{format}"
    if format == 'csv':
        output = io.StringIO(newline='')
        writer = csv.writer(output)
        writer.writerow(headers)
        writer.writerows(rows)
        content = ('\ufeff' + output.getvalue()).encode('utf-8')
        media_type = 'text/csv; charset=utf-8'
    else:
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = 'Admin Tasks'
        sheet.append(headers)
        for cell in sheet[1]:
            cell.font = Font(bold=True)
        for row in rows:
            sheet.append(row)
        for column in sheet.columns:
            letter = column[0].column_letter
            width = max(len(str(cell.value or '')) for cell in column)
            sheet.column_dimensions[letter].width = min(max(width + 2, 12), 48)
        sheet.freeze_panes = 'A2'
        sheet.auto_filter.ref = sheet.dimensions
        buffer = io.BytesIO()
        workbook.save(buffer)
        content = buffer.getvalue()
        media_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

    return StreamingResponse(io.BytesIO(content), media_type=media_type,
                             headers={'Content-Disposition': f'attachment; filename="{filename}"'})

# ---- User profiles (admin role only) ----
def _task_owner(t, accounts):
    """Match the employee name to a profile first, then fall back to submitter."""
    typed = _profile_name_key(t.get('name'))
    for username, u in accounts.items():
        if typed and typed in (_profile_name_key(username), _profile_name_key(u.get('name'))):
            return username
    if t.get('submitted_by'):
        return t['submitted_by']
    return None

def _profiles(accounts, only=None):
    """Active account cards plus task-backed cards for names without an active account."""
    profiles = []
    active_accounts = {username: u for username, u in accounts.items() if auth.is_active(u)}
    by_name = {}
    for username, u in active_accounts.items():
        by_name.setdefault(_profile_name_key(u['name']), username)
        by_name.setdefault(_profile_name_key(username), username)

    counts = {username: [] for username in active_accounts}
    generated = {}
    for task in _task_rows():
        employee_name = ' '.join((task.get('name') or '').split())
        account_username = by_name.get(_profile_name_key(employee_name)) if employee_name else None
        if not employee_name and task.get('submitted_by') in active_accounts:
            account_username = task['submitted_by']
        if account_username:
            counts[account_username].append(task['status'] == 'completed')
        elif employee_name:
            key = _profile_name_key(employee_name)
            generated.setdefault(key, {'name': employee_name, 'done': []})['done'].append(task['status'] == 'completed')

    for username, u in accounts.items():
        if (only is not None and username not in only) or username not in active_accounts:
            continue
        mine = counts[username]
        profiles.append({**auth.public_user(u),
                         'total': len(mine), 'completed': sum(mine), 'pending': len(mine) - sum(mine)})
    if only is None:
        for key, data in generated.items():
            mine = data['done']
            profile_id = 'task-' + hashlib.sha256(key.encode('utf-8')).hexdigest()[:16]
            profiles.append({'username': profile_id, 'name': data['name'], 'role': 'user',
                             'task_generated': True, 'total': len(mine),
                             'completed': sum(mine), 'pending': len(mine) - sum(mine)})
    return profiles

@app.get('/api/admin/users')
def admin_users(user=Depends(require_role('admin'))):
    return _profiles(auth.load_users())

# ---- Analytics (aggregated from the existing JSON task store) ----
_analytics_cache = {}
_analytics_cache_lock = threading.Lock()

def _analytics_snapshot():
    """Build compact task aggregates. No raw task list is sent to the browser."""
    today = datetime.now(IST).date()
    accounts = auth.load_users()
    active = {name: account for name, account in accounts.items() if auth.is_active(account)}
    by_name = {}
    for username, account in active.items():
        by_name.setdefault(_profile_name_key(username), username)
        by_name.setdefault(_profile_name_key(account.get('name')), username)
    normalized = []
    if store is not None:
        rows = store.all_tasks()
    else:
        with _tasks_lock:
            rows = [dict(task) for task in tasks]
    for task in rows:
        stamp = None
        try:
            raw = task.get('submitted_at')
            stamp = datetime.fromisoformat(raw.replace('Z', '+00:00')) if raw else None
            if stamp and stamp.tzinfo is None:
                stamp = stamp.replace(tzinfo=timezone.utc)
            if stamp:
                stamp = stamp.astimezone(IST)
        except (ValueError, TypeError, AttributeError):
            stamp = None
        name = ' '.join(str(task.get('name') or '').split())
        owner = by_name.get(_profile_name_key(name)) if name else None
        if owner is None and task.get('submitted_by') in active:
            owner = task['submitted_by']
        if owner is None and name:
            owner = 'task-' + hashlib.sha256(_profile_name_key(name).encode('utf-8')).hexdigest()[:16]
            active.setdefault(owner, {'username': owner, 'name': name, 'role': 'user'})
        done = str(task.get('status', '')).casefold() == 'completed'
        normalized.append((task, owner, done, stamp))
    return today, active, normalized

def _analytics_period(start, end, period, status, username=None):
    if period not in ('daily', 'weekly', 'monthly') or status not in ('all', 'pending', 'completed'):
        raise HTTPException(status_code=422, detail='Invalid analytics period or status.')
    today, active, rows = _analytics_snapshot()
    try:
        start_date = datetime.strptime(start, '%Y-%m-%d').date() if start else today - timedelta(days=29)
        end_date = datetime.strptime(end, '%Y-%m-%d').date() if end else today
    except ValueError:
        raise HTTPException(status_code=422, detail='Dates must use YYYY-MM-DD format.')
    if end_date < start_date or (end_date - start_date).days > 3660:
        raise HTTPException(status_code=422, detail='Choose a valid date range of at most 10 years.')
    if username is not None and username not in active:
        raise HTTPException(status_code=404, detail='User profile not found.')
    selected = []
    for task, owner, done, stamp in rows:
        if username is not None and owner != username:
            continue
        if not stamp or not (start_date <= stamp.date() <= end_date):
            continue
        if status == 'completed' and not done or status == 'pending' and done:
            continue
        selected.append((task, owner, done, stamp))
    total = len(selected)
    done_count = sum(done for _, _, done, _ in selected)
    buckets = Counter()
    per_user = Counter()
    active_days = set()
    heat = Counter()
    for task, owner, done, stamp in selected:
        if stamp:
            day = stamp.date()
            if period == 'daily': key = day.isoformat()
            elif period == 'weekly': key = (day - timedelta(days=day.weekday())).isoformat()
            else: key = day.replace(day=1).isoformat()
            buckets[key] += 1
            heat[day.isoformat()] += 1
            if day >= today - timedelta(days=6): active_days.add(owner or task.get('submitted_by') or task.get('name'))
        if owner: per_user[owner] += 1
    labels, values = [], []
    cursor = start_date
    while cursor <= end_date:
        if period == 'daily': key = cursor.isoformat(); cursor += timedelta(days=1)
        elif period == 'weekly':
            key = (cursor - timedelta(days=cursor.weekday())).isoformat(); cursor += timedelta(days=7)
        else:
            key = cursor.replace(day=1).isoformat()
            cursor = (cursor.replace(day=28) + timedelta(days=4)).replace(day=1)
        if not labels or labels[-1] != key:
            labels.append(key); values.append(buckets.get(key, 0))
    top = []
    for key, count in per_user.most_common(20):
        account = active.get(key, {})
        top.append({'username': key, 'name': account.get('name', key), 'total': count,
                    'completed': sum(1 for _, owner, done, _ in selected if owner == key and done),
                    'pending': count - sum(1 for _, owner, done, _ in selected if owner == key and done)})
    all_users = len(active)
    return {'summary': {'total_users': all_users if username is None else 1, 'total_tasks': total,
        'completed': done_count, 'pending': total - done_count,
        'completion_rate': round(done_count * 100 / total, 2) if total else 0,
        'submitted_today': sum(1 for _, owner, _, stamp in selected if stamp and stamp.date() == today),
        'active_users': len({owner for _, owner, _, stamp in selected if owner and stamp and start_date <= stamp.date() <= end_date}),
        'average_tasks_per_user': round(total / max(1, all_users if username is None else 1), 2)},
        'series': {'labels': labels, 'tasks': values},
        'daily_activity': [{'date': key, 'count': count} for key, count in sorted(heat.items())],
        'top_users': top,
        'workload': [{'name': active[key].get('name', key), 'total': count,
                      'completed': sum(1 for _, owner, done, _ in selected if owner == key and done),
                      'pending': count - sum(1 for _, owner, done, _ in selected if owner == key and done)}
                     for key, count in per_user.most_common(12)],
        'status_filter': status, 'period': period, 'start': start_date.isoformat(), 'end': end_date.isoformat()}

@app.get('/api/admin/analytics')
def admin_analytics(start: str = '', end: str = '', period: str = 'daily', status: str = 'all', user=Depends(require_role('admin'))):
    key = (start, end, period, status)
    now = datetime.now(timezone.utc).timestamp()
    with _analytics_cache_lock:
        cached = _analytics_cache.get(key)
        if cached and now - cached[0] < 8:
            return cached[1]
    result = _analytics_period(start, end, period, status)
    with _analytics_cache_lock:
        _analytics_cache.clear()
        _analytics_cache[key] = (now, result)
    return result

@app.get('/api/admin/analytics/users')
def analytics_users(q: str = '', offset: int = 0, limit: int = 12, user=Depends(require_role('admin'))):
    if offset < 0 or limit < 1 or limit > 15:
        raise HTTPException(status_code=422, detail='Use offset >= 0 and limit between 1 and 15.')
    profiles = _profiles(auth.load_users())
    query = q.strip().casefold()
    if query:
        profiles = [p for p in profiles if query in p['name'].casefold() or query in p['username'].casefold()]
    return {'items': [{'username': p['username'], 'name': p['name'], 'role': p['role'], 'task_generated': p.get('task_generated', False)} for p in profiles[offset:offset + limit]], 'total': len(profiles), 'offset': offset, 'limit': limit}

@app.get('/api/admin/analytics/users/{username}')
def admin_user_analytics(username: str, start: str = '', end: str = '', period: str = 'daily', status: str = 'all', user=Depends(require_role('admin'))):
    profile = next((p for p in _profiles(auth.load_users()) if p['username'] == username), None)
    if not profile:
        raise HTTPException(status_code=404, detail='User profile not found.')
    result = _analytics_period(start, end, period, status, username)
    result['profile'] = {'username': username, 'name': profile.get('name', username), 'role': profile.get('role', 'user')}
    return result

@app.get('/api/my/analytics')
def my_analytics(start: str = '', end: str = '', period: str = 'daily', status: str = 'all', user=Depends(current_user)):
    result = _analytics_period(start, end, period, status, user['username'])
    result['profile'] = {'username': user['username'], 'name': user.get('name', user['username']), 'role': user['role']}
    return result

def _analytics_export_response(result, export_format):
    if export_format not in ('csv', 'xlsx'):
        raise HTTPException(status_code=422, detail='Format must be csv or xlsx.')
    summary = result['summary']
    if export_format == 'csv':
        output = io.StringIO(newline='')
        writer = csv.writer(output)
        writer.writerow(['Metric', 'Value'])
        writer.writerows(summary.items())
        writer.writerow([])
        writer.writerow(['Date', 'Tasks submitted'])
        writer.writerows(zip(result['series']['labels'], result['series']['tasks']))
        if result['top_users']:
            writer.writerow([])
            writer.writerow(['Employee', 'Total', 'Completed', 'Pending'])
            writer.writerows((u['name'], u['total'], u['completed'], u['pending']) for u in result['top_users'])
        content = ('\ufeff' + output.getvalue()).encode('utf-8')
        media_type = 'text/csv; charset=utf-8'
    else:
        workbook = Workbook()
        overview = workbook.active
        overview.title = 'Summary'
        overview.append(['Metric', 'Value'])
        for row in summary.items(): overview.append(list(row))
        trend = workbook.create_sheet('Submission Trend')
        trend.append(['Date', 'Tasks submitted'])
        for row in zip(result['series']['labels'], result['series']['tasks']): trend.append(list(row))
        if result['top_users']:
            ranking = workbook.create_sheet('Top Employees')
            ranking.append(['Employee', 'Total', 'Completed', 'Pending'])
            for employee in result['top_users']:
                ranking.append([employee['name'], employee['total'], employee['completed'], employee['pending']])
        for sheet in workbook.worksheets:
            for cell in sheet[1]: cell.font = Font(bold=True)
            sheet.freeze_panes = 'A2'
            sheet.auto_filter.ref = sheet.dimensions
            for column in sheet.columns:
                letter = column[0].column_letter
                sheet.column_dimensions[letter].width = min(max(max(len(str(cell.value or '')) for cell in column) + 2, 12), 42)
        buffer = io.BytesIO(); workbook.save(buffer); content = buffer.getvalue()
        media_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    filename = f"Task_Analytics_{datetime.now(IST):%Y-%m-%d}.{export_format}"
    return StreamingResponse(io.BytesIO(content), media_type=media_type,
                             headers={'Content-Disposition': f'attachment; filename="{filename}"'})

@app.get('/api/admin/analytics/export')
def admin_analytics_export(format: str, start: str = '', end: str = '', period: str = 'daily', status: str = 'all', username: str = '', user=Depends(require_role('admin'))):
    result = _analytics_period(start, end, period, status, username or None)
    return _analytics_export_response(result, format)

@app.get('/api/my/analytics/export')
def my_analytics_export(format: str, start: str = '', end: str = '', period: str = 'daily', status: str = 'all', user=Depends(current_user)):
    result = _analytics_period(start, end, period, status, user['username'])
    return _analytics_export_response(result, format)

@app.get('/api/admin/task-profiles/{employee_name}/tasks')
def admin_task_profile_tasks(employee_name: str, user=Depends(require_role('admin'))):
    key = _profile_name_key(employee_name)
    accounts = auth.load_users()
    return [_admin_row(t, {k: v['name'] for k, v in accounts.items()})
            for t in _task_rows() if _profile_name_key(t.get('name')) == key]

@app.get('/api/admin/old-pf')
def old_pf_users(offset: int | None = None, limit: int | None = None, user=Depends(require_role('admin'))):
    """Previously deactivated user records, retained in users.json."""
    records = [u for u in auth.load_users().values()
               if u.get('role') == 'user' and not auth.is_active(u)]
    result = [{
        'username': u['username'],
        'name': u.get('name') or 'Not Available',
        'profile': (u.get('pf_uan_number') or u.get('uan_number') or u.get('pf_number')
                    or u.get('profile') or 'Not Available'),
        'remarks': u.get('remarks') or 'Not Available',
    } for u in records]
    if offset is None and limit is None:
        return result
    offset = offset or 0
    limit = 100 if limit is None else limit
    if offset < 0 or limit < 1 or limit > 200:
        raise HTTPException(status_code=422, detail='Use an offset >= 0 and a limit between 1 and 200')
    return {'items': result[offset:offset + limit], 'total': len(result), 'offset': offset, 'limit': limit}

class NewUserInput(BaseModel):
    name: str = Field(min_length=1, max_length=50)
    username: str = Field(min_length=3, max_length=30, pattern=r'^[A-Za-z0-9_.-]+$')
    password: str = Field(min_length=auth.MIN_PASSWORD_LENGTH, max_length=128)

_users_lock = threading.Lock()

@app.post('/api/admin/users', status_code=201)
def create_user(item: NewUserInput, user=Depends(require_role('admin'))):
    """Admin creates a login account (always role 'user'); it appears as a profile card."""
    username = item.username.lower()
    name = ' '.join(item.name.split())
    if not name:
        raise HTTPException(status_code=422, detail="Name is required.")
    with _users_lock:   # one creation at a time, so duplicates can't slip in
        accounts = auth.load_users()
        if username in accounts:
            raise HTTPException(status_code=409, detail=f'Username "{username}" is already taken'
                                + ('.' if auth.is_active(accounts[username]) else ' (by a deleted account).'))
        clash = next((u for u in accounts.values() if u['name'].lower() == name.lower()), None)
        if clash:
            raise HTTPException(status_code=409, detail=f'A profile named "{name}" already exists'
                                + ('.' if auth.is_active(clash) else ' (deleted account).'))
        accounts[username] = {'username': username, 'name': name, 'role': 'user',
                              'password_hash': auth.hash_password(item.password)}
        if store is not None:
            store.create_user(username, name, accounts[username]['password_hash'])
        else:
            auth.save_users(accounts)   # persisted to users.json
        _invalidate_analytics()
    return _profiles(accounts, only={username})[0]

@app.delete('/api/admin/users/{username}')
def delete_user(username: str, user=Depends(require_role('admin'))):
    """Deactivate a normal user's account. Their task history is kept for admin records."""
    username = username.lower()
    with _users_lock:
        accounts = auth.load_users()
        record = accounts.get(username)
        if not record or not auth.is_active(record):
            raise HTTPException(status_code=404, detail="User not found")
        if record['role'] == 'admin' or username == user['username']:
            raise HTTPException(status_code=400, detail="Admin accounts cannot be deleted.")
        record.update({'active': False,
                       'deactivated_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
                       'deactivated_by': user['username']})
        if store is not None:
            store.deactivate_user(username, record['deactivated_at'], record['deactivated_by'])
        else:
            auth.save_users(accounts)        # persisted: stays deleted after a restart
        _invalidate_analytics()
    auth.end_sessions_for(username)      # signs them out immediately
    return {'ok': True, 'username': username, 'name': record['name']}

@app.get('/api/admin/users/{username}/tasks')
def admin_user_tasks(username: str, user=Depends(require_role('admin'))):
    accounts = auth.load_users()
    if username not in accounts:
        raise HTTPException(status_code=404, detail="User not found")
    names = {k: v['name'] for k, v in accounts.items()}
    return [_admin_row(t, names) for t in _task_rows() if _task_owner(t, accounts) == username]

# ---- Employee Work Details (in-memory, same as tasks) ----
class EmployeeWorkInput(BaseModel):
    employee_name: str
    work_done: str
    time: str

employee_work = []
next_employee_work_id = 1

@app.get('/api/employee-work', dependencies=[Depends(current_user)])
def get_employee_work():
    return employee_work if store is None else store.list_work()

@app.post('/api/employee-work', dependencies=[Depends(current_user)])
def add_employee_work(item: EmployeeWorkInput, user=Depends(current_user)):
    global next_employee_work_id
    if store is not None:
        return store.add_work(item.employee_name, item.work_done, item.time, user['username'])
    entry = {'id': next_employee_work_id, **item.model_dump()}
    next_employee_work_id += 1
    employee_work.append(entry)
    return entry

@app.patch('/api/employee-work/{entry_id}', dependencies=[Depends(current_user)])
def update_employee_work(entry_id: int, item: EmployeeWorkInput):
    if store is not None:
        return store.update_work(entry_id, item.employee_name, item.work_done, item.time)
    for entry in employee_work:
        if entry['id'] == entry_id:
            entry.update(item.model_dump())
            return entry
    raise HTTPException(status_code=404, detail="Entry not found")

@app.delete('/api/employee-work/{entry_id}', dependencies=[Depends(current_user)])
def delete_employee_work(entry_id: int):
    global employee_work
    if store is not None:
        store.delete_work(entry_id)
        return {'ok': True}
    employee_work = [e for e in employee_work if e['id'] != entry_id]
    return {'ok': True}
