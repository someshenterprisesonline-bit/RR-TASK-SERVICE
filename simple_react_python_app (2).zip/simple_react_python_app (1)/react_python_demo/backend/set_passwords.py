"""Set or reset passwords for the demo accounts. Passwords are hashed before
saving to users.json and are never printed or logged.

Usage (run from the backend folder):
  python set_passwords.py                    # prompts (hidden input) for every demo account
  python set_passwords.py --user jaga        # prompts for one account
  python set_passwords.py --from-file p.json # reads {"rithvik": "...", ...}; delete the file afterwards

Changes take effect on the next login; the server does not need restarting.
"""
import argparse
import getpass
import json
import sys

from auth import DEMO_USERS, MIN_PASSWORD_LENGTH, hash_password, load_users, save_users


def prompt_password(name: str) -> str:
    while True:
        first = getpass.getpass(f'New password for {name}: ')
        if len(first) < MIN_PASSWORD_LENGTH:
            print(f'  Password must be at least {MIN_PASSWORD_LENGTH} characters.')
            continue
        if getpass.getpass(f'Repeat password for {name}: ') != first:
            print('  Passwords did not match, try again.')
            continue
        return first


def main() -> int:
    parser = argparse.ArgumentParser(description='Set demo account passwords (stored hashed).')
    parser.add_argument('--user', help='only set the password for this username')
    parser.add_argument('--from-file', help='JSON file mapping username -> password (delete it afterwards)')
    args = parser.parse_args()

    accounts = DEMO_USERS
    if args.user:
        accounts = [a for a in DEMO_USERS if a[0] == args.user.lower()]
        if not accounts:
            print(f'Unknown user. Choose one of: {", ".join(a[0] for a in DEMO_USERS)}')
            return 1

    provided = {}
    if args.from_file:
        with open(args.from_file, encoding='utf-8') as f:
            provided = {k.lower(): v for k, v in json.load(f).items()}

    users = load_users()
    updated = []
    for username, name, role in accounts:
        if args.from_file:
            password = provided.get(username)
            if password is None:
                continue
            if len(password) < MIN_PASSWORD_LENGTH:
                print(f'Skipped {username}: password shorter than {MIN_PASSWORD_LENGTH} characters.')
                continue
        else:
            password = prompt_password(name)
        record = users.get(username, {})
        record.update({'username': username, 'name': name, 'role': role, 'password_hash': hash_password(password)})
        users[username] = record
        updated.append(username)

    save_users(users)
    print(f'Updated {len(updated)} account(s): {", ".join(updated) or "none"}')   # names only, never passwords
    return 0


if __name__ == '__main__':
    sys.exit(main())
