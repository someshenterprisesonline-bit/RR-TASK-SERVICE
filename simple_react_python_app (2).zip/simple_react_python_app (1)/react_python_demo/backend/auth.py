"""Authentication helpers: password hashing, demo accounts, and login sessions.

Passwords are hashed with PBKDF2-HMAC-SHA256 (Python standard library) using a
random per-user salt. Plain-text passwords are never stored or logged.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from pathlib import Path

# RR_USERS_FILE lets tests use a copy; the default is the real backend/users.json.
USERS_FILE = Path(os.environ.get('RR_USERS_FILE') or Path(__file__).with_name('users.json'))
ITERATIONS = 600_000
MIN_PASSWORD_LENGTH = 8
SESSION_TTL_SECONDS = 8 * 60 * 60          # sessions expire after 8 hours
MAX_FAILED_ATTEMPTS = 5                    # per username ...
LOCKOUT_SECONDS = 5 * 60                   # ... within / locked for 5 minutes

# Demo accounts: (username, display name, role). Roles are stored with each
# account in users.json and checked from there - never inferred from the name.
DEMO_USERS = [
    ('rithvik', 'Rithvik', 'admin'),
    ('jaga', 'Jaga', 'user'),
    ('deeraj', 'Deeraj', 'user'),
    ('ajay', 'Ajay', 'user'),
    ('harish', 'Harish', 'user'),
    ('basith', 'Basith', 'user'),
]
VALID_ROLES = {'admin', 'user'}


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode('ascii')


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, ITERATIONS)
    return f'pbkdf2_sha256${ITERATIONS}${_b64(salt)}${_b64(digest)}'


def verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, iterations, salt_b64, digest_b64 = stored.split('$')
        if algorithm != 'pbkdf2_sha256':
            return False
        salt, expected = base64.b64decode(salt_b64), base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


# Used to spend the same time on unknown usernames as on real ones.
DUMMY_HASH = hash_password(secrets.token_urlsafe(16))


# In MySQL mode main.py installs the MySQL store here; users.json is then never used.
_user_backend = None


def set_user_backend(backend) -> None:
    global _user_backend
    _user_backend = backend


def load_users() -> dict:
    """Return {username: record}. Read on every login so password changes apply immediately."""
    if _user_backend is not None:
        return _user_backend.load_users()
    if not USERS_FILE.exists():
        return {}
    with USERS_FILE.open(encoding='utf-8') as f:
        return {u['username']: u for u in json.load(f)}


def save_users(users: dict) -> None:
    if _user_backend is not None:
        raise RuntimeError('users.json must not be written while RR_STORAGE=mysql')
    tmp = USERS_FILE.with_suffix('.json.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(list(users.values()), f, indent=2)
    os.replace(tmp, USERS_FILE)
    try:
        os.chmod(USERS_FILE, 0o600)   # owner-only on POSIX; no effect on Windows
    except OSError:
        pass


def public_user(record: dict) -> dict:
    """Fields safe to send to the browser (never the password hash)."""
    return {'username': record['username'], 'name': record['name'], 'role': record['role']}


# ---- Sessions (in memory, like the task store) ----
_sessions: dict = {}
_failed: dict = {}
_lock = threading.Lock()


def create_session(record: dict) -> str:
    token = secrets.token_urlsafe(32)
    with _lock:
        _sessions[token] = {'user': public_user(record), 'expires': time.time() + SESSION_TTL_SECONDS}
    return token


def get_session_user(token: str):
    with _lock:
        session = _sessions.get(token)
        if not session:
            return None
        if session['expires'] < time.time():
            del _sessions[token]
            return None
        return session['user']


def end_session(token: str) -> None:
    with _lock:
        _sessions.pop(token, None)


def end_sessions_for(username: str) -> None:
    """Sign a user out everywhere (used when their account is deactivated)."""
    with _lock:
        for token in [t for t, s in _sessions.items() if s['user']['username'] == username]:
            del _sessions[token]


def is_active(record: dict) -> bool:
    """Accounts are active unless an admin has deleted (deactivated) them."""
    return record.get('active', True) is not False


def is_locked_out(username: str) -> bool:
    with _lock:
        recent = [t for t in _failed.get(username, []) if t > time.time() - LOCKOUT_SECONDS]
        _failed[username] = recent
        return len(recent) >= MAX_FAILED_ATTEMPTS


def record_failure(username: str) -> None:
    with _lock:
        _failed.setdefault(username, []).append(time.time())


def clear_failures(username: str) -> None:
    with _lock:
        _failed.pop(username, None)
