-- RR TASK SERVICE MySQL 8.0 schema preparation
-- Non-destructive: this file contains no DROP, TRUNCATE, or data-changing DML.
-- Existing tables are left untouched by CREATE TABLE IF NOT EXISTS.
-- IMPORTANT: IF NOT EXISTS does not verify an already-existing table's columns.
-- Inspect rr_task_service before running this file.

USE `rr_task_service`;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `users` (
    `user_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(30) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('admin', 'user') NOT NULL,
    `active` TINYINT(1) NOT NULL DEFAULT 1,
    `deactivated_at` VARCHAR(40) NULL,
    `deactivated_by` VARCHAR(30) NULL,
    PRIMARY KEY (`user_id`),
    UNIQUE KEY `uq_users_username` (`username`),
    KEY `ix_users_role_active` (`role`, `active`)
) ENGINE=InnoDB
  DEFAULT CHARACTER SET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `employees` (
    `employee_id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NULL,
    `name` VARCHAR(100) NOT NULL,
    `normalized_name` VARCHAR(150) NOT NULL,
    PRIMARY KEY (`employee_id`),
    UNIQUE KEY `uq_employees_user_id` (`user_id`),
    KEY `ix_employees_normalized_name` (`normalized_name`),
    CONSTRAINT `fk_employees_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
        ON UPDATE RESTRICT ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARACTER SET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `tasks` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `employee_id` BIGINT UNSIGNED NULL,
    `name` VARCHAR(100) NOT NULL COMMENT 'Original employee-name snapshot from tasks.json',
    `title` VARCHAR(200) NOT NULL,
    `status` VARCHAR(20) NOT NULL COMMENT 'Preserve source status text and capitalization',
    `done` TINYINT(1) NOT NULL COMMENT 'Legacy flag; preserve source value and do not derive from status',
    `time` VARCHAR(20) NOT NULL DEFAULT '' COMMENT 'Keep original time text such as 10:30 AM',
    `submitted_at` VARCHAR(40) NOT NULL COMMENT 'Exact source timestamp text, including its UTC offset',
    `submitted_at_utc` DATETIME(6) NULL COMMENT 'Normalized UTC copy for date filtering and analytics',
    `submitted_by` VARCHAR(100) NULL COMMENT 'Original submitter username snapshot',
    `submitted_by_user_id` BIGINT UNSIGNED NULL,
    `_import_id` VARCHAR(64) NULL,
    PRIMARY KEY (`id`),
    KEY `ix_tasks_status_id` (`status`, `id`),
    KEY `ix_tasks_submitted_at_status` (`submitted_at_utc`, `status`),
    KEY `ix_tasks_employee_submitted` (`employee_id`, `submitted_at_utc`),
    KEY `ix_tasks_submitter_submitted` (`submitted_by_user_id`, `submitted_at_utc`),
    KEY `ix_tasks_import_id` (`_import_id`),
    KEY `ix_tasks_employee_name_id` (`name`, `id`),
    CONSTRAINT `fk_tasks_employee`
        FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`)
        ON UPDATE RESTRICT ON DELETE SET NULL,
    CONSTRAINT `fk_tasks_submitter`
        FOREIGN KEY (`submitted_by_user_id`) REFERENCES `users` (`user_id`)
        ON UPDATE RESTRICT ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARACTER SET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci;

-- No uniqueness constraint is defined for employee name + task title:
-- the source data contains repeated pairs that must remain separate tasks.

CREATE TABLE IF NOT EXISTS `employee_work_entries` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `employee_id` BIGINT UNSIGNED NULL,
    `employee_name` VARCHAR(100) NOT NULL COMMENT 'Original employee-name snapshot',
    `work_done` TEXT NOT NULL,
    `time` VARCHAR(20) NOT NULL,
    `recorded_by_user_id` BIGINT UNSIGNED NULL,
    `created_at_utc` DATETIME(6) NULL COMMENT 'NULL when no source creation time exists',
    PRIMARY KEY (`id`),
    KEY `ix_employee_work_employee_id` (`employee_id`, `id`),
    KEY `ix_employee_work_recorder_id` (`recorded_by_user_id`, `id`),
    CONSTRAINT `fk_employee_work_employee`
        FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`)
        ON UPDATE RESTRICT ON DELETE SET NULL,
    CONSTRAINT `fk_employee_work_recorder`
        FOREIGN KEY (`recorded_by_user_id`) REFERENCES `users` (`user_id`)
        ON UPDATE RESTRICT ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARACTER SET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci;
