import React, { useState } from 'react';

/** Shared table workspace: CSS handles desktop hover; touch devices get a toggle. */
export default function ExpandableTableContainer({ children, scrollClassName = '', label = 'Data table' }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <section className={`expandable-table${expanded ? ' is-expanded' : ''}`} aria-label={`${label} workspace`}>
      <button type="button" className="table-expand-toggle" aria-expanded={expanded}
        onClick={() => setExpanded(value => !value)}>
        {expanded ? 'Collapse table' : 'Expand table'}
      </button>
      <div className={`table-scroll ${scrollClassName}`.trim()}>{children}</div>
    </section>
  );
}
