// Intro session state, kept apart from auth/task state.
// The intro auto-plays once per browser session, and only when the session starts on Home.
// A refresh, or moving between app pages, never replays it; only the Replay button does.
const KEY = 'rr-intro-seen';
let memorySeen = false; // used if sessionStorage is blocked

function readSeen() {
  try { return sessionStorage.getItem(KEY) === '1'; } catch { return memorySeen; }
}
function writeSeen() {
  memorySeen = true;
  try { sessionStorage.setItem(KEY, '1'); } catch { /* storage blocked: memory flag covers this page load */ }
}

export const prefersReducedMotion = () =>
  typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

export function isHomeHash(hash = window.location.hash) {
  const route = hash.split('?')[0];
  return !route || route === '#/' || route === '#/home';
}

let webglSupport = null;
export function supportsWebGL() {
  if (webglSupport !== null) return webglSupport;
  try {
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl2') || c.getContext('webgl');
    webglSupport = !!gl;
    gl?.getExtension('WEBGL_lose_context')?.loseContext();
  } catch { webglSupport = false; }
  return webglSupport;
}

// Decided once, when the app boots.
let bootDecision = null;
export function shouldAutoPlayIntro() {
  if (bootDecision === null) {
    bootDecision = typeof window !== 'undefined' && isHomeHash() && !readSeen() && !prefersReducedMotion();
    if (typeof window !== 'undefined') writeSeen();
  }
  return bootDecision;
}

// Start downloading the 3D scene chunk early (it is code-split from the main bundle).
let scenePromise = null;
export function loadIntroScene() {
  scenePromise ||= import('./introScene.js').catch(err => { scenePromise = null; throw err; });
  return scenePromise;
}
