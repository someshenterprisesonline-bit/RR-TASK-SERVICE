import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import './CinematicIntro.css';
import { loadIntroScene, prefersReducedMotion, shouldAutoPlayIntro, supportsWebGL } from './introSession.js';

// Kick off the 3D chunk download as early as possible when the intro is going to play.
if (typeof window !== 'undefined' && shouldAutoPlayIntro() && supportsWebGL()) loadIntroScene().catch(() => {});

const TIMINGS_2D = {
  fallback: { interactive: 4400, end: 5200 }, // no WebGL / 3D failed: lightweight DOM version
  calm: { interactive: 1800, end: 2600 },     // prefers-reduced-motion: opacity-only version
};
const SKIP_FADE_MS = 600;
const LOAD_TIMEOUT_MS = 6000;

function pickQuality() {
  const coarse = window.matchMedia?.('(pointer: coarse)').matches;
  const cores = navigator.hardwareConcurrency || 4;
  return (coarse && window.innerWidth < 900) || cores <= 4 ? 'low' : 'high';
}

function measure2D() {
  const title = document.querySelector('.rr-landing .rr-title');
  const logo = document.querySelector('.rr-landing .rr-logo-frame');
  if (!title || !logo) return null;
  const t = title.getBoundingClientRect(), l = logo.getBoundingClientRect(), cs = getComputedStyle(title);
  return {
    logo: { left: l.left, top: l.top, width: l.width, height: l.height },
    title: {
      left: t.left, top: t.top, width: t.width, height: t.height,
      fontSize: cs.fontSize, fontWeight: cs.fontWeight, fontFamily: cs.fontFamily,
      letterSpacing: cs.letterSpacing, lineHeight: cs.lineHeight, paddingLeft: cs.paddingLeft,
      color: cs.color, text: title.textContent,
    },
  };
}

function Intro2D({ layout }) {
  const text = layout?.title.text || 'RR TASK SERVICE';
  const titleStyle = layout ? {
    left: layout.title.left, top: layout.title.top, width: layout.title.width, height: layout.title.height,
    fontSize: layout.title.fontSize, fontWeight: layout.title.fontWeight, fontFamily: layout.title.fontFamily,
    letterSpacing: layout.title.letterSpacing, lineHeight: layout.title.lineHeight, paddingLeft: layout.title.paddingLeft,
    '--rr-cine-final': layout.title.color,
  } : undefined;
  return (
    <div className="rr-cine-2d" aria-hidden="true">
      <div className="rr-cine-2d-spot" />
      <img className="rr-cine-2d-logo" src="/rr-logo.webp" alt="" style={layout ? layout.logo : undefined} />
      <p className={`rr-cine-2d-title${layout ? '' : ' is-centered'}`} style={titleStyle}>
        {[...text].map((c, i) => <span key={i} style={{ '--i': i }}>{c}</span>)}
      </p>
      <div className="rr-cine-2d-glow" />
    </div>
  );
}

export default function CinematicIntro({ onDone }) {
  const overlayRef = useRef(null), canvasRef = useRef(null), glowRef = useRef(null);
  const sceneRef = useRef(null), finishedRef = useRef(false), releasedRef = useRef(false), timersRef = useRef([]);
  const [engine, setEngine] = useState(() => (prefersReducedMotion() ? 'calm' : supportsWebGL() ? '3d' : 'fallback'));
  const [leaving, setLeaving] = useState(false);
  const [cssFade, setCssFade] = useState(false);
  const [layout2D, setLayout2D] = useState(null);

  const later = (fn, ms) => { timersRef.current.push(setTimeout(fn, ms)); };

  // Landing page becomes interactive again (navigation, buttons).
  const release = useCallback(() => {
    if (releasedRef.current) return;
    releasedRef.current = true;
    const root = document.getElementById('root');
    if (root) root.inert = false;
    document.documentElement.style.removeProperty('overflow');
    setLeaving(true);
  }, []);

  const complete = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    release();
    // Keyboard users who were on "Skip intro" continue from the top of the landing page.
    if (overlayRef.current?.contains(document.activeElement)) {
      document.querySelector('.rr-landing .rr-wordmark')?.focus({ preventScroll: true });
    }
    onDone?.();
  }, [onDone, release]);

  const skip = useCallback(() => {
    if (finishedRef.current) return;
    if (sceneRef.current) { sceneRef.current.skip(); return; } // the scene fades itself out smoothly
    release();
    setCssFade(true);
    later(complete, SKIP_FADE_MS);
  }, [complete, release]);

  // Hold the landing page in its final state underneath, make it inert, lock scroll.
  useLayoutEffect(() => {
    const html = document.documentElement;
    const root = document.getElementById('root');
    window.scrollTo(0, 0);
    html.dataset.rrIntro = 'playing';
    html.style.overflow = 'hidden';
    if (root) root.inert = true;
    if (engine !== '3d') setLayout2D(measure2D());
    return () => {
      delete html.dataset.rrIntro;
      html.style.removeProperty('overflow');
      if (root) root.inert = false;
      timersRef.current.forEach(clearTimeout);
      timersRef.current = [];
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Escape skips, from anywhere.
  useEffect(() => {
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); skip(); } };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [skip]);

  // 3D engine
  useEffect(() => {
    if (engine !== '3d') return undefined;
    let cancelled = false, scene = null;
    const canvas = canvasRef.current;
    const onLost = e => { e.preventDefault(); if (!finishedRef.current) skip(); };
    canvas.addEventListener('webglcontextlost', onLost);
    const timeout = setTimeout(() => { if (!scene && !cancelled) setEngine('fallback'); }, LOAD_TIMEOUT_MS);
    loadIntroScene()
      .then(mod => (cancelled ? null : mod.createIntroScene({
        canvas, overlay: overlayRef.current, glowEl: glowRef.current, quality: pickQuality(),
        onInteractive: release, onComplete: complete,
        onTooSlow: st => { console.info('[RR intro] device too slow for 3D, using the lightweight version.', st); if (!cancelled) setEngine('fallback'); },
      })))
      .then(s => {
        if (!s) return;
        if (cancelled) { s.dispose(); return; }
        clearTimeout(timeout);
        scene = s;
        sceneRef.current = s;
        if (import.meta.env.DEV) window.__rrIntro = s;
        s.play();
      })
      .catch(err => {
        console.warn('[RR intro] 3D intro unavailable, using the lightweight version.', err);
        if (!cancelled) setEngine('fallback');
      });
    return () => {
      cancelled = true;
      clearTimeout(timeout);
      canvas.removeEventListener('webglcontextlost', onLost);
      sceneRef.current = null;
      if (import.meta.env.DEV && scene) {
        const st = scene.stats;
        window.__rrIntroLastStats = { frames: st.frames, avgFrameMs: +(st.total * 1000 / Math.max(1, st.frames - 6)).toFixed(2), worstFrameMs: +(st.worst * 1000).toFixed(1), worstAt: st.worstAt, spikes: st.spikes, pixelRatio: st.pixelRatio, quality: st.quality, downgraded: st.downgraded };
        if (window.__rrIntro === scene) delete window.__rrIntro;
      }
      scene?.dispose();
    };
  }, [engine, complete, release, skip]);

  // 2D engines (fallback / reduced motion)
  useEffect(() => {
    if (engine === '3d') return undefined;
    setLayout2D(measure2D());
    const t = TIMINGS_2D[engine];
    const a = setTimeout(release, t.interactive);
    const b = setTimeout(complete, t.end);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, [engine, complete, release]);

  return createPortal(
    <div
      ref={overlayRef}
      className={`rr-cine${leaving ? ' is-leaving' : ''}${cssFade ? ' is-css-fading' : ''}`}
      data-engine={engine}
      role="dialog"
      aria-modal="true"
      aria-label="RR Task Service intro"
    >
      <p className="rr-cine-sr">Intro animation. Press Escape or choose Skip intro to go straight to the page.</p>
      {engine === '3d' && <canvas ref={canvasRef} className="rr-cine-canvas" aria-hidden="true" />}
      {engine !== '3d' && <Intro2D layout={layout2D} />}
      <div ref={glowRef} className="rr-cine-glow" aria-hidden="true" />
      <button type="button" className="rr-cine-skip" onClick={skip}>
        Skip intro <span className="rr-cine-skip-key" aria-hidden="true">ESC</span>
      </button>
    </div>,
    document.body,
  );
}

// Hook used by the app shell. Intro state lives here, isolated from auth and task state.
export function useCinematicIntro(onHome) {
  const [run, setRun] = useState(() => ({ id: 1, open: shouldAutoPlayIntro() && onHome }));
  useEffect(() => { if (!onHome) setRun(r => (r.open ? { ...r, open: false } : r)); }, [onHome]);
  const replay = useCallback(() => setRun(r => ({ id: r.id + 1, open: true })), []);
  const prefetch = useCallback(() => {
    if (!prefersReducedMotion() && supportsWebGL()) loadIntroScene().catch(() => {});
  }, []);
  const close = useCallback(() => setRun(r => ({ ...r, open: false })), []);
  const element = run.open && onHome ? <CinematicIntro key={run.id} onDone={close} /> : null;
  return { element, replay, prefetch };
}
