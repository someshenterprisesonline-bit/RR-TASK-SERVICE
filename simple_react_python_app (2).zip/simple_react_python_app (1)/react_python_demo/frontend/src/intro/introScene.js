// RR TASK SERVICE — cinematic 3D intro scene (Three.js, loaded on demand).
//
// World units are "em" of the landing-page title: 1 unit = the title's CSS font size.
// The layout is measured from the real landing page DOM, so the final camera pose puts
// the 3D logo and the 3D heading letters exactly on top of the real ones, and the canvas
// can fade away without a cut or a layout jump.
import * as THREE from 'three';
import { TextGeometry } from 'three/examples/jsm/geometries/TextGeometry.js';
import { FontLoader } from 'three/examples/jsm/loaders/FontLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import fontJson from 'three/examples/fonts/helvetiker_bold.typeface.json';

// ---------- timeline (seconds) ----------
export const INTRO_TIMING = Object.freeze({
  lettersStart: 1.0,
  lampEnter: 3.0,
  tapContact: 4.62,
  glowPeak: 7.05,
  interactive: 7.3,
  end: 8.0,
});
const SKIP_FADE = 0.6;
const FOV = 30;
const TAN_HALF = Math.tan(THREE.MathUtils.degToRad(FOV / 2));
const LAMP_SCALE = 0.85;
const TAP_REACH = 0.92 * LAMP_SCALE; // shade-mouth reach of the strike pose, in em

// ---------- easing helpers ----------
const clamp01 = x => (x < 0 ? 0 : x > 1 ? 1 : x);
const lerp = (a, b, t) => a + (b - a) * t;
const seg = (t, a, b) => clamp01((t - a) / (b - a));
const smooth = x => x * x * (3 - 2 * x);
const smoother = x => x * x * x * (x * (x * 6 - 15) + 10);
const easeOutCubic = x => 1 - (1 - x) ** 3;
const easeInOutCubic = x => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
const easeOutBack = (x, s = 1.4) => 1 + (s + 1) * (x - 1) ** 3 + s * (x - 1) ** 2;
const wrapAngle = a => Math.atan2(Math.sin(a), Math.cos(a));
const lerpAngle = (a, b, t) => a + wrapAngle(b - a) * t;
const headingTo = (dx, dz) => Math.atan2(-dz, dx); // rotation.y that points local +x along (dx, dz)

// ---------- layout measured from the landing page ----------
const measureCtx = typeof document !== 'undefined' ? document.createElement('canvas').getContext('2d') : null;

export function measureLanding() {
  const vw = window.innerWidth, vh = window.innerHeight;
  const title = document.querySelector('.rr-landing .rr-title');
  const logo = document.querySelector('.rr-landing .rr-logo-frame');
  const textNode = title && [...title.childNodes].find(n => n.nodeType === Node.TEXT_NODE && n.textContent.trim());
  const cs = title && getComputedStyle(title);
  const fs = cs ? parseFloat(cs.fontSize) : 0;
  if (!title || !logo || !textNode || !fs || !measureCtx) return fallbackLayout(vw, vh);

  measureCtx.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
  const text = textNode.textContent;
  const range = document.createRange();
  const chars = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (!ch.trim()) continue;
    range.setStart(textNode, i);
    range.setEnd(textNode, i + 1);
    const r = range.getBoundingClientRect();
    const m = measureCtx.measureText(ch);
    chars.push({
      ch,
      inkL: r.left - m.actualBoundingBoxLeft,
      inkR: r.left + m.actualBoundingBoxRight,
      base: r.bottom - m.fontBoundingBoxDescent,
    });
  }
  if (!chars.length) return fallbackLayout(vw, vh);
  const floorPx = Math.max(...chars.map(c => c.base));
  const toX = px => (px - vw / 2) / fs;
  const toY = py => (floorPx - py) / fs;
  const lr = logo.getBoundingClientRect();
  const capEm = measureCtx.measureText('H').actualBoundingBoxAscent / fs;
  return {
    fs, vw, vh,
    capEm: capEm > 0.3 && capEm < 1 ? capEm : 0.72,
    letters: chars.map(c => ({ ch: c.ch, x: toX((c.inkL + c.inkR) / 2), y: toY(c.base), inkL: toX(c.inkL), inkR: toX(c.inkR) })),
    logo: { cx: toX(lr.left + lr.width / 2), cy: toY(lr.top + lr.height / 2), w: lr.width / fs, h: lr.height / fs },
    camY: toY(vh / 2),
    viewH: vh / fs,
    titleColor: cs.color,
  };
}

function fallbackLayout(vw, vh) {
  // Used only if the landing page is not in the DOM (should not happen on Home).
  const fs = Math.max(26, Math.min(58, vw * 0.05));
  const text = 'RR TASK SERVICE';
  const step = 0.9, letters = [];
  let x = -((text.length - 1) * step) / 2;
  for (const ch of text) { if (ch !== ' ') letters.push({ ch, x, y: 0, inkL: x - 0.33, inkR: x + 0.33 }); x += step; }
  return { fs, vw, vh, capEm: 0.72, letters, logo: { cx: 0, cy: 4, w: 6.4, h: 4.8 }, camY: 1.5, viewH: vh / fs, titleColor: 'rgb(240, 216, 125)' };
}

// ---------- small procedural assets ----------
function radialTexture(stops) {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  const grd = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  for (const [o, col] of stops) grd.addColorStop(o, col);
  g.fillStyle = grd;
  g.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

class HelixCurve extends THREE.Curve {
  constructor(radius, length, turns) { super(); this.radius = radius; this.length = length; this.turns = turns; }
  getPoint(t, target = new THREE.Vector3()) {
    const a = t * Math.PI * 2 * this.turns;
    return target.set(Math.cos(a) * this.radius, t * this.length, Math.sin(a) * this.radius);
  }
}

// ---------- the lamp mascot (original design: puck base, twin-rod arms with springs, bell shade) ----------
function buildLamp(env) {
  const graphite = new THREE.MeshStandardMaterial({ color: 0x2c2f35, metalness: 0.75, roughness: 0.3, envMap: env, envMapIntensity: 0.8 });
  const gold = new THREE.MeshStandardMaterial({ color: 0xd8ab52, metalness: 1, roughness: 0.28, envMap: env, envMapIntensity: 1.1 });
  const cream = new THREE.MeshStandardMaterial({ color: 0xefe9dc, metalness: 0.05, roughness: 0.42, envMap: env, envMapIntensity: 0.5, side: THREE.DoubleSide });
  const inner = new THREE.MeshStandardMaterial({ color: 0x1b140b, emissive: 0xffcf8f, emissiveIntensity: 0.25, roughness: 0.6, side: THREE.DoubleSide });
  const bulbMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(1, 0.93, 0.78), toneMapped: false });
  const mesh = (geo, mat, setup) => { const m = new THREE.Mesh(geo, mat); m.castShadow = true; m.receiveShadow = true; setup?.(m); return m; };

  const root = new THREE.Group();
  // base
  root.add(mesh(new THREE.CylinderGeometry(0.46, 0.53, 0.13, 48), graphite, m => { m.position.y = 0.065; }));
  root.add(mesh(new THREE.SphereGeometry(0.21, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), graphite, m => { m.position.y = 0.13; }));
  root.add(mesh(new THREE.TorusGeometry(0.47, 0.014, 8, 72), gold, m => { m.rotation.x = Math.PI / 2; m.position.y = 0.132; }));

  const hinge = () => mesh(new THREE.CylinderGeometry(0.085, 0.085, 0.24, 24), gold, m => { m.rotation.x = Math.PI / 2; });
  const arm = (len) => {
    const g = new THREE.Group();
    for (const z of [-0.075, 0.075]) g.add(mesh(new THREE.CylinderGeometry(0.032, 0.032, len, 12), graphite, m => { m.position.set(0, len / 2, z); }));
    g.add(mesh(new THREE.TubeGeometry(new HelixCurve(0.03, len * 0.62, 11), 120, 0.011, 6), gold, m => { m.position.set(-0.075, len * 0.19, 0); }));
    return g;
  };
  const L1 = 1.0, L2 = 0.9;
  const hip = new THREE.Group(); hip.position.y = 0.27; root.add(hip); hip.add(hinge());
  hip.add(arm(L1));
  const elbow = new THREE.Group(); elbow.position.y = L1; hip.add(elbow); elbow.add(hinge());
  elbow.add(arm(L2));
  const neck = new THREE.Group(); neck.position.y = L2; elbow.add(neck); neck.add(hinge());
  const headYaw = new THREE.Group(); neck.add(headYaw);
  const headRoll = new THREE.Group(); headYaw.add(headRoll);

  // bell shade, axis along local +x
  const shade = new THREE.Group(); shade.rotation.z = -Math.PI / 2; shade.position.x = 0.1; headRoll.add(shade);
  const profile = [[0.001, -0.06], [0.12, -0.04], [0.16, 0.06], [0.19, 0.2], [0.25, 0.37], [0.36, 0.54], [0.42, 0.62]].map(([r, y]) => new THREE.Vector2(r, y));
  shade.add(mesh(new THREE.LatheGeometry(profile, 56), cream));
  const innerShell = mesh(new THREE.LatheGeometry(profile.map(p => new THREE.Vector2(Math.max(0.001, p.x - 0.018), p.y + 0.01)), 56), inner);
  innerShell.castShadow = false; shade.add(innerShell);
  shade.add(mesh(new THREE.TorusGeometry(0.42, 0.016, 8, 72), gold, m => { m.rotation.x = Math.PI / 2; m.position.y = 0.62; }));
  shade.add(mesh(new THREE.SphereGeometry(0.06, 16, 12), gold, m => { m.position.y = -0.09; }));
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.13, 24, 16), bulbMat);
  bulb.position.y = 0.44; shade.add(bulb);

  const light = new THREE.SpotLight(0xffd59a, 0, 0, 0.62, 0.65, 0);
  light.position.set(0, 0.42, 0);
  light.castShadow = true;
  light.shadow.bias = -0.0005;
  light.shadow.normalBias = 0.02;
  light.shadow.camera.near = 0.1;
  light.shadow.camera.far = 40;
  shade.add(light);
  const lightTarget = new THREE.Object3D(); lightTarget.position.set(0, 4, 0); shade.add(lightTarget);
  light.target = lightTarget;

  root.scale.setScalar(LAMP_SCALE);
  return { root, hip, elbow, neck, headYaw, headRoll, bulb, light, inner, materials: [graphite, gold, cream, inner, bulbMat] };
}

function applyLampPose(lamp, p) {
  lamp.root.position.set(p.x, p.y, p.z);
  lamp.root.rotation.y = p.yaw;
  const a1 = -(0.35 + p.lean + p.crouch * 0.55); // lower arm, leaning forward
  const a2 = 1.25 + p.crouch * 0.85;             // elbow folds back
  lamp.hip.rotation.z = a1;
  lamp.elbow.rotation.z = a2;
  lamp.neck.rotation.z = p.pitch - (a1 + a2);    // head pitch is held in world space (stabilised like a bird's head)
  lamp.headYaw.rotation.y = p.headYaw;
  lamp.headRoll.rotation.x = p.roll;
}

// ---------- choreography ----------
// A "bounce track" is a list of floor contacts; the lamp flies ballistically between them.
// crouch > 0 compresses the joints, < 0 stretches them. Landing compression flows straight
// into the next take-off (anticipation), with follow-through on the head.
function bounceTrack(t, contacts) {
  const first = contacts[0];
  if (t <= first.t0) return { x: first.x, z: first.z, y: 0, crouch: 0, lean: 0, pitchOff: 0, yaw: first.yawIn, rest: false };
  for (let i = 0; i < contacts.length; i++) {
    const c = contacts[i], next = contacts[i + 1];
    const yawOut = next ? headingTo(next.x - c.x, next.z - c.z) : c.yawIn;
    if (t <= c.t1 || !next) {
      if (c.rest) { // final landing: damped settle
        const s = t - c.t0;
        const crouch = (-0.1 * Math.cos(9 * s) + 0.95 * Math.sin(9 * s)) * Math.exp(-5.5 * s);
        return { x: c.x, z: c.z, y: 0, crouch, lean: 0.12 * Math.exp(-6 * s), pitchOff: -0.3 * crouch, yaw: c.yawIn, rest: true, restTime: s };
      }
      const u = clamp01((t - c.t0) / (c.t1 - c.t0));
      const startC = i === 0 ? 0 : -0.1;
      const crouch = lerp(startC, -0.35, u * u) + 0.85 * Math.sin(Math.PI * u ** 0.75);
      const yawIn = i === 0 ? c.yawIn : headingTo(c.x - contacts[i - 1].x, c.z - contacts[i - 1].z);
      return { x: c.x, z: c.z, y: 0, crouch, lean: lerp(-0.05, 0.22, u * u), pitchOff: -0.32 * crouch, yaw: lerpAngle(yawIn, yawOut, smooth(u)), rest: false };
    }
    if (t < next.t0) {
      const s = (t - c.t1) / (next.t0 - c.t1);
      const dist = Math.hypot(next.x - c.x, next.z - c.z);
      const h = 0.32 + dist * 0.16;
      return {
        x: lerp(c.x, next.x, s), z: lerp(c.z, next.z, s), y: 4 * h * s * (1 - s),
        crouch: lerp(-0.35, -0.1, s) + 0.42 * Math.sin(Math.PI * s),
        lean: lerp(0.22, -0.05, smooth(s)),
        pitchOff: 0.16 * Math.sin(Math.PI * s) - 0.12 * s,
        yaw: yawOut, rest: false,
      };
    }
  }
  return null;
}

function buildChoreography(L) {
  const xs = L.letters.map(l => l.x);
  const xEnd = Math.max(...xs);
  const vIdx = pickTiltLetter(L);
  const V = L.letters[vIdx];
  const neighbour = L.letters[vIdx + 1];
  const gap = neighbour ? Math.max(0.05, neighbour.inkL - V.inkR) : 0.3;
  const tilt = -Math.min(0.36, Math.asin(Math.min(0.9, gap / L.capEm)) * 0.92); // leans right, resting on its neighbour

  // Contact point: the leaning letter's upper-right corner. The lamp stands front-right of it, one reach away.
  const contact = { x: V.x + 0.62 * L.capEm, z: 0.05 };
  const approach = THREE.MathUtils.degToRad(50);
  const P3 = { x: contact.x + TAP_REACH * Math.cos(approach), z: contact.z + TAP_REACH * Math.sin(approach) };
  const P0 = { x: xEnd + 4.8, z: 1.5 };
  const P1 = { x: lerp(P0.x, P3.x, 0.4), z: lerp(P0.z, P3.z, 0.35) };
  const P2 = { x: lerp(P0.x, P3.x, 0.76), z: lerp(P0.z, P3.z, 0.75) };
  const C = { x: 0, z: 1.45 };
  const Q = { x: lerp(P3.x, C.x, 0.52), z: 1.3 };
  const tapYaw = headingTo(contact.x - P3.x, contact.z - P3.z);

  const track1 = [
    { ...P0, t0: 2.72, t1: 3.0, yawIn: Math.PI },
    { ...P1, t0: 3.36, t1: 3.5 },
    { ...P2, t0: 3.86, t1: 3.99 },
    { ...P3, t0: 4.27, rest: true, yawIn: headingTo(P3.x - P2.x, P3.z - P2.z) },
  ];
  const track2 = [
    { ...P3, t0: 4.98, t1: 5.2, yawIn: tapYaw },
    { ...Q, t0: 5.55, t1: 5.68 },
    { ...C, t0: 6.02, rest: true, yawIn: headingTo(C.x - Q.x, C.z - Q.z) },
  ];
  return { vIdx, tilt, track1, track2, tapYaw, P3 };
}

function pickTiltLetter(L) {
  // The "V" of SERVICE leans on the "I"; fall back to the 4th-from-last letter.
  const idx = L.letters.findIndex(l => l.ch === 'V');
  return idx > 0 && idx < L.letters.length - 1 ? idx : Math.max(0, L.letters.length - 4);
}

function lampPoseAt(t, L, ch, camPos) {
  const p = { x: 0, y: 0, z: 0, yaw: Math.PI, crouch: 0, lean: 0, pitch: -0.42, headYaw: 0, roll: 0 };
  const b = t < 4.98 ? bounceTrack(t, ch.track1) : bounceTrack(t, ch.track2);
  Object.assign(p, { x: b.x, y: b.y, z: b.z, yaw: b.yaw, crouch: b.crouch, lean: b.lean });
  p.pitch += b.pitchOff;

  if (t >= 4.27 && t < 4.98) {
    // Notice the leaning letter, take a curious look, then tap it upright with the shade.
    const turn = smoother(seg(t, 4.3, 4.5));
    p.yaw = lerpAngle(b.yaw, ch.tapYaw, turn);
    const look = smooth(seg(t, 4.32, 4.46)) * (1 - smooth(seg(t, 4.66, 4.86)));
    p.roll += 0.38 * look;
    p.pitch += -0.15 * look;
    const wind = smooth(seg(t, 4.46, 4.56)) * (1 - seg(t, 4.56, 4.6));
    const strike = smooth(seg(t, 4.56, 4.62));
    const recoil = t > 4.62 ? Math.exp(-7 * (t - 4.62)) * Math.cos(11 * (t - 4.62)) : 1;
    p.lean += -0.16 * wind + 0.62 * strike * recoil;
    p.pitch += -0.55 * strike * recoil + 0.08 * wind;
    p.crouch += 0.5 * strike * recoil;
    // a small, pleased bounce
    const nod = seg(t, 4.78, 4.98);
    p.crouch += 0.28 * Math.sin(Math.PI * nod);
    p.pitch += 0.12 * Math.sin(Math.PI * nod);
  }
  if (t >= 4.98 && t < 5.2) p.yaw = b.yaw; // already blended inside the track

  if (t >= 6.02) {
    // Settle in front of the logo, look up at it, then slowly turn the light to the viewer.
    const s = t - 6.02;
    const faceLogo = Math.PI / 2;           // facing -z
    const faceViewer = -Math.PI / 2;        // facing +z (camera)
    const bodyYawAt = tt => {
      const a = smoother(seg(tt, 6.08, 6.32));
      const b2 = smoother(seg(tt, 6.48, 7.0));
      const y1 = lerpAngle(b.yaw, faceLogo, a);
      return y1 - Math.PI * b2;             // continue turning the same way: +90deg -> -90deg
    };
    const lead = 0.09;
    p.yaw = bodyYawAt(t - lead);
    p.headYaw = bodyYawAt(t) - p.yaw;       // the head leads the body (overlapping action)
    const lookUp = smooth(seg(t, 6.1, 6.32)) * (1 - smooth(seg(t, 6.5, 6.85)));
    p.pitch = lerp(-0.42 + b.pitchOff, 0.82, lookUp);
    p.roll = 0.16 * Math.sin(Math.PI * seg(t, 6.3, 6.5));
    // aim at the camera at the end
    const aim = smooth(seg(t, 6.6, 7.0));
    if (aim > 0 && camPos) {
      const headY = (0.27 + 1.6) * LAMP_SCALE;
      const pitchCam = Math.atan2(camPos.y - headY, Math.max(0.1, camPos.z - p.z));
      p.pitch = lerp(p.pitch, pitchCam, aim);
    }
    p.crouch += 0.18 * Math.sin(Math.PI * seg(t, 6.42, 6.62)) - 0.12 * aim; // tiny breath before the turn, rise to present
    void s;
  }
  return p;
}

// ---------- camera ----------
function fitDist(w, h, aspect) {
  return Math.max(h / 2 / TAN_HALF, w / 2 / (TAN_HALF * aspect));
}

function cameraKeys(L, ch, aspect) {
  const xs = L.letters.map(l => l.x);
  const titleW = Math.max(...xs) - Math.min(...xs) + L.capEm;
  const top = L.logo.cy + L.logo.h / 2;
  const D = L.viewH / 2 / TAN_HALF;
  const V = L.letters[ch.vIdx];
  const wide = fitDist(titleW * 1.22, top * 1.3, aspect);
  return [
    { t: 0, tx: L.logo.cx, ty: L.logo.cy, dist: fitDist(L.logo.w * 1.55, L.logo.h * 1.55, aspect) * 1.1, el: 0.04, az: 0.2 },
    { t: 1.05, tx: L.logo.cx, ty: L.logo.cy - 0.25, dist: fitDist(L.logo.w * 1.6, L.logo.h * 1.6, aspect), el: 0.08, az: 0.13 },
    { t: 2.85, tx: 0, ty: top * 0.44, dist: wide, el: 0.21, az: -0.12 },
    { t: 4.5, tx: V.x * 0.22, ty: top * 0.36, dist: wide, el: 0.25, az: -0.05 },
    { t: 6.15, tx: 0, ty: top * 0.34, dist: fitDist(titleW * (aspect < 1 ? 1.12 : 0.98), top * 1.05, aspect), el: 0.14, az: 0.03 },
    { t: 7.25, tx: 0, ty: L.camY, dist: D, el: 0, az: 0 },
  ];
}

function splineAt(keys, t, prop) {
  if (t <= keys[0].t) return keys[0][prop];
  const n = keys.length;
  if (t >= keys[n - 1].t) return keys[n - 1][prop];
  let i = 0;
  while (t > keys[i + 1].t) i++;
  const k0 = keys[i], k1 = keys[i + 1];
  const h = k1.t - k0.t;
  const tangent = j => (j <= 0 || j >= n - 1) ? 0 : (keys[j + 1][prop] - keys[j - 1][prop]) / (keys[j + 1].t - keys[j - 1].t);
  const m0 = tangent(i) * h, m1 = tangent(i + 1) * h;
  const s = (t - k0.t) / h, s2 = s * s, s3 = s2 * s;
  return (2 * s3 - 3 * s2 + 1) * k0[prop] + (s3 - 2 * s2 + s) * m0 + (-2 * s3 + 3 * s2) * k1[prop] + (s3 - s2) * m1;
}

// ---------- scene ----------
export async function createIntroScene({ canvas, overlay, glowEl, quality = 'high', onInteractive, onComplete, onTooSlow }) {
  const low = quality === 'low';
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance', alpha: false });
  let pixelRatio = Math.min(window.devicePixelRatio || 1, low ? 1.5 : 2);
  renderer.setPixelRatio(pixelRatio);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  const bgColor = new THREE.Color(0x000000);
  const bgTarget = new THREE.Color(0x08090a);
  scene.background = bgColor;
  scene.fog = new THREE.Fog(0x000000, 30, 80);
  const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 400);

  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const env = pmrem.fromScene(room, 0.04).texture;
  room.dispose?.();
  pmrem.dispose();

  // logo texture (the project's real RR logo asset)
  const logoImg = await new Promise((resolve, reject) => {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = '/rr-logo.webp';
  });
  const logoMap = new THREE.Texture(logoImg); logoMap.colorSpace = THREE.SRGBColorSpace; logoMap.anisotropy = 4; logoMap.needsUpdate = true;
  const logoAlpha = new THREE.Texture(logoImg); logoAlpha.colorSpace = THREE.NoColorSpace; logoAlpha.needsUpdate = true;

  const font = new FontLoader().parse(fontJson);

  // ---- lights ----
  const hemi = new THREE.HemisphereLight(0xe8ecf5, 0x000000, 0);
  scene.add(hemi);
  const key = new THREE.SpotLight(0xfff1dc, 0, 0, 0.42, 0.9, 0);
  key.castShadow = true;
  key.shadow.mapSize.set(low ? 1024 : 2048, low ? 1024 : 2048);
  key.shadow.bias = -0.0004;
  key.shadow.normalBias = 0.02;
  key.shadow.camera.near = 1;
  key.shadow.camera.far = 80;
  scene.add(key, key.target);
  const rim = new THREE.DirectionalLight(0xe6ebff, 0);
  rim.position.set(-6, 10, -12);
  scene.add(rim);

  // fake volumetric beam for the opening spotlight
  const beamMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { uOpacity: { value: 0 }, uColor: { value: new THREE.Color(1, 0.94, 0.84) } },
    vertexShader: `varying vec2 vUv; varying vec3 vN; varying vec3 vV;
      void main(){ vUv=uv; vec4 mv=modelViewMatrix*vec4(position,1.0); vN=normalize(normalMatrix*normal); vV=normalize(-mv.xyz); gl_Position=projectionMatrix*mv; }`,
    fragmentShader: `uniform float uOpacity; uniform vec3 uColor; varying vec2 vUv; varying vec3 vN; varying vec3 vV;
      void main(){ float edge=pow(abs(dot(vN,vV)),2.2); float along=smoothstep(0.0,0.35,vUv.y)*smoothstep(1.0,0.75,vUv.y);
      gl_FragColor=vec4(uColor, uOpacity*edge*along); }`,
  });
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 1, 1, 48, 1, true), beamMat);
  scene.add(beam);

  // ---- floor ----
  const floorMat = new THREE.MeshStandardMaterial({ color: 0x0c0c0e, roughness: 0.95, metalness: 0.0, transparent: true });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  // ---- logo: layered slab so it reads as a solid object under light ----
  const logoGroup = new THREE.Group();
  scene.add(logoGroup);
  const plane = new THREE.PlaneGeometry(1, 1);
  const logoLayers = [];
  const LAYERS = 7;
  for (let i = 0; i < LAYERS; i++) {
    const shade = i === 0 ? 1 : 0.42 - i * 0.035;
    const mat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(shade, shade, shade), map: logoMap, alphaMap: logoAlpha, transparent: true, alphaTest: 0.04,
      roughness: 0.38, metalness: 0.15, envMap: env, envMapIntensity: 0.35,
    });
    const m = new THREE.Mesh(plane, mat);
    m.position.z = -i * 0.016;
    m.renderOrder = LAYERS - i;
    if (i === 0) {
      m.castShadow = true;
      m.customDepthMaterial = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, alphaMap: logoAlpha, alphaTest: 0.5 });
    }
    logoGroup.add(m);
    logoLayers.push(m);
  }
  const flatLogoMat = new THREE.MeshBasicMaterial({ map: logoMap, transparent: true, opacity: 0, toneMapped: false, depthWrite: false });
  const flatLogo = new THREE.Mesh(plane, flatLogoMat);
  flatLogo.position.z = 0.004;
  flatLogo.renderOrder = 20;
  logoGroup.add(flatLogo);

  // ---- 3D letters ----
  const goldMat = new THREE.MeshStandardMaterial({ color: 0xe0b24f, metalness: 1, roughness: 0.27, envMap: env, envMapIntensity: 1.25, transparent: true });
  const flatTextMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, toneMapped: false, depthWrite: false });
  const capRef = new TextGeometry('H', { font, size: 1, depth: 0.01, curveSegments: 4, bevelEnabled: false });
  capRef.computeBoundingBox();
  const capH3 = capRef.boundingBox.max.y;
  capRef.dispose();
  const glyphCache = new Map();
  const glyph = ch => {
    if (!glyphCache.has(ch)) {
      const solid = new TextGeometry(ch, { font, size: 1, depth: 0.26, curveSegments: low ? 5 : 8, bevelEnabled: true, bevelThickness: 0.025, bevelSize: 0.014, bevelSegments: low ? 2 : 3 });
      solid.computeBoundingBox();
      const bb = solid.boundingBox;
      const cx = (bb.min.x + bb.max.x) / 2;
      solid.translate(-cx, 0, -bb.max.z);
      const flat = new THREE.ShapeGeometry(font.generateShapes(ch, 1), low ? 5 : 8);
      flat.translate(-cx, 0, 0.004);
      glyphCache.set(ch, { solid, flat });
    }
    return glyphCache.get(ch);
  };

  let L, ch, camKeys, letters = [];
  const lettersGroup = new THREE.Group();
  scene.add(lettersGroup);

  const lamp = buildLamp(env);
  lamp.light.shadow.mapSize.set(low ? 512 : 1024, low ? 512 : 1024);
  scene.add(lamp.root);

  const glowSprite = new THREE.Sprite(new THREE.SpriteMaterial({
    map: radialTexture([[0, 'rgba(255,240,215,1)'], [0.18, 'rgba(255,214,150,0.55)'], [0.5, 'rgba(255,190,110,0.12)'], [1, 'rgba(255,180,100,0)']]),
    blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, toneMapped: false, opacity: 0,
  }));
  glowSprite.renderOrder = 30;
  scene.add(glowSprite);

  function layout() {
    L = measureLanding();
    ch = buildChoreography(L);
    const aspect = L.vw / L.vh;
    camera.aspect = aspect;
    camera.updateProjectionMatrix();
    renderer.setSize(L.vw, L.vh, false);
    camKeys = cameraKeys(L, ch, aspect);
    // letters
    for (const l of letters) lettersGroup.remove(l.group);
    letters = [];
    const s = L.capEm / capH3;
    flatTextMat.color.setStyle(L.titleColor);
    L.letters.forEach((info, i) => {
      const g = glyph(info.ch);
      const group = new THREE.Group();
      const solid = new THREE.Mesh(g.solid, goldMat);
      solid.castShadow = true; solid.receiveShadow = true;
      const flat = new THREE.Mesh(g.flat, flatTextMat);
      flat.renderOrder = 21;
      group.add(solid, flat);
      group.scale.setScalar(s);
      lettersGroup.add(group);
      letters.push({ group, info, i, wob: (i % 2 ? 1 : -1) * (0.05 + ((i * 37) % 7) * 0.006) });
    });
    // logo slab
    logoGroup.scale.set(L.logo.w, L.logo.h, 1);
    for (const m of logoLayers) m.scale.z = 1;
    // lights relative to content
    const top = L.logo.cy + L.logo.h / 2;
    key.position.set(0, top + 8, 10);
    key.target.position.set(0, top * 0.45, 0);
    const xs = L.letters.map(l => l.x);
    const span = Math.max(L.logo.w, Math.max(...xs) - Math.min(...xs) + L.capEm);
    key.angle = Math.min(0.75, Math.atan2(span * 0.62, Math.hypot(top + 8, 10)) + 0.1);
    // beam from light towards the logo
    const from = key.position.clone(), to = new THREE.Vector3(L.logo.cx, L.logo.cy - L.logo.h * 0.2, -0.8);
    const len = from.distanceTo(to);
    beam.scale.set(L.logo.w * 0.62, len, L.logo.w * 0.62);
    beam.position.copy(from).add(to).multiplyScalar(0.5);
    beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, -1, 0), to.clone().sub(from).normalize());
  }
  layout();

  const tmpV = new THREE.Vector3(), tmpDir = new THREE.Vector3(), camPosFinal = new THREE.Vector3();
  let interactiveFired = false, completeFired = false, skipAt = null;

  function renderAt(t, realTime, draw = true) {
    // camera
    const az = splineAt(camKeys, t, 'az'), el = splineAt(camKeys, t, 'el'), dist = splineAt(camKeys, t, 'dist');
    const finalBlend = smooth(seg(t, 6.3, 7.25));
    const drift = (1 - finalBlend) * 0.035;
    const tx = splineAt(camKeys, t, 'tx') + Math.sin(t * 0.9) * drift;
    const ty = splineAt(camKeys, t, 'ty') + Math.sin(t * 1.3 + 1) * drift * 0.6;
    camera.position.set(tx + dist * Math.sin(az) * Math.cos(el), ty + dist * Math.sin(el), dist * Math.cos(az) * Math.cos(el));
    camera.lookAt(tx, ty, 0);
    scene.fog.near = dist + 2;
    scene.fog.far = dist + 30;
    camPosFinal.copy(camera.position);

    // background, lights
    bgColor.setRGB(0, 0, 0).lerp(bgTarget, smooth(seg(t, 0.4, 2.5)));
    scene.fog.color.copy(bgColor);
    floorMat.opacity = 1 - smooth(seg(t, 6.45, 7.15));
    const keyOn = smooth(seg(t, 0.12, 1.25));
    key.intensity = 3.4 * keyOn * (1 - 0.35 * smooth(seg(t, 6.6, 7.2)));
    hemi.intensity = 0.22 * smooth(seg(t, 0.6, 2.2));
    rim.intensity = 0.7 * smooth(seg(t, 0.9, 2.6));
    beamMat.uniforms.uOpacity.value = 0.11 * keyOn * (1 - 0.55 * smooth(seg(t, 2.2, 3.4))) * (1 - smooth(seg(t, 6.4, 7.1)));

    // logo: emerges in the spotlight, then slides to its exact landing-page plane
    const logoZ = lerp(-0.8, 0, smoother(seg(t, 6.25, 7.2)));
    logoGroup.position.set(L.logo.cx, L.logo.cy + 0.25 * (1 - easeOutCubic(seg(t, 0.1, 1.4))), logoZ);
    const handoff = smooth(seg(t, 7.0, 7.3)); // solid 3D -> flat, pixel-matched copies
    const logoIn = easeOutCubic(seg(t, 0.15, 1.2)) * (1 - handoff);
    for (let i = 0; i < logoLayers.length; i++) logoLayers[i].material.opacity = logoIn;
    flatLogoMat.opacity = smooth(seg(t, 6.75, 7.25));

    // letters
    const dropDur = 0.55;
    for (const l of letters) {
      const start = INTRO_TIMING.lettersStart + l.i * 0.07;
      const land = start + dropDur;
      const g = l.group;
      g.visible = t >= start;
      let y = l.info.y, rz = 0;
      if (t < land) {
        const s = seg(t, start, land);
        y += 12 * (1 - s * s);
        rz = l.wob * 2.5 * (1 - s);
      } else {
        const b = seg(t, land, land + 0.2);
        y += 0.09 * Math.sin(Math.PI * b) * (1 - b * 0.4);
        const tau = t - land;
        rz = l.wob * Math.exp(-6 * tau) * Math.sin(16 * tau);
      }
      if (l.i === ch.vIdx && t >= land) {
        const tip = seg(t, land + 0.28, land + 0.7);
        let r = ch.tilt * tip * tip * tip;
        const rest = land + 0.7;
        if (t > rest) r += 0.03 * Math.exp(-12 * (t - rest)) * Math.sin(30 * (t - rest));
        if (t >= INTRO_TIMING.tapContact) {
          const tau = t - INTRO_TIMING.tapContact;
          r = ch.tilt * Math.exp(-7 * tau) * Math.cos(12 * tau);
        }
        rz += r;
      }
      g.position.set(l.info.x, y, 0);
      g.rotation.z = rz;
    }
    flatTextMat.opacity = smooth(seg(t, 6.8, 7.25));
    goldMat.opacity = 1 - handoff;
    goldMat.depthWrite = handoff < 0.5;

    // lamp
    const lampVisible = t >= 2.7 && t < 7.08;
    lamp.root.visible = lampVisible;
    applyLampPose(lamp, lampPoseAt(Math.min(t, 7.07), L, ch, camPosFinal)); // posed even when hidden: the glow tracks the bulb
    if (lampVisible) {
      lamp.light.intensity = 5.5 * smooth(seg(t, 2.8, 3.3));
      lamp.inner.emissiveIntensity = 0.25 + 1.6 * smooth(seg(t, 2.8, 3.3));
    } else {
      lamp.light.intensity = 0;
    }
    // Keep the shadow-casting light count constant: toggling it would recompile every material mid-intro.
    lamp.light.castShadow = !lowShadows;

    // glow: the light turning towards the viewer
    scene.updateMatrixWorld();
    lamp.bulb.getWorldPosition(tmpV);
    tmpDir.set(0, 1, 0).transformDirection(lamp.bulb.parent.matrixWorld); // shade axis
    const toCam = camera.position.clone().sub(tmpV).normalize();
    const facing = Math.max(0, tmpDir.dot(toCam));
    const turnGlow = lampVisible ? facing ** 6 * smooth(seg(t, 6.55, 7.0)) : 0;
    glowSprite.position.copy(tmpV);
    const gs = lerp(0.6, 9, smooth(seg(t, 6.6, 7.1)));
    glowSprite.scale.setScalar(gs);
    glowSprite.material.opacity = turnGlow;

    // DOM glow + overlay fade
    if (glowEl) {
      tmpV.project(camera);
      const gx = (tmpV.x * 0.5 + 0.5) * L.vw, gy = (-tmpV.y * 0.5 + 0.5) * L.vh;
      const rise = smooth(seg(t, 6.62, INTRO_TIMING.glowPeak));
      const decay = smooth(seg(t, INTRO_TIMING.glowPeak, INTRO_TIMING.end));
      // never fully 0: keeps the blend layer alive so its first appearance costs nothing
      glowEl.style.opacity = String(Math.max(0.002, rise * (1 - decay) * 0.92));
      glowEl.style.transform = `translate3d(${gx}px, ${gy}px, 0) translate(-50%, -50%) scale(${lerp(0.15, 1, easeOutCubic(rise)) * lerp(1, 1.25, decay)})`;
    }
    let overlayOpacity = 1 - smooth(seg(t, INTRO_TIMING.interactive - 0.05, INTRO_TIMING.end));
    if (skipAt != null) overlayOpacity = Math.min(overlayOpacity, 1 - easeInOutCubic(clamp01((realTime - skipAt) / SKIP_FADE)));
    overlay.style.opacity = String(overlayOpacity);

    if (draw) renderer.render(scene, camera);
    return overlayOpacity;
  }

  // ---- loop ----
  let raf = 0, time = 0, last = 0, realTime = 0, running = false, paused = false, lowShadows = low, slowStreak = 0;
  const stats = { frames: 0, total: 0, worst: 0, pixelRatio, quality, downgraded: false };
  function frame(now) {
    raf = requestAnimationFrame(frame);
    // Real time drives the timeline (slow devices drop frames, they don't slow down).
    // Only a long stall (tab hidden, debugger) is absorbed, so the intro resumes where it was.
    const elapsed = last ? (now - last) / 1000 : 1 / 60;
    const dt = elapsed > 0.25 ? 1 / 60 : elapsed;
    // A device that keeps rendering below ~8 fps gets the lightweight 2D intro instead.
    slowStreak = elapsed > 0.12 && document.visibilityState === 'visible' ? slowStreak + 1 : 0;
    if (slowStreak >= 4 && skipAt == null && time < INTRO_TIMING.interactive && onTooSlow) { stop(); onTooSlow(stats); return; }
    last = now;
    if (!paused) time += dt;
    realTime += dt;
    if (stats.frames > 5) { stats.total += dt; if (elapsed > stats.worst) { stats.worst = elapsed; stats.worstAt = +time.toFixed(2); } if (elapsed > 0.05) (stats.spikes ||= []).push([+time.toFixed(2), Math.round(elapsed * 1000)]); }
    stats.frames++;
    // adaptive quality: if the device cannot keep up, drop resolution and the lamp shadow
    if (!stats.downgraded && stats.frames === 30 && stats.total / 24 > 1 / 40) {
      stats.downgraded = true;
      lowShadows = true;
      pixelRatio = 1;
      renderer.setPixelRatio(1);
      renderer.setSize(L.vw, L.vh, false);
      stats.pixelRatio = 1;
    }
    const opacity = renderAt(time, realTime);
    if (!interactiveFired && (time >= INTRO_TIMING.interactive || skipAt != null)) { interactiveFired = true; onInteractive?.(); }
    if (!completeFired && (time >= INTRO_TIMING.end || opacity <= 0.001)) { completeFired = true; stop(); onComplete?.(); }
  }
  function stop() { cancelAnimationFrame(raf); running = false; }

  const onResize = () => { layout(); if (!running) renderAt(time, realTime); };
  window.addEventListener('resize', onResize);

  // Warm-up before the clock starts. Pose a mid-intro frame (letters, lamp, glow all visible) and
  // compile every program in parallel off the main thread, then draw that frame once so the shadow
  // passes compile too, and finally draw frame 0. Only frame 0 is ever presented.
  renderAt(5.4, 0, false);
  if (renderer.compileAsync) await renderer.compileAsync(scene, camera); else renderer.compile(scene, camera);
  for (const t of [1.55, 3.5, 5.4, 6.75, 6.95, 7.2]) renderAt(t, 0);
  renderAt(0, 0);

  const api = {
    stats,
    play() { if (running) return; running = true; last = 0; raf = requestAnimationFrame(frame); },
    skip() { if (skipAt == null) skipAt = realTime; },
    seek(t) { paused = true; time = t; renderAt(t, realTime); },
    resume() { paused = false; },
    dispose() {
      stop();
      window.removeEventListener('resize', onResize);
      scene.traverse(o => {
        if (o.geometry) o.geometry.dispose();
        const mats = o.material ? (Array.isArray(o.material) ? o.material : [o.material]) : [];
        for (const m of mats) { for (const v of Object.values(m)) if (v && v.isTexture) v.dispose(); m.dispose(); }
        if (o.customDepthMaterial) o.customDepthMaterial.dispose();
        if (o.isLight && o.shadow?.map) o.shadow.map.dispose();
      });
      for (const { solid, flat } of glyphCache.values()) { solid.dispose(); flat.dispose(); }
      env.dispose(); logoMap.dispose(); logoAlpha.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
    },
  };
  return api;
}
