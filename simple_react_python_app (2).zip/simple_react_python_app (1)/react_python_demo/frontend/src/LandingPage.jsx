import React, { useEffect, useRef, useState } from 'react';
import './LandingPage.css';

export default function LandingPage({ onReplayIntro, onReplayIntent }) {
  const detailsRef = useRef(null);
  const [detailsVisible, setDetailsVisible] = useState(false);

  useEffect(() => {
    const section = detailsRef.current;
    if (!section) return undefined;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion || !('IntersectionObserver' in window)) {
      setDetailsVisible(true);
      return undefined;
    }
    let observer;
    const revealWhenVisible = () => {
      if (section.getBoundingClientRect().top <= window.innerHeight * 0.92) {
        setDetailsVisible(true);
        observer?.disconnect();
        window.removeEventListener('scroll', revealWhenVisible);
      }
    };
    observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setDetailsVisible(true);
        observer.disconnect();
        window.removeEventListener('scroll', revealWhenVisible);
      }
    }, { threshold: 0.2 });
    window.addEventListener('scroll', revealWhenVisible, { passive: true });
    observer.observe(section);
    revealWhenVisible();
    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', revealWhenVisible);
    };
  }, []);

  return (
    <main className="rr-landing">
      <div className="rr-landing-glow" aria-hidden="true" />
      <header className="rr-landing-header">
        <a className="rr-wordmark" href="#/home" aria-label="RR Task Service home">RR <span>TASK SERVICE</span></a>
        <nav className="rr-landing-nav" aria-label="Main navigation">
          <a className="rr-nav-home" href="#/home" aria-current="page">Home</a>
          <a href="#/tasks">MY TASKS</a>
          <a href="#/login">Login</a>
        </nav>
      </header>

      <section className="rr-hero" aria-labelledby="rr-title">
        <p className="rr-eyebrow rr-reveal rr-delay-1">A CLEARER WAY TO WORK</p>
        <div className="rr-logo-frame" aria-label="Official RR Task Service logo">
          <img
            className="rr-logo-image"
            src="/rr-logo.webp"
            alt="RR Task Service original white RR wing mark"
            width="450"
            height="338"
          />
          <span className="rr-logo-sweep" aria-hidden="true" />
        </div>
        <h1 id="rr-title" className="rr-title rr-reveal rr-delay-2">RR TASK SERVICE</h1>
        <p className="rr-tagline rr-reveal rr-delay-3">TASK <i>•</i> TRACK <i>•</i> ANALYZE <i>•</i> ACHIEVE</p>
        <p className="rr-intro-copy rr-reveal rr-delay-4">A focused workspace to bring everyday tasks and team progress into view.</p>
        <div className="rr-actions rr-reveal rr-delay-5">
          <a className="rr-button rr-button-primary" href="#/tasks">Get Started <span aria-hidden="true">↗</span></a>
          <a className="rr-button rr-button-secondary" href="#/login">Login</a>
        </div>
        <a className="rr-scroll-cue" href="#rr-workflow" aria-label="Scroll to learn more"><span />SCROLL TO EXPLORE</a>
        {onReplayIntro && (
          <button type="button" className="rr-replay-intro" onClick={onReplayIntro} onPointerEnter={onReplayIntent} onFocus={onReplayIntent} aria-label="Replay intro animation">
            <span className="rr-replay-icon" aria-hidden="true">↻</span><span className="rr-replay-label" aria-hidden="true">REPLAY INTRO</span>
          </button>
        )}
      </section>

      <section id="rr-workflow" className={`rr-workflow${detailsVisible ? ' is-visible' : ''}`} ref={detailsRef} aria-label="About the workspace">
        <div className="rr-workflow-rule" />
        <p className="rr-workflow-kicker">ONE THOUGHTFUL WORKSPACE</p>
        <p className="rr-workflow-copy">Keep the day clear.<br /><span>Keep progress moving.</span></p>
        <div className="rr-workflow-links" aria-label="Workspace features">
          <span>MY TASKS</span><i>—</i><span>TEAM VIEW</span><i>—</i><span>ANALYTICS</span>
        </div>
      </section>

      <footer className="rr-landing-footer"><span>RR TASK SERVICE</span><span>BUILT FOR FOCUSED WORK</span></footer>
    </main>
  );
}
