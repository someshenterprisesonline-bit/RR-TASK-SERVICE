﻿import React, { useEffect, useState } from 'react';

export default function PaginationControls({ page, pageSize, total, loading, onPageChange, onPageSizeChange, label = 'records' }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const [jump, setJump] = useState(String(page + 1));
  useEffect(() => setJump(String(page + 1)), [page]);
  const go = () => {
    const value = Number.parseInt(jump, 10);
    if (Number.isFinite(value)) onPageChange(Math.min(pages - 1, Math.max(0, value - 1)));
    else setJump(String(page + 1));
  };
  const start = total ? page * pageSize + 1 : 0;
  const end = Math.min((page + 1) * pageSize, total);
  return <div className="task-pagination" aria-label={`${label} pages`}>
    <span>Showing {start.toLocaleString()}–{end.toLocaleString()} of {total.toLocaleString()} {label}</span>
    <div className="pagination-controls">
      <label>Rows <select value={pageSize} onChange={e => onPageSizeChange(Number(e.target.value))} aria-label={`${label} per page`}>
        {[25, 50, 100, 200].map(size => <option key={size} value={size}>{size}</option>)}
      </select></label>
      {loading && <span className="pagination-loading" role="status"><span className="loading-spinner"/>Loading</span>}
      <button type="button" aria-label="First Page" title="First Page" onClick={() => onPageChange(0)} disabled={loading || page === 0}>|&lt;</button>
      <button type="button" aria-label="Previous Page" onClick={() => onPageChange(Math.max(0, page - 1))} disabled={loading || page === 0}>Previous</button>
      <label>Page <input className="page-jump" aria-label="Page number" type="number" min="1" max={pages} value={jump} onChange={e => setJump(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') go(); }} onBlur={go}/><span> of {pages}</span></label>
      <button type="button" aria-label="Next Page" onClick={() => onPageChange(Math.min(pages - 1, page + 1))} disabled={loading || page >= pages - 1}>Next</button>
      <button type="button" aria-label="Last Page" title="Last Page" onClick={() => onPageChange(pages - 1)} disabled={loading || page >= pages - 1}>&gt;|</button>
    </div>
  </div>;
}
