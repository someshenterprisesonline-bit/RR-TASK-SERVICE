import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';
import Login from './Login.jsx';
import HeaderTools from './HeaderTools.jsx';
import AdminDashboard from './AdminDashboard.jsx';
import UserProfiles from './UserProfiles.jsx';
import AnalyticsDashboard from './AnalyticsDashboard.jsx';
import PaginationControls from './PaginationControls.jsx';
import ExpandableTableContainer from './ExpandableTableContainer.jsx';
import { API_BASE, apiFetch, getToken, clearToken, logout, onUnauthorized } from './authApi.js';
import LandingPage from './LandingPage.jsx';
import { useCinematicIntro } from './intro/CinematicIntro.jsx';
const API = `${API_BASE}/tasks`;
const fetch = apiFetch;   // every task request carries the login token
const numberOr = (value, fallback = 0) => value != null && Number.isFinite(Number(value)) ? Number(value) : fallback;

function normalizeRejectedRows(rows) {
  return (Array.isArray(rows) ? rows : []).filter(row => row && typeof row === 'object').map(row => ({
    ...row,
    row_number: Number.isFinite(Number(row.row_number)) ? Number(row.row_number) : 0,
    reference: row.reference ?? '',
    messages: Array.isArray(row.messages) && row.messages.length ? row.messages.map(String) : ['Rejected row.'],
  }));
}

function splitRejectedRows(rows) {
  const duplicates = [], invalid = [];
  for (const row of normalizeRejectedRows(rows)) {
    const isDuplicate = row.messages.some(message => /duplicate/i.test(message));
    (isDuplicate ? duplicates : invalid).push(row);
  }
  return {duplicates, invalid};
}

function normalizeImportPreview(value) {
  const data = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const {duplicates: legacyDuplicates, invalid: legacyInvalid} = splitRejectedRows(data.errors);
  const errors = normalizeRejectedRows(data.errors);
  const duplicates = Array.isArray(data.duplicates) ? normalizeRejectedRows(data.duplicates) : legacyDuplicates;
  const invalidRows = Array.isArray(data.duplicates) ? errors : legacyInvalid;
  const duplicateFileRows = data.duplicate && !Array.isArray(data.duplicates) ? numberOr(data.valid_count) : 0;
  const duplicateCount = numberOr(data.duplicate_count, duplicates.length + duplicateFileRows);
  const acceptedCount = numberOr(data.accepted_count, data.duplicate ? 0 : numberOr(data.valid_count));
  const invalidCount = Array.isArray(data.duplicates) ? numberOr(data.invalid_count, invalidRows.length) : invalidRows.length;
  return {...data, valid_count: acceptedCount, accepted_count: acceptedCount,
    duplicate_count: duplicateCount, invalid_count: invalidCount,
    total_rows: numberOr(data.total_rows, acceptedCount + duplicateCount + invalidCount),
    duplicates, errors: invalidRows, duplicate: Boolean(data.duplicate)};
}

function normalizeImportResult(value, preview, currentTotal) {
  const data = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const {duplicates: legacyDuplicates, invalid: legacyInvalid} = splitRejectedRows(data.errors);
  const errors = normalizeRejectedRows(data.errors);
  const duplicates = Array.isArray(data.duplicates) ? normalizeRejectedRows(data.duplicates) : legacyDuplicates;
  const invalidRows = Array.isArray(data.duplicates) ? errors : legacyInvalid;
  const invalidCount = Array.isArray(data.duplicates) ? numberOr(data.invalid_count, invalidRows.length) : invalidRows.length;
  const acceptedCount = numberOr(data.accepted_count, numberOr(data.imported_count));
  return {...data,
    total: numberOr(data.total, currentTotal + acceptedCount),
    total_rows: numberOr(data.total_rows, preview.total_rows),
    accepted_count: acceptedCount,
    duplicate_count: numberOr(data.duplicate_count, Math.max(duplicates.length, numberOr(data.failed_count) - invalidCount)),
    invalid_count: invalidCount,
    duplicates, errors: invalidRows,
    unique_employee_count: data.unique_employee_count ?? 0,
    newly_created_profiles: data.newly_created_profiles ?? 0,
    existing_profiles_updated: data.existing_profiles_updated ?? 0,
  };
}

class AppErrorBoundary extends React.Component {
  state = { hasError: false };
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error, info) { console.error('Application render failed:', error, info.componentStack); }
  render() {
    if (!this.state.hasError) return this.props.children;
    return <main className="app-recovery" role="alert">
      <h1>The app could not open this page</h1>
      <p>Your saved tasks were not changed. Reload the app to try again.</p>
      <button type="button" onClick={() => window.location.reload()}>Reload application</button>
    </main>;
  }
}

function App({ user, onLogout, onOpenAdmin }) {
  const [tasks, setTasks] = useState([]);
  const [totalTasks, setTotalTasks] = useState(0);
  const [allTaskCount, setAllTaskCount] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(100);
  const [search, setSearch] = useState('');
  const [taskStatus, setTaskStatus] = useState('all');
  const [taskSort, setTaskSort] = useState('newest');
  const [deleteAllOpen, setDeleteAllOpen] = useState(false);
  const [deleteAllText, setDeleteAllText] = useState('');
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [notice, setNotice] = useState('');
  const deleteAllLock = useRef(false);
  const [title, setTitle] = useState('');
  const [name, setName] = useState('');
  // Time is picked with Hour / Minute / AM-PM dropdowns so it is always 12-hour,
  // regardless of the computer's 24-hour clock setting.
  const [hour, setHour] = useState('');
  const [minute, setMinute] = useState('');
  const [ampm, setAmpm] = useState('AM');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(true); // tasks table expanded/collapsed
  const importFileRef = useRef(null);
  const pageRequestRef = useRef(0);
  const pageAbortRef = useRef(null);
  const [importPreview, setImportPreview] = useState(null);
  const [importResult, setImportResult] = useState(null);
  const [importBusy, setImportBusy] = useState(false);
  const [importPhase, setImportPhase] = useState('');
  const [shownImportErrors, setShownImportErrors] = useState(50);
  async function refreshPage(targetPage = page) {
    const requestNumber = ++pageRequestRef.current;
    pageAbortRef.current?.abort();
    const controller = new AbortController(); pageAbortRef.current = controller;
    try {
      const res = await fetch(`${API}?offset=${targetPage * pageSize}&limit=${pageSize}&q=${encodeURIComponent(search)}&status=${taskStatus}&sort=${taskSort}`, {signal: controller.signal});
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.detail || `Could not load tasks (HTTP ${res.status}).`);
      }
      const result = await res.json();
      if (requestNumber !== pageRequestRef.current) return;
      setTotalTasks(result.total); setAllTaskCount(result.all_total ?? result.total);
      const lastPage = Math.max(0, Math.ceil(result.total / pageSize) - 1);
      if (targetPage > lastPage) { setPage(lastPage); return; }
      setTasks(result.items);
      setError('');
    } catch (err) { if (requestNumber === pageRequestRef.current) setError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : (err.message || 'Could not load tasks. Please retry.')); }
    finally { if (requestNumber === pageRequestRef.current) setLoading(false); }
  }
  useEffect(() => { setLoading(true); refreshPage(page); }, [page, pageSize, search, taskStatus, taskSort]);
  async function add(e) {
    e.preventDefault(); if (!title.trim()) return;
    if (!hour !== !minute) { setError('Please select both hour and minutes for the time, or leave both empty.'); return; }
    const time = hour ? `${hour}:${minute} ${ampm}` : '';   // e.g. "2:05 PM"
    // Backend requires title and status; name and time are optional
    try {
      const res = await fetch(API, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({title: title.trim(), name: name.trim(), time, status: 'pending'}) });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.detail || 'Failed to add task.');
      }
      setTitle(''); setName(''); setHour(''); setMinute(''); setAmpm('AM'); setError(''); setNotice('Task added successfully.'); setOpen(true);
      const targetPage = Math.floor(totalTasks / pageSize);
      setPage(targetPage);
      if (targetPage === page) refreshPage(targetPage);
    } catch (err) { setError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message); }
  }
  // Backend PATCH requires {title, status} and stores completion in `status`
  const isDone = t => t.done || t.status === 'completed';
  async function toggle(id) {
    const t = tasks.find(x => x.id === id); if (!t) return;
    const res = await fetch(`${API}/${id}`, { method: 'PATCH', headers: {'Content-Type':'application/json'}, body: JSON.stringify({title: t.title, status: isDone(t) ? 'pending' : 'completed'}) });
    if (res.ok) refreshPage(); else setError('Failed to update task.');
  }
  async function remove(id) {
    const res = await fetch(`${API}/${id}`, {method:'DELETE'});
    if (res.ok) refreshPage(); else setError('Failed to delete task.');
  }
  async function validateImport(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setError(''); setImportPreview(null); setImportResult(null); setShownImportErrors(50);
    if (!file.name.toLowerCase().endsWith('.xlsx')) { setError('Choose an Excel .xlsx file.'); return; }
    setImportBusy(true); setImportPhase('validating');
    try {
      const res = await fetch(`${API}/import/validate`, {
        method: 'POST',
        headers: {'Content-Type': file.type || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'},
        body: file,
        timeoutMs: 120000,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.detail || 'Could not validate this Excel file.');
      setImportPreview({...normalizeImportPreview(data), filename: file.name});
      setOpen(true);
    } catch (err) { setError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message); }
    finally { setImportBusy(false); setImportPhase(''); }
  }
  async function confirmImport() {
    if (!importPreview || !importPreview.valid_count) return;
    setImportBusy(true); setImportPhase('importing'); setError('');
    try {
      const res = await fetch(`${API}/import/commit`, {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({import_id: importPreview.import_id}),
        timeoutMs: 120000,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.detail || 'Import failed.');
      const result = normalizeImportResult(data, importPreview, totalTasks);
      setImportResult(result);
      setTotalTasks(result.total);
      setOpen(true);
      const lastPage = Math.max(0, Math.ceil(result.total / pageSize) - 1);
      setPage(lastPage);
      if (lastPage === page) refreshPage(lastPage);
    } catch (err) { setError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message); }
    finally { setImportBusy(false); setImportPhase(''); }
  }
  function downloadImportRejections() {
    const source = importResult || importPreview;
    if (!source) return;
    const rows = [
      ...source.duplicates.map(row => ({...row, category: 'Duplicate'})),
      ...source.errors.map(row => ({...row, category: 'Invalid'})),
    ].sort((a, b) => a.row_number - b.row_number);
    const quote = value => `"${String(value ?? '').replaceAll('"', '""')}"`;
    const csv = [['Row number', 'S.No / reference', 'Rejection type', 'Reason'],
      ...rows.map(row => [row.row_number, row.reference, row.category, row.messages.join(' ')])]
      .map(row => row.map(quote).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob(['\ufeff', csv], {type: 'text/csv;charset=utf-8'}));
    const link = document.createElement('a');
    link.href = url; link.download = 'Rejected_Task_Import_Rows.csv';
    document.body.appendChild(link); link.click(); link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function deleteAllTasks() {
    if (deleteAllLock.current || bulkDeleting || deleteAllText !== 'DELETE ALL') return;
    deleteAllLock.current = true; setBulkDeleting(true); setError(''); setNotice('');
    try {
      const res = await fetch(`${API_BASE}/admin/tasks`, {method:'DELETE', headers:{'Content-Type':'application/json'}, body:JSON.stringify({confirmation:'DELETE ALL', expected_count:allTaskCount})});
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.detail || (res.status === 403 ? 'Only administrators can delete all task records.' : 'Could not delete task records.'));
      pageRequestRef.current += 1; pageAbortRef.current?.abort(); setLoading(false);
      setTasks([]); setTotalTasks(0); setAllTaskCount(0); setPage(0); setNotice(`${data.deleted_count.toLocaleString()} task records deleted.`);
      setDeleteAllOpen(false); setDeleteAllText('');
    } catch (err) { setError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message); }
    finally { deleteAllLock.current = false; setBulkDeleting(false); }
  }
  return <main><div className="heading"><h1>MY TASKS</h1>
      <HeaderTools user={user} onLogout={onLogout}>
        <button type="button" className="admin-btn" onClick={() => window.location.hash = '#/my-analytics'}>Analytics Dashboard</button>
        {user?.role === 'admin' && <button type="button" className="admin-btn" onClick={onOpenAdmin}>Admin Dashboard</button>}
      </HeaderTools>
    </div>
    <form onSubmit={add} className="task-form">
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name" aria-label="Name"/>
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Tasks" aria-label="Tasks"/>
      <div className="task-time" role="group" aria-label="Time">
        <select value={hour} onChange={e=>setHour(e.target.value)} aria-label="Hour">
          <option value="">Hr</option>
          {Array.from({length: 12}, (_, i) => String(i + 1)).map(h => <option key={h} value={h}>{h}</option>)}
        </select>
        <span aria-hidden="true">:</span>
        <select value={minute} onChange={e=>setMinute(e.target.value)} aria-label="Minutes">
          <option value="">Min</option>
          {Array.from({length: 60}, (_, i) => String(i).padStart(2, '0')).map(m => <option key={m} value={m}>{m}</option>)}
        </select>
        <select value={ampm} onChange={e=>setAmpm(e.target.value)} aria-label="AM or PM">
          <option value="AM">AM</option>
          <option value="PM">PM</option>
        </select>
      </div>
      <button>ADD</button>
      <button type="button" className="import-excel-button" onClick={() => importFileRef.current?.click()} disabled={importBusy}>Import Excel</button>
      <input ref={importFileRef} type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        className="import-file-input" aria-label="Select Excel workbook" onChange={validateImport}/>
    </form>
    {error && <p className="error" role="alert">{error} {error.toLowerCase().includes('load tasks') || error.toLowerCase().includes('backend not reachable') || error.toLowerCase().includes('timed out')
      ? <button type="button" className="retry-button" onClick={() => { setLoading(true); refreshPage(page); }}>Retry</button> : null}</p>}
    {notice && <p className="success-notice" role="status">{notice}</p>}
    {importBusy && <div className="import-progress" role="status">
      <span>{importPhase === 'validating' ? 'Validating Excel rows...' : `Importing ${importPreview?.valid_count?.toLocaleString() || ''} records...`}</span>
      <progress aria-label={importPhase === 'validating' ? 'Validation progress' : 'Import progress'} />
    </div>}
    {importPreview && <section className="import-preview" aria-live="polite">
      <div className="import-preview-heading"><h3>{importResult ? 'Import complete' : 'Excel import preview'}</h3>
        <button type="button" className="import-dismiss" onClick={() => { setImportPreview(null); setImportResult(null); }} disabled={importBusy}>Close</button>
      </div>
      <p className="import-file-name">{importPreview.filename}</p>
      {importResult
        ? <div className="import-summary" role="status">
          <p>Rows {importResult.total_rows.toLocaleString()}; accepted {importResult.accepted_count.toLocaleString()}; duplicates {importResult.duplicate_count.toLocaleString()}; invalid {importResult.invalid_count.toLocaleString()}.</p>
          <p>{importResult.unique_employee_count.toLocaleString()} unique employee profiles: {importResult.newly_created_profiles.toLocaleString()} newly created, {importResult.existing_profiles_updated.toLocaleString()} existing updated.</p>
        </div>
        : <p className="import-summary">Rows {importPreview.total_rows.toLocaleString()}; accepted {importPreview.accepted_count.toLocaleString()}; duplicates {importPreview.duplicate_count.toLocaleString()}; invalid {importPreview.invalid_count.toLocaleString()}.</p>}
      {(importResult?.duplicates || importPreview.duplicates).length + (importResult?.errors || importPreview.errors).length > 0 && <div className="import-row-errors" aria-label="Rejected Excel rows">
        {[...(importResult?.duplicates || importPreview.duplicates).map(item => ({...item, category: 'Duplicate'})),
          ...(importResult?.errors || importPreview.errors).map(item => ({...item, category: 'Invalid'}))]
          .sort((a, b) => a.row_number - b.row_number).slice(0, shownImportErrors)
          .map(item => <p key={`${item.category}-${item.row_number}`}>Row {item.row_number} (S.No {item.reference}, {item.category}): {item.messages.join(' ')}</p>)}
      </div>}
      {(importResult?.duplicates || importPreview.duplicates).length + (importResult?.errors || importPreview.errors).length > shownImportErrors && <button type="button" className="show-more-import-errors" onClick={() => setShownImportErrors(count => count + 50)}>
        Show more rejected rows
      </button>}
      {((importResult?.duplicates || importPreview.duplicates).length + (importResult?.errors || importPreview.errors).length > 0) && <button type="button" className="import-dismiss" onClick={downloadImportRejections}>Download rejected rows CSV</button>}
      {!importResult && <div className="import-actions">
        <button type="button" onClick={confirmImport} disabled={importBusy || importPreview.duplicate || importPreview.valid_count === 0}>Import {importPreview.valid_count.toLocaleString()} valid records</button>
        <button type="button" className="import-dismiss" onClick={() => setImportPreview(null)} disabled={importBusy}>Cancel</button>
      </div>}
    </section>}
    <div className="task-table-controls">
      <label>Search <input value={search} onChange={e => {setSearch(e.target.value); setPage(0);}} placeholder="Name or task" aria-label="Search tasks across all records" /></label>
      <label>Status <select value={taskStatus} onChange={e => {setTaskStatus(e.target.value); setPage(0);}}><option value="all">All</option><option value="pending">Pending</option><option value="completed">Completed</option></select></label>
      <label>Sort <select value={taskSort} onChange={e => {setTaskSort(e.target.value); setPage(0);}}><option value="newest">Newest</option><option value="oldest">Oldest</option><option value="name">Employee name</option><option value="task">Task description</option></select></label>
      {user?.role === 'admin' && <button type="button" className="delete-all-button" onClick={() => {setDeleteAllText('');setDeleteAllOpen(true);}} disabled={allTaskCount === 0}>Delete All</button>}
    </div>
    <button type="button" className="emp-toggle task-toggle" aria-expanded={open} onClick={() => setOpen(!open)}>
      <span className="emp-arrow">{open ? '▼' : '▶'}</span><h2>Tasks ({totalTasks.toLocaleString()})</h2>
    </button>
    {open && (loading ? <p>Loading tasks...</p> : totalTasks ? <>
      <ExpandableTableContainer scrollClassName="task-list-scroll" label="MY TASKS">
        <table className="task-table">
          <thead><tr><th>S.No</th><th>Name</th><th>Task</th><th>Time</th><th></th></tr></thead>
          <tbody>{tasks.map((t, i) => (
            <tr key={t.id} className={isDone(t) ? 'task-row-completed' : 'task-row-pending'}>
              <td>{page * pageSize + i + 1}</td>
              <td>{t.name}</td>
              <td className={isDone(t) ? 'done' : ''}>{t.title}</td>
              <td>{t.time}</td>
              <td className="task-actions">
                <input type="checkbox" aria-label="Done" checked={isDone(t)} onChange={() => toggle(t.id)}/>
                <button className="delete" onClick={() => remove(t.id)}>Delete</button>
              </td>
            </tr>
          ))}</tbody>
        </table>
      </ExpandableTableContainer>
      <PaginationControls page={page} pageSize={pageSize} total={totalTasks} loading={loading} onPageChange={setPage}
        onPageSizeChange={size => {setPageSize(size);setPage(0);}} label="records" />
    </> : (!error && <div className="empty-state"><span aria-hidden="true">?</span><strong>Your task list is ready</strong><p>Add a task above or import an Excel workbook to get started.</p></div>))}
    {deleteAllOpen && <div className="confirm-backdrop" role="presentation" onMouseDown={e => {if (e.target === e.currentTarget && !bulkDeleting) {setDeleteAllOpen(false);setDeleteAllText('');}}}>
      <section className="confirm-dialog" role="alertdialog" aria-modal="true" aria-labelledby="delete-all-title" aria-describedby="delete-all-description">
        <h2 id="delete-all-title">Delete all task records?</h2>
        <p id="delete-all-description">This will permanently delete all {allTaskCount.toLocaleString()} task records, including records outside the current page and filters. Employee login accounts and Old PF history will not be deleted.</p>
        <p>Type <strong>DELETE ALL</strong> to confirm.</p>
        <input autoFocus value={deleteAllText} onChange={e => setDeleteAllText(e.target.value)} aria-label="Type DELETE ALL" placeholder="DELETE ALL" disabled={bulkDeleting}/>
        <div className="confirm-actions"><button type="button" className="import-dismiss" onClick={() => {setDeleteAllOpen(false);setDeleteAllText('');}} disabled={bulkDeleting}>Cancel</button><button type="button" className="delete-all-confirm" onClick={deleteAllTasks} disabled={bulkDeleting || deleteAllText !== 'DELETE ALL'}>{bulkDeleting ? 'Deleting?' : 'Confirm Delete'}</button></div>
      </section>
    </div>}
  </main>;
}
// MY TASKS is public. Admin pages (#/admin, #/profiles) show the Login page until an admin is signed in;
// the backend independently refuses admin data to anyone without the admin role.
function Root() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(() => !!getToken());
  useEffect(() => {
    onUnauthorized(() => { clearToken(); setUser(null); });   // expired/invalid session -> back to login
    if (!getToken()) return;
    apiFetch(`${API_BASE}/me`)
      .then(res => (res.ok ? res.json() : null))
      .then(u => { if (u) setUser(u); else clearToken(); })
      .catch(() => {})
      .finally(() => setChecking(false));
  }, []);
  // A bare URL opens Home. Existing app screens stay available through hash routes.
  const PAGES = { '#/home': 'home', '#/tasks': 'tasks', '#/login': 'login', '#/admin': 'admin', '#/profiles': 'profiles', '#/analytics': 'analytics', '#/my-analytics': 'my-analytics' };
  const pageFromHash = () => {
    const route = window.location.hash.split('?')[0];
    return !route || route === '#/' ? 'home' : PAGES[route] || 'tasks';
  };
  const [page, setPage] = useState(pageFromHash);
  useEffect(() => {
    const sync = () => setPage(pageFromHash());
    window.addEventListener('hashchange', sync);
    return () => window.removeEventListener('hashchange', sync);
  }, []);
  const go = target => { window.location.hash = `#/${target}`; };
  const intro = useCinematicIntro(page === 'home');   // cinematic intro: own state, Home only
  async function handleLogout() { await logout(); setUser(null); go('tasks'); }
  // Login from an admin page: only the admin role gets in; anyone else is signed straight back out.
  async function handleAdminLogin(u) {
    if (u.role !== 'admin') {
      await logout();
      throw new Error(`${u.name} is not an administrator. Please sign in with the admin account.`);
    }
    setUser(u);   // the URL is still #/admin or #/profiles, so that page opens automatically
  }
  function handleLandingLogin(u) {
    setUser(u);
    go(u.role === 'admin' ? 'admin' : 'my-analytics');
  }
  const isAdmin = user?.role === 'admin';
  const adminPage = page === 'admin' || page === 'profiles' || page === 'analytics';
  const analyticsParams = new URLSearchParams(window.location.hash.split('?')[1] || '');
  return (
    <div className={`layout${page.includes('analytics') ? ' layout-analytics' : ''}${page === 'home' ? ' layout-landing' : ''}`}>
      <aside className="sidebar sidebar-left"></aside>
      <div className="center">
        {intro.element}
        {page === 'home' ? <LandingPage onReplayIntro={intro.replay} onReplayIntent={intro.prefetch}/>
          : <nav className="route-home-nav" aria-label="Main navigation"><a href="#/home">Home</a></nav>}
        {page !== 'home' && checking ? <main className="app-startup" role="status"><span className="loading-spinner"/>Checking your session…</main>
          : page === 'my-analytics' && !user ? <Login onLogin={setUser} onBack={() => go('tasks')} notice="Sign in to view your personal analytics."/>
          : page === 'my-analytics' ? <AnalyticsDashboard user={user} onLogout={handleLogout} onBack={() => go('tasks')} individual/>
          : page === 'home' ? null
          : page === 'tasks' ? <App user={user} onLogout={handleLogout} onOpenAdmin={() => go('admin')}/>
          : page === 'login' ? <Login onLogin={handleLandingLogin} onBack={() => go('home')} notice="Sign in to continue to your workspace."/>
          : !isAdmin ? <Login onLogin={handleAdminLogin} onBack={() => go('tasks')}
              notice={`Admin login required to open ${page === 'profiles' ? 'User Profiles' : page === 'analytics' ? 'Analytics Dashboard' : 'the Admin Dashboard'}.`}/>
          : page === 'admin' ? <AdminDashboard user={user} onLogout={handleLogout} onBack={() => go('tasks')} onOpenProfiles={() => go('profiles')} onOpenAnalytics={() => go('analytics')}/>
          : page === 'analytics' ? <AnalyticsDashboard user={user} onLogout={handleLogout} onBack={() => go('admin')} initialUser={analyticsParams.get('user') ? {username: analyticsParams.get('user'), name: analyticsParams.get('name') || analyticsParams.get('user')} : null}/>
          : <UserProfiles user={user} onLogout={handleLogout} onBack={() => go('admin')} onOpenAnalytics={profile => { window.location.hash = profile ? `#/analytics?user=${encodeURIComponent(profile.username)}&name=${encodeURIComponent(profile.name)}` : '#/analytics'; }}/>}
      </div>
      <aside className="sidebar sidebar-right"></aside>
    </div>
  );
}
createRoot(document.getElementById('root')).render(<AppErrorBoundary><Root/></AppErrorBoundary>);
