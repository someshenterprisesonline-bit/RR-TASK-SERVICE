// Login token handling + fetch wrapper that sends it to the backend.
// The token lives in sessionStorage, so closing the browser tab logs you out.
export const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000/api';
const KEY = 'authToken';

export const getToken = () => { try { return sessionStorage.getItem(KEY); } catch { return null; } };
export const setToken = t => { try { sessionStorage.setItem(KEY, t); } catch { /* storage unavailable */ } };
export const clearToken = () => { try { sessionStorage.removeItem(KEY); } catch { /* storage unavailable */ } };

// Called when the backend says the session is no longer valid (401).
let unauthorizedHandler = () => {};
export const onUnauthorized = fn => { unauthorizedHandler = fn; };

async function fetchWithTimeout(url, options = {}) {
  const { timeoutMs = 30000, signal: externalSignal, ...fetchOptions } = options;
  const controller = new AbortController();
  let timedOut = false;
  const abortFromCaller = () => controller.abort(externalSignal?.reason);
  if (externalSignal?.aborted) abortFromCaller();
  else externalSignal?.addEventListener('abort', abortFromCaller, { once: true });
  const timer = window.setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);
  try {
    return await fetch(url, { ...fetchOptions, signal: controller.signal });
  } catch (error) {
    if (timedOut) throw new Error('The request timed out. Check your connection and try again.');
    throw error;
  } finally {
    window.clearTimeout(timer);
    externalSignal?.removeEventListener('abort', abortFromCaller);
  }
}

export async function apiFetch(url, options = {}) {
  const token = getToken();
  const headers = { ...(options.headers || {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) };
  const res = await fetchWithTimeout(url, { ...options, headers });
  if (res.status === 401 && token) unauthorizedHandler();
  return res;
}

export async function login(username, password) {
  const res = await fetchWithTimeout(`${API_BASE}/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || 'Login failed.');
  setToken(data.token);
  return data.user;
}

export async function logout() {
  try { await apiFetch(`${API_BASE}/logout`, { method: 'POST' }); } catch { /* backend unreachable: still log out locally */ }
  clearToken();
}
