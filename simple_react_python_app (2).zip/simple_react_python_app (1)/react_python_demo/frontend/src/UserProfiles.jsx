import React, { useEffect, useRef, useState } from 'react';
import HeaderTools from './HeaderTools.jsx';
import ExpandableTableContainer from './ExpandableTableContainer.jsx';
import { API_BASE, apiFetch } from './authApi.js';

const initials = name => name.split(/\s+/).filter(Boolean).map(p => p[0]).join('').slice(0, 2).toUpperCase();
const loadJson = async url => {
  const res = await apiFetch(url);
  if (res.status === 403) throw new Error('Only administrators can view user profiles.');
  if (!res.ok) throw new Error('Could not load data from the server.');
  return res.json();
};
const message = err => (err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message);

// Admin-only page: one card per account with live task counts; click a card to see that user's tasks.
export default function UserProfiles({ user, onLogout, onBack, onOpenAnalytics }) {
  const [profiles, setProfiles] = useState([]);
  const [profileSearch, setProfileSearch] = useState('');
  const [profilePage, setProfilePage] = useState(0);
  const [profilePageSize, setProfilePageSize] = useState(50);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);       // profile object
  const [userTasks, setUserTasks] = useState([]);
  const [tasksError, setTasksError] = useState('');
  const [tasksLoading, setTasksLoading] = useState(false);
  const detailRef = useRef(null);
  // "Add User" form (admin creates a login account with role User)
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: '', username: '', password: '' });
  const [usernameEdited, setUsernameEdited] = useState(false);
  const [addError, setAddError] = useState('');
  const [addOk, setAddOk] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadJson(`${API_BASE}/admin/users`).then(setProfiles).catch(e => setError(message(e))).finally(() => setLoading(false));
  }, []);

  async function open(profile) {
    setSelected(profile); setUserTasks([]); setTasksError(''); setTasksLoading(true);
    const tasksUrl = profile.task_generated
      ? `${API_BASE}/admin/task-profiles/${encodeURIComponent(profile.name)}/tasks`
      : `${API_BASE}/admin/users/${encodeURIComponent(profile.username)}/tasks`;
    try { setUserTasks(await loadJson(tasksUrl)); }
    catch (e) { setTasksError(message(e)); }
    finally { setTasksLoading(false); setTimeout(() => detailRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0); }
  }

  function setField(field, value) {
    setForm(f => {
      const next = { ...f, [field]: value };
      // Suggest a username from the name until the admin types one
      if (field === 'name' && !usernameEdited) next.username = value.toLowerCase().replace(/[^a-z0-9_.-]/g, '');
      return next;
    });
    if (field === 'username') setUsernameEdited(true);
  }

  function closeForm() { setAdding(false); setForm({ name: '', username: '', password: '' }); setUsernameEdited(false); setAddError(''); }

  async function createUser(e) {
    e.preventDefault();
    const name = form.name.trim(), username = form.username.trim().toLowerCase();
    if (!name) return setAddError('Please enter a name.');
    if (!/^[a-z0-9_.-]{3,30}$/.test(username)) return setAddError('Username must be 3–30 characters: letters, numbers, dot, dash or underscore.');
    if (form.password.length < 8) return setAddError('Initial password must be at least 8 characters.');
    setSaving(true); setAddError('');
    try {
      const res = await apiFetch(`${API_BASE}/admin/users`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, username, password: form.password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'Could not create the user. Please check the fields.');
      setProfiles(prev => [...prev, data]);          // new card appears immediately
      setAddOk(`${data.name} was added as a User. They can sign in with username "${data.username}".`);
      closeForm();
    } catch (err) {
      setAddError(message(err));
    } finally {
      setSaving(false);
    }
  }

  // Delete (deactivate) a normal user after confirmation
  const [confirming, setConfirming] = useState(null);   // profile being deleted
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  async function deleteUser() {
    const p = confirming;
    setDeleting(true); setDeleteError('');
    try {
      const res = await apiFetch(`${API_BASE}/admin/users/${encodeURIComponent(p.username)}`, { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'Could not delete the user.');
      setProfiles(prev => prev.filter(x => x.username !== p.username));   // card disappears immediately
      if (selected?.username === p.username) setSelected(null);
      setAddOk(`${p.name} was deleted and can no longer log in. Their past tasks are kept in the Admin Dashboard.`);
      setConfirming(null);
    } catch (err) {
      setDeleteError(message(err));
    } finally {
      setDeleting(false);
    }
  }

  const notRecorded = <span className="not-recorded">Not recorded</span>;
  const filteredProfiles = profiles.filter(p => `${p.name} ${p.username} ${p.role}`.toLowerCase().includes(profileSearch.trim().toLowerCase()));
  const visibleProfiles = filteredProfiles.slice(profilePage * profilePageSize, (profilePage + 1) * profilePageSize);
  useEffect(() => {
    const lastPage = Math.max(0, Math.ceil(filteredProfiles.length / profilePageSize) - 1);
    if (profilePage > lastPage) setProfilePage(lastPage);
  }, [filteredProfiles.length, profilePage, profilePageSize]);

  return (
    <main className="profiles-page">
      <div className="heading">
        <h1>USER PROFILES</h1>
        <HeaderTools user={user} onLogout={onLogout}>
          <button type="button" className="admin-btn" onClick={() => onOpenAnalytics()}>Analytics Dashboard</button>
          <button type="button" className="logout-btn" onClick={onBack}>← Back to Admin Dashboard</button>
        </HeaderTools>
      </div>
      <div className="profiles-bar">
        <p className="dash-note profiles-note">Click a profile to see that member's submitted tasks.</p>
        <label className="profiles-search">Search <input type="search" value={profileSearch} onChange={e => { setProfileSearch(e.target.value); setProfilePage(0); }} placeholder="Name or username" aria-label="Search all user profiles" /></label>
        {!adding && <button type="button" className="admin-btn" onClick={() => { setAdding(true); setAddOk(''); }}>+ Add User</button>}
      </div>
      {adding && (
        <form className="add-user-form" onSubmit={createUser} noValidate>
          <h2 className="dash-subtitle">Add User</h2>
          <div className="add-user-fields">
            <label>Name<input value={form.name} onChange={e => setField('name', e.target.value)} maxLength={50} autoFocus placeholder="e.g. Priya" /></label>
            <label>Username<input value={form.username} onChange={e => setField('username', e.target.value)} maxLength={30} autoComplete="off" placeholder="e.g. priya" /></label>
            <label>Initial password<input type="password" value={form.password} onChange={e => setField('password', e.target.value)} maxLength={128} autoComplete="new-password" placeholder="At least 8 characters" /></label>
          </div>
          <p className="dash-note">New members get the <strong>User</strong> role.</p>
          {addError && <p className="error" role="alert">{addError}</p>}
          <div className="add-user-actions">
            <button disabled={saving}>{saving ? 'Creating…' : 'Create User'}</button>
            <button type="button" className="logout-btn" onClick={closeForm}>Cancel</button>
          </div>
        </form>
      )}
      {addOk && <p className="add-user-ok" role="status">{addOk}</p>}
      {error && <p className="error" role="alert">{error}</p>}
      {loading ? <p>Loading…</p> : (
        <>
        <div className="profile-grid-scroll" aria-label="User profile cards">
        <div className="profile-grid">
          {profiles.length === 0 && <div className="empty-state"><span aria-hidden="true">?</span><strong>No employee profiles yet</strong><p>Profiles will appear as employees and tasks are added.</p></div>}
          {profiles.length > 0 && filteredProfiles.length === 0 && <div className="empty-state"><span aria-hidden="true">?</span><strong>No matching profiles</strong><p>Try a different name or username.</p></div>}
          {visibleProfiles.map(p => (
            <div className="profile-cell" key={p.username}>
            <button type="button" onClick={() => open(p)} aria-pressed={selected?.username === p.username}
              className={`profile-card${selected?.username === p.username ? ' selected' : ''}`}>
              <span className={`avatar avatar-${p.role}`} aria-hidden="true">{initials(p.name)}</span>
              <span className="profile-name">{p.name}</span>
              <span className={`role-badge role-${p.role}`}>{p.role === 'admin' ? 'Admin' : 'User'}</span>
              <span className="profile-stats">
                <span><strong>{p.total}</strong>Total</span>
                <span><strong>{p.completed}</strong>Completed</span>
                <span><strong>{p.pending}</strong>Pending</span>
              </span>
            </button>
            <button type="button" className="profile-analytics" onClick={() => onOpenAnalytics(p)}>View analytics <span aria-hidden="true">↗</span></button>
            {p.role === 'user' && !p.task_generated && (
              <button type="button" className="profile-delete" aria-label={`Delete ${p.name}`} title={`Delete ${p.name}`}
                onClick={() => { setConfirming(p); setDeleteError(''); }}>Delete</button>
            )}
            </div>
          ))}
        </div>
        </div>
        {filteredProfiles.length > 0 && <div className="profiles-pagination" aria-label="User profile pages">
          <span>Showing {(profilePage * profilePageSize + 1).toLocaleString()}–{Math.min((profilePage + 1) * profilePageSize, filteredProfiles.length).toLocaleString()} of {filteredProfiles.length.toLocaleString()}</span>
          <div><label>Cards <select value={profilePageSize} onChange={e => { setProfilePageSize(Number(e.target.value)); setProfilePage(0); }} aria-label="Profiles per page"><option value={25}>25</option><option value={50}>50</option><option value={100}>100</option></select></label>
            <button type="button" onClick={() => setProfilePage(page => Math.max(0, page - 1))} disabled={profilePage === 0}>Previous</button>
            <span>Page {profilePage + 1} of {Math.ceil(filteredProfiles.length / profilePageSize)}</span>
            <button type="button" onClick={() => setProfilePage(page => Math.min(Math.ceil(filteredProfiles.length / profilePageSize) - 1, page + 1))} disabled={profilePage >= Math.ceil(filteredProfiles.length / profilePageSize) - 1}>Next</button></div>
        </div>}
      </>
      )}

      {confirming && (
        <div className="confirm-backdrop" onClick={e => { if (e.target === e.currentTarget && !deleting) setConfirming(null); }}>
          <div className="confirm-dialog" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-text"
            onKeyDown={e => { if (e.key === 'Escape' && !deleting) setConfirming(null); }}>
            <h2 id="confirm-title">Delete {confirming.name}?</h2>
            <p id="confirm-text">
              {confirming.name} will be removed from User Profiles and will no longer be able to log in.
              Their past tasks and submission times stay in the Admin Dashboard.
            </p>
            {deleteError && <p className="error" role="alert">{deleteError}</p>}
            <div className="confirm-actions">
              <button type="button" className="logout-btn" autoFocus onClick={() => setConfirming(null)} disabled={deleting}>Cancel</button>
              <button type="button" className="delete" onClick={deleteUser} disabled={deleting}>{deleting ? 'Deleting…' : 'Delete user'}</button>
            </div>
          </div>
        </div>
      )}

      {selected && (
        <section className="profile-detail" ref={detailRef} aria-live="polite">
          <h2 className="dash-subtitle">{selected.name}'s tasks ({userTasks.length})</h2>
          {tasksError && <p className="error" role="alert">{tasksError}</p>}
          {tasksLoading ? <p>Loading…</p> : !tasksError && (userTasks.length ? (
            <ExpandableTableContainer scrollClassName="emp-scroll profile-task-scroll" label={`${selected.name} task records`}>
              <table className="task-table dash-table">
                <thead>
                  <tr><th>S.No</th><th>Task Description</th><th>Task Time</th><th>Submission Date (IST)</th><th>Submission Time (IST)</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {userTasks.map((r, i) => (
                    <tr key={r.id}>
                      <td>{i + 1}</td>
                      <td>{r.task}</td>
                      <td>{r.task_time || '—'}</td>
                      <td>{r.submitted_date || notRecorded}</td>
                      <td>{r.submitted_time || notRecorded}</td>
                      <td><span className={`status-badge status-${r.status.toLowerCase()}`}>{r.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </ExpandableTableContainer>
          ) : <div className="empty-state"><span aria-hidden="true">?</span><strong>No tasks for {selected.name}</strong><p>Submitted work will appear here.</p></div>)}
        </section>
      )}
    </main>
  );
}
