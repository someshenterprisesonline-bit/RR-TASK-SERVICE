import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "http://127.0.0.1:8000/api/tasks";

const STATUS_OPTIONS = [
  { value: "pending", label: "Not Started" },
  { value: "in_progress", label: "In Progress" },
  { value: "completed", label: "Completed" },
  { value: "on_hold", label: "On Hold" },
];

function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [status, setStatus] = useState("pending");
  const [filter, setFilter] = useState("all");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("all"); // New state to track view (all, old, new)

  const fetchTasks = async () => {
    try {
      setError("");
      const response = await axios.get(API);
      setTasks(response.data);
    } catch (err) {
      console.error(err);
      setError("Cannot connect to Python backend.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const addTask = async () => {
    if (!title.trim()) {
      setError("Please enter a task title.");
      return;
    }

    try {
      setError("");
      const response = await axios.post(API, {
        title: title.trim(),
        status,
      });

      setTasks(prev => [...prev, response.data]);
      setTitle("");
      setStatus("pending");
    } catch (err) {
      console.error(err);
      setError("Failed to create task.");
    }
  };

  const updateTask = async (taskId, newStatus) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    try {
      setError("");
      const response = await axios.patch(
        `${API}/${taskId}`,
        {
          title: task.title,
          status: newStatus,
        }
      );

      setTasks(prev =>
        prev.map(t =>
          t.id === taskId ? response.data : t
        )
      );
    } catch (err) {
      console.error(err);
      setError("Failed to update task.");
    }
  };

  const deleteTask = async (taskId) => {
    try {
      setError("");
      await axios.delete(`${API}/${taskId}`);
      setTasks(prev =>
        prev.filter(t => t.id !== taskId)
      );
    } catch (err) {
      console.error(err);
      setError("Failed to delete task.");
    }
  };

  const filteredTasks =
    filter === "all"
      ? tasks
      : tasks.filter(task => task.status === filter);

  const oldTasks = tasks.filter(task => task.status === "completed");
  const newTasks = tasks.filter(task => task.status !== "completed");

  return (
    <div style={{
      maxWidth: 1000,
      margin: "40px auto",
      padding: 20,
      fontFamily: "Arial, sans-serif"
    }}>
      <h1>Task Manager</h1>

      <p>React + Python FastAPI</p>

      {error && (
        <div style={{
          padding: 12,
          background: "#ffe5e5",
          color: "#a00000",
          marginBottom: 20
        }}>
          {error}
          <button onClick={fetchTasks}>
            Retry
          </button>
        </div>
      )}

      <h2>Create Task</h2>

      <div style={{
        display: "flex",
        gap: 10,
        marginBottom: 25
      }}>
        <input
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Enter task title"
          style={{ flex: 1, padding: 10 }}
        />

        <select
          value={status}
          onChange={e => setStatus(e.target.value)}
        >
          {STATUS_OPTIONS.map(option => (
            <option
              key={option.value}
              value={option.value}
            >
              {option.label}
            </option>
          ))}
        </select>

        <button onClick={addTask}>
          Add Task
        </button>
      </div>

      <h2>Filter Tasks</h2>

      <div style={{
        display: "flex",
        gap: 10,
        marginBottom: 20
      }}>
        <button onClick={() => setFilter("all")}>
          All
        </button>

        {STATUS_OPTIONS.map(option => (
          <button
            key={option.value}
            onClick={() => setFilter(option.value)}
          >
            {option.label}
          </button>
        ))}
      </div>

      <h2>View Tasks</h2>

      <div style={{
        display: "flex",
        gap: 10,
        marginBottom: 20
      }}>
        <button onClick={() => setView("all")}>
          All
        </button>

        <button onClick={() => setView("old")}>
          Old
        </button>

        <button onClick={() => setView("new")}>
          New
        </button>
      </div>

      <h2>Tasks ({filteredTasks.length})</h2>

      {loading ? (
        <p>Loading tasks...</p>
      ) : (
        <div>
          <h3>Old Tasks</h3>
          <table
            border="1"
            cellPadding="12"
            style={{
              width: "100%",
              borderCollapse: "collapse"
            }}
          >
            <thead>
              <tr>
                <th>ID</th>
                <th>Task Title</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {oldTasks.map(task => (
                <tr key={task.id}>
                  <td>{task.id}</td>
                  <td>{task.title}</td>
                  <td>{task.status}</td>
                  <td>
                    <button
                      onClick={() => deleteTask(task.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3>New Tasks</h3>
          <table
            border="1"
            cellPadding="12"
            style={{
              width: "100%",
              borderCollapse: "collapse"
            }}
          >
            <thead>
              <tr>
                <th>ID</th>
                <th>Task Title</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {newTasks.map(task => (
                <tr key={task.id}>
                  <td>{task.id}</td>
                  <td>{task.title}</td>
                  <td>
                    <select
                      value={task.status}
                      onChange={e =>
                        updateTask(task.id, e.target.value)
                      }
                    >
                      {STATUS_OPTIONS.map(option => (
                        <option
                          key={option.value}
                          value={option.value}
                        >
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <button
                      onClick={() => deleteTask(task.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default App;
