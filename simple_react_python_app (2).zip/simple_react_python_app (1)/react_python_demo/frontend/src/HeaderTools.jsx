import React from 'react';
import NavBar from './NavBar.jsx';

// Right side of the page heading: optional extra buttons, signed-in user + Logout (when logged in), display controls.
export default function HeaderTools({ user, onLogout, children }) {
  return (
    <div className="heading-tools">
      {children}
      {user && <>
        <span className="user-chip" title={`Signed in as ${user.username}`}>
          {user.name}<span className={`role-badge role-${user.role}`}>{user.role === 'admin' ? 'Admin' : 'User'}</span>
        </span>
        <button type="button" className="logout-btn" onClick={onLogout}>Logout</button>
      </>}
      <NavBar/>
    </div>
  );
}
