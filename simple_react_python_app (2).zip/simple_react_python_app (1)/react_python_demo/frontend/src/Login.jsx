import React, { useState } from 'react';
import NavBar from './NavBar.jsx';
import { login } from './authApi.js';

export default function Login({ onLogin, onBack, notice }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    if (!username.trim() || !password) { setError('Please enter your username and password.'); return; }
    setBusy(true); setError('');
    try {
      await onLogin(await login(username.trim(), password));   // onLogin may reject (e.g. not an admin)
    } catch (err) {
      setError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message);
      setPassword('');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="login-card">
      <div className="heading"><h1>MY TASKS</h1><NavBar/></div>
      <h2 className="login-title">Sign in</h2>
      {notice && <p className="login-notice">{notice}</p>}
      <form onSubmit={submit} className="login-form" noValidate>
        <label>
          Username
          <input value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" autoFocus placeholder="e.g. jaga" />
        </label>
        <label>
          Password
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" placeholder="Your password" />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        <button disabled={busy}>{busy ? 'Signing in…' : 'Login'}</button>
      </form>
      {onBack && <button type="button" className="logout-btn login-back" onClick={onBack}>← Back to MY TASKS</button>}
    </main>
  );
}
