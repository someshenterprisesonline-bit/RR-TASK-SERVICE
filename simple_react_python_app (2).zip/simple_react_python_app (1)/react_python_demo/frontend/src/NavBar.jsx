import React, { useEffect, useState } from 'react';

// Text size steps (1 = current default size)
const MIN_SCALE = 0.8;
const MAX_SCALE = 1.5;
const STEP = 0.1;

const load = (key, fallback) => {
  try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
};
const save = (key, value) => {
  try { localStorage.setItem(key, value); } catch { /* storage unavailable */ }
};

const SunIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
  </svg>
);
const MoonIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
  </svg>
);

export default function NavBar() {
  const [theme, setTheme] = useState(() => (load('theme', 'light') === 'dark' ? 'dark' : 'light'));
  const [scale, setScale] = useState(() => {
    const s = parseFloat(load('textScale', '1'));
    return Number.isFinite(s) ? Math.min(MAX_SCALE, Math.max(MIN_SCALE, s)) : 1;
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    save('theme', theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.style.setProperty('--scale', String(scale));
    save('textScale', String(scale));
  }, [scale]);

  const change = delta => setScale(s => Math.round(Math.min(MAX_SCALE, Math.max(MIN_SCALE, s + delta)) * 10) / 10);
  const isDark = theme === 'dark';

  return (
    <nav className="navbar" aria-label="Display settings">
      <button
        type="button"
        className="nav-btn"
        onClick={() => setTheme(isDark ? 'light' : 'dark')}
        aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
        title={isDark ? 'Light mode' : 'Dark mode'}
        aria-pressed={isDark}
      >
        {isDark ? <SunIcon /> : <MoonIcon />}
      </button>
      <span className="nav-divider" aria-hidden="true" />
      <button type="button" className="nav-btn" onClick={() => change(STEP)} disabled={scale >= MAX_SCALE}
        aria-label="Increase text size" title="Increase text size">+</button>
      <span className="nav-scale" aria-live="polite">{Math.round(scale * 100)}%</span>
      <button type="button" className="nav-btn" onClick={() => change(-STEP)} disabled={scale <= MIN_SCALE}
        aria-label="Decrease text size" title="Decrease text size">−</button>
    </nav>
  );
}
