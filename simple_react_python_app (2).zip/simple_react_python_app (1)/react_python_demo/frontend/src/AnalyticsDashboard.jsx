﻿import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import HeaderTools from './HeaderTools.jsx';
import { API_BASE, apiFetch } from './authApi.js';

const COLORS = ['#5865f2', '#20b88a', '#ffad42', '#e66b99', '#48a8d6'];
const fmt = n => Number(n || 0).toLocaleString();
const dateInput = d => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(d);
const wedge = (cx, cy, r, start, end) => { if (end <= start) return ''; if (end - start >= 359.99) return `M ${cx} ${cy-r} A ${r} ${r} 0 1 1 ${cx} ${cy+r} A ${r} ${r} 0 1 1 ${cx} ${cy-r} Z`; const a = (start - 90) * Math.PI / 180, b = (end - 90) * Math.PI / 180; const x1 = cx + r * Math.cos(a), y1 = cy + r * Math.sin(a), x2 = cx + r * Math.cos(b), y2 = cy + r * Math.sin(b); return `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${end - start > 180 ? 1 : 0} 1 ${x2} ${y2} Z`; };
function highlightMatch(value, query) {
  const text = String(value || ''), needle = String(query || '').trim();
  if (!needle) return text;
  const lower = text.toLocaleLowerCase(), search = needle.toLocaleLowerCase(), parts = [];
  let cursor = 0, found = lower.indexOf(search);
  while (found !== -1) {
    if (found > cursor) parts.push(text.slice(cursor, found));
    parts.push(<mark className="employee-match" key={`${found}-${parts.length}`}>{text.slice(found, found + needle.length)}</mark>);
    cursor = found + needle.length; found = lower.indexOf(search, cursor);
  }
  if (!parts.length) return text;
  if (cursor < text.length) parts.push(text.slice(cursor));
  return parts;
}
const ranges = {
  today: () => [dateInput(new Date()), dateInput(new Date())],
  '7d': () => { const end = new Date(); const start = new Date(end); start.setDate(start.getDate() - 6); return [dateInput(start), dateInput(end)]; },
  '30d': () => { const end = new Date(); const start = new Date(end); start.setDate(start.getDate() - 29); return [dateInput(start), dateInput(end)]; },
};

function ChartSvg({ kind, data, expanded = false }) {
  const W = 760, H = expanded ? 410 : 290, pad = { l: 50, r: 22, t: 22, b: 42 };
  const chart = useRef(null);
  const [tip, setTip] = useState(null);
  const [showCompleted, setShowCompleted] = useState(true);
  const [showPending, setShowPending] = useState(true);
  useEffect(() => { if (!chart.current) return; chart.current.setAttribute('viewBox', `0 0 ${W} ${H}`); }, [H]);
  const labels = data?.series?.labels || [];
  const values = data?.series?.tasks || [];
  const plotW = W - pad.l - pad.r, plotH = H - pad.t - pad.b;
  const max = Math.max(1, ...values);
  const points = values.map((v, i) => [pad.l + (values.length < 2 ? plotW / 2 : i * plotW / (values.length - 1)), pad.t + plotH - v / max * plotH]);
  const pts = points.map(p => p.join(',')).join(' ');
  const grid = [0, 1, 2, 3].map(i => pad.t + i * plotH / 3);
  const title = { trend: 'Task submissions', area: 'Submission volume', status: 'Completion status', pie: 'Task status mix', donut: 'Completion rate', top: 'Top contributors', stacked: 'Employee task comparisons', scatter: 'Workload vs completion', treemap: 'Workload distribution', heat: 'Daily activity' }[kind];
  const statusValues = [data?.summary?.completed || 0, data?.summary?.pending || 0];
  const ranked = data?.top_users?.slice(0, 10) || [];
  const heat = data?.daily_activity || [];
  const total = data?.summary?.total_tasks || 0;
  const done = data?.summary?.completed || 0;
  const shownTotal = (showCompleted ? done : 0) + (showPending ? total - done : 0);
  const rate = data?.summary?.completion_rate || 0;
  const ring = 2 * Math.PI * 65;
  const download = () => {
    const svg = chart.current; if (!svg) return;
    const xml = new XMLSerializer().serializeToString(svg);
    const url = URL.createObjectURL(new Blob([xml], { type: 'image/svg+xml;charset=utf-8' }));
    const image = new Image(); image.onload = () => { const canvas = document.createElement('canvas'); canvas.width = W * 2; canvas.height = H * 2; const context = canvas.getContext('2d'); context.scale(2, 2); context.fillStyle = getComputedStyle(svg).color || '#fff'; context.fillRect(0, 0, W, H); context.drawImage(image, 0, 0, W, H); URL.revokeObjectURL(url); canvas.toBlob(blob => { if (!blob) return; const png = URL.createObjectURL(blob), a = document.createElement('a'); a.href = png; a.download = `analytics-${kind}.png`; a.click(); URL.revokeObjectURL(png); }, 'image/png'); }; image.onerror = () => URL.revokeObjectURL(url); image.src = url;
  };
  const axes = <>{grid.map((y, i) => <g key={y}><line x1={pad.l} x2={W - pad.r} y1={y} y2={y} stroke="var(--chart-grid)"/><text x={pad.l - 10} y={y + 4} textAnchor="end" className="chart-axis">{Math.round(max * (3 - i) / 3)}</text></g>)}
    {labels.filter((_, i) => i % Math.max(1, Math.ceil(labels.length / 6)) === 0).map(label => { const i = labels.indexOf(label); return <text key={label} x={points[i]?.[0] || pad.l} y={H - 13} textAnchor="middle" className="chart-axis">{label.slice(5)}</text>; })}</>;
  return <div className="chart-canvas-wrap">{['status','pie','stacked'].includes(kind) && <div className="chart-legend"><button type="button" aria-pressed={showCompleted} onClick={() => setShowCompleted(v => !v)}><i style={{background:COLORS[1]}}/>Completed</button><button type="button" aria-pressed={showPending} onClick={() => setShowPending(v => !v)}><i style={{background:COLORS[2]}}/>Pending</button></div>}<svg ref={chart} className="analytics-svg" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={title}>
    <title>{title}</title>
    {(kind === 'trend' || kind === 'area') && <>{axes}{kind === 'area' && <polygon points={`${pad.l},${pad.t + plotH} ${pts} ${W - pad.r},${pad.t + plotH}`} fill="url(#analyticsArea)"/>}<defs><linearGradient id="analyticsArea" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor={COLORS[0]} stopOpacity=".32"/><stop offset="100%" stopColor={COLORS[0]} stopOpacity=".015"/></linearGradient></defs><polyline points={pts} fill="none" stroke={COLORS[0]} strokeWidth="3.5" strokeLinejoin="round" strokeLinecap="round"/>{points.map(([x,y], i) => <circle key={i} cx={x} cy={y} r="5" fill={COLORS[0]} onMouseEnter={() => setTip({x, y, text: `${labels[i]} · ${values[i]} tasks`})} onMouseLeave={() => setTip(null)}/>)}</>}
    {kind === 'pie' && <g>{total ? <>{showCompleted && done>0 && <path d={wedge(270,145,95,0,done/Math.max(1,shownTotal)*360)} fill={COLORS[1]}><title>Completed: {fmt(done)}</title></path>}{showPending && total-done>0 && <path d={wedge(270,145,95,showCompleted?done/Math.max(1,shownTotal)*360:0,360)} fill={COLORS[2]}><title>Pending: {fmt(total-done)}</title></path>}<text x="430" y="132" className="chart-label">● Completed · {fmt(done)}</text><text x="430" y="170" className="chart-label" fill={COLORS[2]}>● Pending · {fmt(total-done)}</text></> : <text x="380" y="145" textAnchor="middle" className="chart-axis">No task data</text>}</g>}
    {kind === 'status' && <g>{['Completed', 'Pending'].map((label, i) => {if(i===0&&!showCompleted||i===1&&!showPending)return null;const x = 180 + i * 220, value = statusValues[i], width = Math.max(4, value / Math.max(1, shownTotal) * 150); return <g key={label}><text x={x} y="82" className="chart-label">{label}</text><rect x={x} y="104" width="150" height="28" rx="14" fill="var(--chart-track)"/><rect x={x} y="104" width={width} height="28" rx="14" fill={COLORS[i === 0 ? 1 : 2]}><title>{label}: {fmt(value)}</title></rect><text x={x} y="160" className="chart-value">{fmt(value)}</text></g>;})}<text x="380" y="228" textAnchor="middle" className="chart-axis">{fmt(shownTotal)} visible tasks in the selected range</text></g>}
    {kind === 'donut' && <g transform="translate(250 145) rotate(-90)"><circle r="65" fill="none" stroke="var(--chart-track)" strokeWidth="24"/><circle r="65" fill="none" stroke={COLORS[1]} strokeWidth="24" strokeDasharray={`${ring * rate / 100} ${ring}`} strokeLinecap="round"><title>{rate}% complete</title></circle><g transform="rotate(90)"><text textAnchor="middle" y="-2" className="chart-value">{rate}%</text><text textAnchor="middle" y="23" className="chart-axis">complete</text></g><g transform="translate(130 0) rotate(90)"><text x="0" y="-12" className="chart-label">{fmt(done)} completed</text><text x="0" y="18" className="chart-label">{fmt(total - done)} pending</text><text x="0" y="53" className="chart-axis">{fmt(total)} total tasks</text></g></g>}
    {kind === 'top' && <g>{ranked.length ? ranked.map((u, i) => { const y = 24 + i * Math.min(24, (H - 45) / Math.max(1, ranked.length)); const width = Math.max(2, (u.total / Math.max(1, ranked[0].total)) * 480); return <g key={u.username}><text x="4" y={y + 14} className="chart-axis">{u.name.slice(0, 22)}</text><rect x="180" y={y} width="480" height="16" rx="8" fill="var(--chart-track)"/><rect x="180" y={y} width={width} height="16" rx="8" fill={COLORS[i % COLORS.length]}><title>{u.name}: {u.total} tasks, {u.completed} completed</title></rect><text x={Math.min(680, 188 + width)} y={y + 13} className="chart-axis">{u.total}</text></g>; }) : <text x="380" y="145" textAnchor="middle" className="chart-axis">No attributed task data in this range</text>}</g>}
    {kind === 'stacked' && <g>{ranked.slice(0,8).map((u,i)=>{const y=22+i*29, x=190, scale=440/Math.max(1,...ranked.map(p=>p.total)), a=showCompleted?u.completed*scale:0, b=showPending?u.pending*scale:0;return <g key={u.username}><text x="2" y={y+14} className="chart-axis">{u.name.slice(0,25)}</text><rect x={x} y={y} width={a} height="18" rx="5" fill={COLORS[1]}><title>{u.name}: {u.completed} completed</title></rect><rect x={x+a} y={y} width={b} height="18" rx="5" fill={COLORS[2]}><title>{u.name}: {u.pending} pending</title></rect></g>;})}<text x="190" y={H-8} className="chart-axis">Completed</text><text x="280" y={H-8} className="chart-axis">Pending</text></g>}
    {kind === 'scatter' && <g>{grid}{ranked.map((u,i)=>{const x=pad.l+u.total/Math.max(1,...ranked.map(p=>p.total))*plotW,y=pad.t+plotH-(u.total?u.completed/u.total:0)*plotH;return <g key={u.username}><circle cx={x} cy={y} r="7" fill={COLORS[i%COLORS.length]} opacity=".8" onMouseEnter={()=>setTip({x,y,text:`${u.name}: ${u.total} tasks · ${u.total?Math.round(100*u.completed/u.total):0}% complete`})} onMouseLeave={()=>setTip(null)}/></g>})}<text x={W/2} y={H-8} textAnchor="middle" className="chart-axis">Task workload →</text><text transform={`translate(13 ${H/2}) rotate(-90)`} textAnchor="middle" className="chart-axis">Completion rate →</text></g>}
    {kind === 'treemap' && <g>{ranked.length?ranked.map((u,i)=>{const x=14+i*(W-28)/ranked.length,w=(W-34)/ranked.length-4,h=Math.max(35,plotH*u.total/Math.max(1,...ranked.map(p=>p.total)));return <g key={u.username}><rect x={x} y={H-pad.b-h} width={w} height={h} rx="5" fill={COLORS[i%COLORS.length]} opacity=".82"><title>{u.name}: {u.total} tasks</title></rect>{w>42&&<text x={x+5} y={H-pad.b-h+18} fontSize="10" fill="white">{u.name.slice(0,10)}</text>}</g>}):<text x="380" y="145" textAnchor="middle" className="chart-axis">No workload data</text>}</g>}
    {kind === 'heat' && <g>{heat.length ? heat.slice(-140).map((d, i, rows) => {const cols = Math.min(20, Math.ceil(Math.sqrt(rows.length * 2))), cell = Math.min(24, (W - 80) / cols - 3), x = 30 + i % cols * (cell + 3), y = 20 + Math.floor(i / cols) * (cell + 3), intensity = d.count / Math.max(1, ...rows.map(r => r.count)); return <rect key={d.date} x={x} y={y} width={cell} height={cell} rx="4" fill={COLORS[0]} opacity={0.12 + intensity * .88} onMouseEnter={() => setTip({x:x + cell, y:y + cell, text:`${d.date} · ${d.count} tasks`})} onMouseLeave={() => setTip(null)}><title>{d.date}: {d.count} tasks</title></rect>;}) : <text x="380" y="145" textAnchor="middle" className="chart-axis">No dated submissions in this range</text>}</g>}
    {tip && <g pointerEvents="none"><rect x={Math.min(W - 220, Math.max(2, tip.x - 40))} y={Math.max(3, tip.y - 36)} width="215" height="27" rx="7" fill="var(--chart-tip)"/><text x={Math.min(W - 212, Math.max(10, tip.x - 32))} y={Math.max(21, tip.y - 18)} className="chart-tip-text">{tip.text}</text></g>}
  </svg><div className="chart-actions"><button type="button" onClick={download} aria-label={`Download ${title} chart as PNG`} title="Download chart as PNG">↓</button></div></div>;
}

function ChartCard({ kind, title, data }) {
  const [full, setFull] = useState(false);
  const triggerRef = useRef(null);
  const closeRef = useRef(null);
  useEffect(() => {
    if (!full) return undefined;
    const bodyOverflow = document.body.style.overflow;
    const rootOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    const onKeyDown = event => { if (event.key === 'Escape') { event.preventDefault(); setFull(false); } };
    document.addEventListener('keydown', onKeyDown);
    const frame = requestAnimationFrame(() => closeRef.current?.focus());
    return () => {
      cancelAnimationFrame(frame);
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = bodyOverflow;
      document.documentElement.style.overflow = rootOverflow;
      triggerRef.current?.focus();
    };
  }, [full]);
  const modal = full && createPortal(<div className="chart-fullscreen" role="dialog" aria-modal="true" aria-label={`${title} expanded chart`} onMouseDown={event => { if (event.target === event.currentTarget) setFull(false); }}>
    <div className="chart-fullscreen-panel"><div className="analytics-chart-heading"><h2>{title}</h2><button ref={closeRef} className="chart-close" type="button" onClick={() => setFull(false)}>Close</button></div><ChartSvg kind={kind} data={data} expanded/></div>
  </div>, document.body);
  return <article className="analytics-chart-card"><div className="analytics-chart-heading"><div><span className="chart-kicker">INSIGHT</span><h3>{title}</h3></div><button ref={triggerRef} className="chart-expand" type="button" onClick={() => setFull(true)} aria-label={`Expand ${title} chart`} title="Expand chart">⛶</button></div><ChartSvg kind={kind} data={data}/>{modal}</article>;
}

export default function AnalyticsDashboard({ user, onLogout, onBack, individual = false, initialUser = null }) {
  const [range, setRange] = useState('30d');
  const [custom, setCustom] = useState(() => ranges['30d']());
  const [period, setPeriod] = useState('daily');
  const [status, setStatus] = useState('all');
  const [query, setQuery] = useState(''); const [debounced, setDebounced] = useState('');
  const [users, setUsers] = useState([]); const [selected, setSelected] = useState(initialUser);
  const [view, setView] = useState(() => (individual || initialUser) ? 'individual' : 'overall');
  const [suggestionsOpen, setSuggestionsOpen] = useState(false); const [activeSuggestion, setActiveSuggestion] = useState(-1);
  const [usersLoading, setUsersLoading] = useState(false); const [userSearchError, setUserSearchError] = useState('');
  const userSearchAbort = useRef(null); const userSearchInput = useRef(null);
  const [result, setResult] = useState(null); const [loading, setLoading] = useState(true); const [error, setError] = useState('');
  useEffect(() => { const timer = setTimeout(() => setDebounced(query.trim()), 180); return () => clearTimeout(timer); }, [query]);
  useEffect(() => {
    if (user.role !== 'admin' || individual || view !== 'individual' || !debounced) {
      setUsers([]); setUsersLoading(false); setUserSearchError('');
      return undefined;
    }
    const controller = new AbortController();
    userSearchAbort.current = controller;
    setUsers([]); setUsersLoading(true); setUserSearchError(''); setActiveSuggestion(-1);
    apiFetch(`${API_BASE}/admin/analytics/users?q=${encodeURIComponent(debounced)}&limit=12`, {signal:controller.signal}).then(r => { if (!r.ok) throw new Error('Could not search employee profiles.'); return r.json(); }).then(d => { if (!controller.signal.aborted) setUsers(d.items); }).catch(e => { if (e.name !== 'AbortError' && !controller.signal.aborted) setUserSearchError(e.message); }).finally(() => { if (!controller.signal.aborted) setUsersLoading(false); });
    return () => controller.abort();
  }, [debounced, user.role, individual, view]);
  function searchEmployees(value) {
    userSearchAbort.current?.abort();
    setQuery(value); setActiveSuggestion(-1); setUserSearchError('');
    if (value.trim()) { setSuggestionsOpen(true); setUsersLoading(true); }
    else { setSuggestionsOpen(false); setUsers([]); setUsersLoading(false); setDebounced(''); }
  }
  function chooseEmployee(profile) {
    userSearchAbort.current?.abort(); setUsersLoading(false); setSelected(profile); setView('individual');
    setSuggestionsOpen(false); setActiveSuggestion(-1);
  }
  function handleEmployeeSearchKeyDown(event) {
    if (event.key === 'ArrowDown' && suggestionsOpen && users.length) {
      event.preventDefault(); setActiveSuggestion(index => Math.min(index + 1, users.length - 1));
    } else if (event.key === 'ArrowUp' && suggestionsOpen && users.length) {
      event.preventDefault(); setActiveSuggestion(index => index <= 0 ? 0 : index - 1);
    } else if (event.key === 'Enter' && suggestionsOpen && users.length) {
      event.preventDefault(); chooseEmployee(users[activeSuggestion >= 0 ? activeSuggestion : 0]);
    } else if (event.key === 'Escape' && suggestionsOpen) {
      event.preventDefault(); setSuggestionsOpen(false); setActiveSuggestion(-1);
    }
  }
  useEffect(() => {
    if (activeSuggestion >= 0) document.getElementById(`employee-suggestion-${activeSuggestion}`)?.scrollIntoView({block:'nearest'});
  }, [activeSuggestion]);
  const [start, end] = range === 'custom' ? custom : ranges[range]();
  useEffect(() => {
    const controller = new AbortController(); let alive = true;
    if (!individual && view === 'individual' && !selected) {
      setResult(null); setLoading(false); setError('');
      return () => { alive = false; controller.abort(); };
    }
    setLoading(true); setError('');
    const root = individual ? `${API_BASE}/my/analytics` : view === 'individual' ? `${API_BASE}/admin/analytics/users/${encodeURIComponent(selected.username)}` : `${API_BASE}/admin/analytics`;
    apiFetch(`${root}?start=${start}&end=${end}&period=${period}&status=${status}`, {signal:controller.signal}).then(async r => { if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.detail || 'Could not load analytics.'); } return r.json(); }).then(d => { if (alive) setResult(d); }).catch(e => { if (alive && e.name !== 'AbortError') setError(e.message === 'Failed to fetch' ? 'Analytics service is unavailable. Retry in a moment.' : e.message); }).finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; controller.abort(); };
  }, [start, end, period, status, selected, individual, view]);
  const summary = result?.summary;
  const csv = () => {
    if (!result) return;
    const rows = [['Metric','Value'], ...Object.entries(summary || {}), ['Period', period], ['Start', start], ['End', end], [], ['Date','Tasks'], ...(result.series?.labels || []).map((d,i) => [d, result.series.tasks[i]]), [], ['Employee','Total','Completed','Pending'], ...(result.top_users || []).map(u => [u.name,u.total,u.completed,u.pending])];
    const content = rows.map(row => row.map(v => `"${String(v ?? '').replaceAll('"','""')}"`).join(',')).join('\r\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff',content], {type:'text/csv;charset=utf-8'})); a.download = 'filtered-task-analytics.csv'; a.click(); URL.revokeObjectURL(a.href);
  };
  const excel = async () => {
    try {
      const root = individual ? `${API_BASE}/my/analytics/export` : `${API_BASE}/admin/analytics/export`;
      const params = new URLSearchParams({format:'xlsx',start,end,period,status});
      if (selected && !individual && view === 'individual') params.set('username', selected.username);
      const response = await apiFetch(`${root}?${params}`);
      if (!response.ok) throw new Error('Could not export the Excel report.');
      const url = URL.createObjectURL(await response.blob()); const a = document.createElement('a');
      a.href = url; a.download = 'filtered-task-analytics.xlsx'; a.click(); URL.revokeObjectURL(url);
    } catch (e) { setError(e.message); }
  };
  const title = individual ? `${user.name}'s Analytics` : view === 'individual' ? (selected ? `${selected.name} · Individual Analytics` : 'Individual Analytics') : 'Overall Analytics';
  const charts = useMemo(() => [['status','Completed vs pending','status'],['pie','Task status distribution','pie'],['donut','Completion rate','donut'],['trend',`${period[0].toUpperCase()}${period.slice(1)} submissions`,'trend'],['area','Submission activity','area'],['stacked','Employee task comparisons','stacked'],['top','Top 10 contributors','top'],['scatter','Workload vs completion rate','scatter'],['treemap','Workload distribution','treemap'],['heat','Daily activity heatmap','heat']], [period]);
  return <main className="analytics-page"><div className="heading analytics-page-heading"><div><span className="analytics-eyebrow">WORKSPACE INTELLIGENCE</span><h1>ANALYTICS</h1></div><HeaderTools user={user} onLogout={onLogout}><button className="logout-btn" onClick={onBack}>← Back</button></HeaderTools></div>
    <section className="analytics-hero"><div><span className="analytics-eyebrow">PERFORMANCE OVERVIEW</span><h2>{title}</h2><p>Task activity based on actual submission records, reported in Asia/Kolkata time.</p></div><div className="analytics-hero-mark" aria-hidden="true">✳</div></section>
    <div className="analytics-toolbar"><div className="analytics-tabs" role="group" aria-label="Analytics view">{!individual && <><button type="button" aria-pressed={view === 'overall'} className={view === 'overall' ? 'active' : ''} onClick={() => setView('overall')}>Overall</button><button type="button" aria-pressed={view === 'individual'} className={view === 'individual' ? 'active' : ''} onClick={() => setView('individual')}>Individual</button></>}{individual && <span className="analytics-tabs-current">Personal analytics</span>}</div>
      {!individual && user.role === 'admin' && view === 'individual' && <div className="analytics-user-search" onBlur={event => { if (!event.currentTarget.contains(event.relatedTarget)) { setSuggestionsOpen(false); setActiveSuggestion(-1); } }}>
        <div className="employee-search-heading"><label htmlFor="analytics-user">Search employees</label>{selected && <span className="employee-selected-label">Viewing {selected.name}</span>}</div>
        <div className="employee-search-control">
          <input ref={userSearchInput} id="analytics-user" type="search" role="combobox" aria-autocomplete="list" aria-expanded={suggestionsOpen && Boolean(query.trim())} aria-controls="employee-suggestions" aria-activedescendant={activeSuggestion >= 0 ? `employee-suggestion-${activeSuggestion}` : undefined} autoComplete="off" value={query} onFocus={() => { if (query.trim()) setSuggestionsOpen(true); }} onChange={event => searchEmployees(event.target.value)} onKeyDown={handleEmployeeSearchKeyDown} placeholder="Search by employee name or ID"/>
          {query && <button type="button" className="employee-search-clear" aria-label="Clear employee search" title="Clear search" onMouseDown={event => event.preventDefault()} onClick={() => { searchEmployees(''); userSearchInput.current?.focus(); }}>×</button>}
        </div>
        {suggestionsOpen && query.trim() && <div id="employee-suggestions" className="employee-suggestions" role="listbox" aria-label="Matching employees" aria-busy={usersLoading}>
          {usersLoading ? <div className="employee-suggestion-status" role="status">Searching employees…</div> : userSearchError ? <div className="employee-suggestion-status employee-suggestion-error" role="alert">{userSearchError}</div> : users.length ? users.map((profile, index) => <button type="button" role="option" id={`employee-suggestion-${index}`} aria-selected={activeSuggestion === index} className={`employee-suggestion${activeSuggestion === index ? ' active' : ''}`} key={profile.username} onMouseDown={event => event.preventDefault()} onMouseEnter={() => setActiveSuggestion(index)} onClick={() => chooseEmployee(profile)}>
            <span className="employee-suggestion-avatar" aria-hidden="true">{profile.name.split(/\s+/).filter(Boolean).map(part => part[0]).join('').slice(0,2).toUpperCase()}</span>
            <span className="employee-suggestion-copy"><strong>{highlightMatch(profile.name, debounced)}</strong><small>{profile.username ? <>ID <b>{highlightMatch(profile.username, debounced)}</b></> : 'Employee profile'}</small></span>
            <span className="employee-suggestion-arrow" aria-hidden="true">↗</span>
          </button>) : <div className="employee-suggestion-status">No matching users found</div>}
        </div>}
      </div>}
      <div className="analytics-filters"><label>Range<select value={range} onChange={e => { setRange(e.target.value); if (ranges[e.target.value]) setCustom(ranges[e.target.value]()); }}><option value="today">Today</option><option value="7d">Last 7 days</option><option value="30d">Last 30 days</option><option value="custom">Custom</option></select></label>{range === 'custom' && <><label>From<input type="date" value={custom[0]} onChange={e => setCustom([e.target.value, custom[1]])}/></label><label>To<input type="date" value={custom[1]} onChange={e => setCustom([custom[0], e.target.value])}/></label></>}<label>View<select value={period} onChange={e => setPeriod(e.target.value)}><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option></select></label><label>Status<select value={status} onChange={e => setStatus(e.target.value)}><option value="all">All tasks</option><option value="completed">Completed</option><option value="pending">Pending</option></select></label><button className="analytics-export" onClick={csv} disabled={!result}>↓ Export CSV</button><button className="analytics-export" onClick={excel} disabled={!result}>↓ Export Excel</button></div>
    </div>
    {error && <div className="analytics-error" role="alert">{error}<button onClick={() => setRange(value => value)}>Retry</button></div>}
    {!individual && view === 'individual' && !selected ? <div className="analytics-empty" role="status"><span>◎</span><strong>Select a user to view analytics</strong><p>Search by name or username, then choose a matching profile.</p></div> : loading && !result ? <div className="analytics-loading" role="status"><span/><span/><span/><p>Preparing your insights…</p></div> : result && <><section className="analytics-kpis" aria-label="Key task metrics">{[['Total users',fmt(summary.total_users),'◉'],['Total tasks',fmt(summary.total_tasks),'▤'],['Completed',fmt(summary.completed),'✓'],['Pending',fmt(summary.pending),'◷'],['Completion',`${summary.completion_rate}%`,'↗'],['Submitted today',fmt(summary.submitted_today),'✦'],['Active users · range',fmt(summary.active_users),'◎'],['Avg tasks / user',summary.average_tasks_per_user,'⌁']].map(([label,value,icon],i)=><article key={label} className={`analytics-kpi kpi-${i}`}><span>{icon}</span><div><small>{label}</small><strong>{value}</strong></div><i/></article>)}</section><section className="analytics-chart-grid">{charts.map(([kind, label])=><ChartCard key={kind} kind={kind} title={label} data={result}/>)}</section>{!result.summary.total_tasks && <div className="analytics-empty"><span>◌</span><strong>No task activity in this range</strong><p>Try a wider date range or another status.</p></div>}</>}
    <p className="analytics-footnote">Completion is based on task status. Activity trends use submission timestamps; completion timestamps are not recorded.</p>
  </main>;
}
