import React, { useEffect, useRef, useState } from 'react';
import HeaderTools from './HeaderTools.jsx';
import { API_BASE, apiFetch } from './authApi.js';
import PaginationControls from './PaginationControls.jsx';
import ExpandableTableContainer from './ExpandableTableContainer.jsx';


// Admin-only page: every user's submitted tasks with server-recorded submission times (IST).
export default function AdminDashboard({ user, onLogout, onBack, onOpenProfiles, onOpenAnalytics }) {
  const [rows, setRows] = useState([]);
  const [totalRows, setTotalRows] = useState(0);
  const [taskStats, setTaskStats] = useState({total:0, completed:0, pending:0});
  const [taskPage, setTaskPage] = useState(0);
  const [pageSize, setPageSize] = useState(100);
  const [search, setSearch] = useState('');
  const [taskStatus, setTaskStatus] = useState('all');
  const [taskSort, setTaskSort] = useState('newest');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [oldPfOpen, setOldPfOpen] = useState(false);
  const [oldPfRows, setOldPfRows] = useState([]);
  const [oldPfTotal, setOldPfTotal] = useState(0);
  const [oldPfPage, setOldPfPage] = useState(0);
  const [oldPfPageSize, setOldPfPageSize] = useState(100);
  const oldPfRequest = useRef(0);
  const oldPfAbort = useRef(null);
  const [oldPfLoading, setOldPfLoading] = useState(false);
  const [oldPfError, setOldPfError] = useState('');
  const [downloadOpen, setDownloadOpen] = useState(false);
  const [downloadMessage, setDownloadMessage] = useState('');

  async function downloadTasks(format) {
    setDownloadOpen(false);
    setDownloadMessage('');
    try {
      const res = await apiFetch(`${API_BASE}/admin/tasks/export?format=${format}`);
      if (res.status === 204) {
        setDownloadMessage('No records available to download');
        return;
      }
      if (res.status === 403) throw new Error('Only administrators can download task records.');
      if (!res.ok) throw new Error(`Could not download the ${format.toUpperCase()} report.`);
      const blob = await res.blob();
      const disposition = res.headers.get('Content-Disposition') || '';
      const filename = disposition.match(/filename="?([^";]+)"?/i)?.[1]
        || `Admin_Tasks_${new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date())}.${format}`;
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      setDownloadMessage(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message);
    }
  }

  async function toggleOldPf() {
    if (oldPfOpen) { setOldPfOpen(false); return; }
    setOldPfOpen(true); setOldPfPage(0);
  }
  async function loadOldPf(targetPage = oldPfPage, size = oldPfPageSize) {
    const requestId = ++oldPfRequest.current;
    oldPfAbort.current?.abort();
    const controller = new AbortController(); oldPfAbort.current = controller;
    setOldPfLoading(true); setOldPfError('');
    try {
      const res = await apiFetch(`${API_BASE}/admin/old-pf?offset=${targetPage * size}&limit=${size}`, {signal:controller.signal});
      if (res.status === 403) throw new Error('Only administrators can view Old PF records.');
      if (!res.ok) throw new Error('Could not load Old PF records.');
      const result = await res.json();
      if (requestId !== oldPfRequest.current) return;
      setOldPfRows(result.items); setOldPfTotal(result.total);
      const last = Math.max(0, Math.ceil(result.total / size) - 1);
      if (targetPage > last) setOldPfPage(last);
    } catch (err) { if (requestId === oldPfRequest.current) setOldPfError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message); }
    finally { if (requestId === oldPfRequest.current) setOldPfLoading(false); }
  }
  useEffect(() => { if (oldPfOpen) loadOldPf(oldPfPage, oldPfPageSize); }, [oldPfPage, oldPfPageSize, oldPfOpen]);

  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    setLoading(true); setError('');
    apiFetch(`${API_BASE}/admin/tasks?offset=${taskPage * pageSize}&limit=${pageSize}&q=${encodeURIComponent(search)}&status=${taskStatus}&sort=${taskSort}`, {signal:controller.signal})
      .then(res => {
        if (res.status === 403) throw new Error('Only administrators can view this dashboard.');
        if (!res.ok) throw new Error('Could not load submissions.');
        return res.json();
      })
      .then(result => {
        if (!active) return;
        setRows(result.items); setTotalRows(result.total);
        if (result.stats) setTaskStats(result.stats);
        const lastPage = Math.max(0, Math.ceil(result.total / pageSize) - 1);
        if (taskPage > lastPage) setTaskPage(lastPage);
      })
      .catch(err => { if (active) setError(err.message === 'Failed to fetch' ? 'Backend not reachable. Start the Python server.' : err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; controller.abort(); };
  }, [taskPage, pageSize, search, taskStatus, taskSort]);

  const notRecorded = <span className="not-recorded">Not recorded</span>;

  return (
    <main>
      <div className="heading">
        <h1>ADMIN DASHBOARD</h1>
        <HeaderTools user={user} onLogout={onLogout}>
          <button type="button" className="logout-btn" onClick={onBack}>← Back to MY TASKS</button>
          {user.role === 'admin' && <button type="button" className="admin-btn" onClick={onOpenProfiles}>User Profiles</button>}
          {user.role === 'admin' && <button type="button" className="admin-btn" onClick={onOpenAnalytics}>Analytics Dashboard</button>}
          {user.role === 'admin' && <button type="button" className="admin-btn" aria-expanded={oldPfOpen} onClick={toggleOldPf}>Old PF</button>}
        </HeaderTools>
      </div>
      <section className="dashboard-stats" aria-label="Task statistics">
        <article className="stat-card stat-total"><span className="stat-icon" aria-hidden="true">?</span><div><span className="stat-label">All tasks</span><strong>{taskStats.total.toLocaleString()}</strong></div></article>
        <article className="stat-card stat-completed"><span className="stat-icon" aria-hidden="true">?</span><div><span className="stat-label">Completed</span><strong>{taskStats.completed.toLocaleString()}</strong></div></article>
        <article className="stat-card stat-pending"><span className="stat-icon" aria-hidden="true">?</span><div><span className="stat-label">Pending</span><strong>{taskStats.pending.toLocaleString()}</strong></div></article>
      </section>
      {oldPfOpen && <section className="old-pf-section" aria-label="Old PF records">
        <h2 className="dash-subtitle">Old PF ({oldPfTotal.toLocaleString()})</h2>
        {oldPfError && <p className="error" role="alert">{oldPfError}</p>}
        {oldPfLoading ? <p>Loading…</p> : !oldPfError && (oldPfRows.length ? <ExpandableTableContainer scrollClassName="emp-scroll" label="Old PF records">
          <table className="task-table dash-table">
            <thead><tr><th>S.No</th><th>Employee Name</th><th>Profile</th><th>Remarks</th></tr></thead>
            <tbody>{oldPfRows.map((row, i) => <tr key={row.username}>
              <td>{oldPfPage * oldPfPageSize + i + 1}</td><td>{row.name}</td><td>{row.profile}</td><td>{row.remarks}</td>
            </tr>)}</tbody>
          </table>
        </ExpandableTableContainer> : <div className="empty-state"><span aria-hidden="true">?</span><strong>No Old PF records</strong><p>Deactivated employee history will appear here.</p></div>)}
        {oldPfTotal > 0 && <PaginationControls page={oldPfPage} pageSize={oldPfPageSize} total={oldPfTotal} loading={oldPfLoading} onPageChange={setOldPfPage} onPageSizeChange={size => {setOldPfPageSize(size);setOldPfPage(0);}} label="Old PF records" />}
      </section>}
      <div className="dashboard-table-heading">
        <h2 className="dash-subtitle">All submitted tasks ({totalRows.toLocaleString()})</h2>
        {user?.role === 'admin' && <div className="download-menu-wrap">
          <button type="button" className="download-menu-button" aria-haspopup="menu" aria-expanded={downloadOpen}
            onClick={() => { setDownloadOpen(open => !open); setDownloadMessage(''); }}>
            <svg aria-hidden="true" viewBox="0 0 16 16" width="14" height="14" fill="none">
              <path d="M8 1.5v8m0 0 3-3m-3 3-3-3M2.5 10.5v3h11v-3" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span>Download</span><span className="download-menu-arrow" aria-hidden="true">▾</span>
          </button>
          {downloadOpen && <div className="download-menu" role="menu">
            <button type="button" role="menuitem" onClick={() => downloadTasks('xlsx')}>Excel (.xlsx)</button>
            <button type="button" role="menuitem" onClick={() => downloadTasks('csv')}>CSV (.csv)</button>
          </div>}
        </div>}
      </div>
      {downloadMessage && <p className="download-message" role="status">{downloadMessage}</p>}
      {!loading && !error && totalRows === 0 && !downloadMessage && <p className="download-message" role="status">No records available to download</p>}
      <div className="task-table-controls"><label>Search <input value={search} onChange={e => {setSearch(e.target.value);setTaskPage(0);}} placeholder="Name or task" aria-label="Search submitted tasks"/></label>
        <label>Status <select value={taskStatus} onChange={e => {setTaskStatus(e.target.value);setTaskPage(0);}}><option value="all">All</option><option value="pending">Pending</option><option value="completed">Completed</option></select></label>
        <label>Sort <select value={taskSort} onChange={e => {setTaskSort(e.target.value);setTaskPage(0);}}><option value="newest">Newest</option><option value="oldest">Oldest</option><option value="name">Employee name</option><option value="task">Task description</option></select></label>
      </div>
      <p className="dash-note">Submission date and time are recorded automatically by the server and shown in Indian Standard Time (IST).</p>
      {error && <p className="error" role="alert">{error}</p>}
      {loading ? <p>Loading…</p> : !error && (totalRows ? <>
        <ExpandableTableContainer scrollClassName="emp-scroll" label="Admin task records">
          <table className="task-table dash-table">
            <thead>
              <tr>
                <th>S.No</th><th>Employee Name</th><th>Task Description</th><th>Task Time</th>
                <th>Submission Date (IST)</th><th>Submission Time (IST)</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.id}>
                  <td>{taskPage * pageSize + i + 1}</td>
                  <td>{r.employee_name}{r.submitted_by && r.submitted_by.toLowerCase() !== r.employee_name.toLowerCase() &&
                    <span className="submitted-by">submitted by {r.submitted_by}</span>}</td>
                  <td>{r.task}</td>
                  <td>{r.task_time || '—'}</td>
                  <td>{r.submitted_date || notRecorded}</td>
                  <td>{r.submitted_time || notRecorded}</td>
                  <td><span className={`status-badge status-${r.status.toLowerCase()}`}>{r.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </ExpandableTableContainer>
        <PaginationControls page={taskPage} pageSize={pageSize} total={totalRows} loading={loading} onPageChange={setTaskPage} onPageSizeChange={size => {setPageSize(size);setTaskPage(0);}} label="tasks" />
      </> : <div className="empty-state"><span aria-hidden="true">?</span><strong>No submitted tasks yet</strong><p>New submissions will appear here.</p></div>)}
    </main>
  );
}
