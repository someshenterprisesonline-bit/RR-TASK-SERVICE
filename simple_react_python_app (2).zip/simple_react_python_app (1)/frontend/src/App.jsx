import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);
  const [savedTasks, setSavedTasks] = useState([]);

  useEffect(() => {
    fetchTasks();
    fetchSavedTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:5000/tasks');
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const fetchSavedTasks = async () => {
    try {
      const response = await axios.get('http://localhost:5000/tasks');
      setSavedTasks(response.data);
    } catch (error) {
      console.error('Error fetching saved tasks:', error);
    }
  };

  const addTask = async () => {
    try {
      await axios.post('http://localhost:5000/tasks', { task });
      setTask('');
      fetchTasks();
      fetchSavedTasks();
    } catch (error) {
      console.error('Error adding task:', error);
    }
  };

  return (
    <div>
      <h1>Task Manager</h1>
      <input
        type="text"
        value={task}
        onChange={(e) => setTask(e.target.value)}
        placeholder="Add a new task"
      />
      <button onClick={addTask}>Add Task</button>
      <h2>Tasks</h2>
      <ul>
        {tasks.map((t, index) => (
          <li key={index}>{t.task}</li>
        ))}
      </ul>
      <h2>Saved Tasks</h2>
      <select>
        {savedTasks.map((t, index) => (
          <option key={index} value={t.task}>
            {t.task}
          </option>
        ))}
      </select>
    </div>
  );
}

export default App;
